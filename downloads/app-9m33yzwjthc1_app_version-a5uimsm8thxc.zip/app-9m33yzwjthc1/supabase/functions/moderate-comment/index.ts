import { createClient } from 'jsr:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface ModerationRequest {
  commentId: string;
  name: string;
  content: string;
}

interface ModerationResult {
  approved: boolean;
  reason: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { commentId, name, content }: ModerationRequest = await req.json();

    if (!commentId || !content) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // استخدام Gemini AI للمراجعة عبر Gateway
    const INTEGRATIONS_API_KEY = Deno.env.get('INTEGRATIONS_API_KEY');
    if (!INTEGRATIONS_API_KEY) {
      throw new Error('INTEGRATIONS_API_KEY not configured');
    }

    const prompt = `أنت مشرف صارم جداً على تعليقات حملة "نطالب بإنترنت غير محدود في مصر".
مهمتك مراجعة التعليقات والموافقة عليها أو رفضها بناءً على المعايير التالية:

⚠️ قواعد مهمة:
- كن صارماً جداً في المراجعة
- التعليقات الغامضة أو القصيرة جداً تُرفض
- التعليقات التي لا تدعم الحملة بوضوح تُرفض
- أي تعليق يحتوي على كلمات إيجابية عن الخدمة الحالية يُرفض فوراً
- أي ذكر لأسماء شركات الاتصالات بشكل إيجابي يُرفض فوراً

🚫 شركات الاتصالات المصرية (يُرفض أي مدح لها):
- وي (WE)
- فودافون (Vodafone)
- اورانج (Orange)
- اتصالات (Etisalat)
- أي شركة اتصالات أخرى

✅ يُقبل التعليق فقط إذا:
- يطالب صراحةً بإنترنت غير محدود
- ينتقد خدمات الإنترنت الحالية بوضوح (مثل: غالية، محدودة، بطيئة، تنتهي بسرعة، نصب)
- يشارك تجربة شخصية سلبية واضحة مع خدمة الإنترنت
- يشرح لماذا يحتاج إنترنت غير محدود (للعمل، الدراسة، الترفيه)
- يقترح حلول لتحسين الخدمة
- يعبر عن دعم واضح للحملة
- ينتقد شركات الاتصالات بشكل سلبي (مقبول)

❌ يُرفض التعليق فوراً إذا:
- يذكر اسم شركة اتصالات بشكل إيجابي (مثل: "افضل شركة وي"، "وي حلوة"، "فودافون كويسة")
- يمدح أي شركة اتصالات أو يدافع عنها
- يقول أن الخدمة جيدة أو ممتازة أو كافية
- يحتوي على كلمات إيجابية عن الخدمة الحالية (مثل: "افضل"، "ممتاز"، "كويس"، "تمام"، "حلو"، "عسل")
- غامض أو غير واضح المعنى (مثل: "وي عسل"، "حلو"، "تمام"، "جميل")
- قصير جداً (أقل من 10 كلمات) ولا يوضح موقفه من الحملة
- يحتوي على ألفاظ نابية أو بذيئة أو شتائم
- يحتوي على تحرش أو إساءة شخصية
- يحتوي على محتوى ديني (آيات قرآنية، أحاديث، دعاء، مواعظ دينية)
- يحتوي على محتوى سياسي
- يسيء للحملة أو يهاجمها
- يحتوي على سبام أو إعلانات
- يحتوي على معلومات شخصية (أرقام هواتف، عناوين)
- لا يوضح موقفه من الحملة بشكل صريح

أمثلة للتعليقات المرفوضة:
- "افضل شركة وي" ← يمدح شركة اتصالات
- "افضل شركة هي وي" ← يمدح شركة اتصالات
- "فودافون كويسة" ← يمدح شركة اتصالات
- "وي عسل" ← غامض ويمدح شركة
- "حلو" ← قصير وغامض
- "تمام" ← لا يوضح الموقف
- "الخدمة كويسة" ← يمدح الخدمة
- "الحمد لله على كل حال" ← محتوى ديني
- "بسم الله الرحمن الرحيم" ← محتوى ديني
- "الحملة دي غلط" ← يسيء للحملة

أمثلة للتعليقات المقبولة:
- "الباقات غالية جداً ومحدودة، نحتاج إنترنت غير محدود"
- "الإنترنت بينتهي بسرعة، لازم يكون غير محدود"
- "محتاج إنترنت غير محدود للعمل من البيت"
- "شركات الاتصالات بتنصب علينا، عايزين إنترنت غير محدود"
- "وي والشركات التانية بتسرقنا، محتاجين إنترنت مفتوح"

التعليق المطلوب مراجعته:
الاسم: ${name}
المحتوى: ${content}

قرر: هل يُقبل هذا التعليق أم يُرفض؟
أجب بصيغة JSON فقط:
{
  "approved": true أو false,
  "reason": "سبب القرار بالعربية"
}`;

    const geminiResponse = await fetch(
      `https://app-9m33yzwjthc1-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent`,
      {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'X-Gateway-Authorization': `Bearer ${INTEGRATIONS_API_KEY}`
        },
        body: JSON.stringify({
          contents: [{
            role: 'user',
            parts: [{ text: prompt }]
          }]
        })
      }
    );

    if (!geminiResponse.ok) {
      const errorText = await geminiResponse.text();
      console.error('Gemini API error:', geminiResponse.status, errorText);
      throw new Error(`Gemini API error: ${geminiResponse.status} - ${errorText}`);
    }

    const geminiData = await geminiResponse.json();
    const aiResponse = geminiData.candidates?.[0]?.content?.parts?.[0]?.text || '';
    
    console.log('AI Response:', aiResponse);
    
    // استخراج JSON من الرد
    const jsonMatch = aiResponse.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      console.error('Invalid AI response format. Response:', aiResponse);
      throw new Error('Invalid AI response format');
    }

    const moderation: ModerationResult = JSON.parse(jsonMatch[0]);

    // تحديث حالة التعليق في قاعدة البيانات
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { error: updateError } = await supabase
      .from('comments')
      .update({
        status: moderation.approved ? 'approved' : 'rejected',
        moderation_reason: moderation.reason
      })
      .eq('id', commentId);

    if (updateError) {
      throw updateError;
    }

    return new Response(
      JSON.stringify({
        success: true,
        approved: moderation.approved,
        reason: moderation.reason
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Moderation error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
