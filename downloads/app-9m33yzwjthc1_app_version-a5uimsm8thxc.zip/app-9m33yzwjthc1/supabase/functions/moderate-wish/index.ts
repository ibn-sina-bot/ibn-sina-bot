// AI Wish Moderation Edge Function
// مراجعة الأمنيات بالذكاء الاصطناعي

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface ModerationRequest {
  wishText: string;
  userName?: string;
  governorate?: string;
}

interface ModerationResult {
  approved: boolean;
  reason?: string;
  suggestions?: string;
  category?: 'appropriate' | 'offensive' | 'illegal' | 'spam' | 'off-topic';
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { wishText, userName, governorate }: ModerationRequest = await req.json();

    if (!wishText || wishText.trim().length === 0) {
      return new Response(
        JSON.stringify({
          success: false,
          error: 'نص الأمنية مطلوب'
        }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // Get API key from environment
    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    if (!apiKey) {
      throw new Error('INTEGRATIONS_API_KEY not configured');
    }

    // Prepare AI moderation prompt
    const prompt = `أنت مراجع محتوى خبير في حملة "نطالب بإنترنت غير محدود في مصر 🇪🇬". مهمتك مراجعة الأمنيات التي يكتبها المستخدمون للتأكد من أنها مناسبة.

**الأمنية المطلوب مراجعتها:**
"${wishText}"

**معايير القبول:**
✅ يجب أن تكون الأمنية:
1. تدعم الحملة بشكل إيجابي (تطالب بإنترنت أفضل، أسعار أقل، خدمة أحسن)
2. محترمة وخالية من الألفاظ البذيئة أو المسيئة
3. لا تحتوي على محتوى مخالف للقانون أو يحرض على العنف
4. لا تحتوي على محتوى مسيء للمجتمع أو الأديان أو الأعراق
5. ليست spam أو إعلانات
6. متعلقة بموضوع الحملة (الإنترنت في مصر)

❌ يجب رفض الأمنية إذا كانت:
1. تحتوي على ألفاظ بذيئة أو مسيئة
2. تحرض على العنف أو الكراهية
3. تحتوي على محتوى جنسي أو غير لائق
4. إعلانات أو spam
5. لا علاقة لها بالحملة نهائياً
6. تحتوي على معلومات شخصية حساسة (أرقام هواتف، عناوين)

**المطلوب:**
راجع الأمنية وأعطني النتيجة بتنسيق JSON فقط:

\`\`\`json
{
  "approved": true أو false,
  "reason": "سبب القبول أو الرفض بالعربية",
  "suggestions": "اقتراحات للتحسين إذا تم الرفض (اختياري)",
  "category": "appropriate" أو "offensive" أو "illegal" أو "spam" أو "off-topic"
}
\`\`\`

**أمثلة:**

مثال 1 - مقبول:
الأمنية: "نفسي الإنترنت يكون غير محدود عشان أقدر أذاكر أونلاين براحتي"
النتيجة: {"approved": true, "reason": "أمنية إيجابية تدعم الحملة وتتحدث عن التعليم", "category": "appropriate"}

مثال 2 - مرفوض (ألفاظ مسيئة):
الأمنية: "الشركات دي كلها نصابة و..."
النتيجة: {"approved": false, "reason": "تحتوي على ألفاظ غير لائقة", "suggestions": "يمكنك التعبير عن رأيك بشكل محترم مثل: نتمنى تحسين الخدمة والأسعار", "category": "offensive"}

مثال 3 - مرفوض (خارج الموضوع):
الأمنية: "نفسي أشتري عربية جديدة"
النتيجة: {"approved": false, "reason": "الأمنية لا تتعلق بموضوع الحملة (الإنترنت)", "suggestions": "اكتب أمنية متعلقة بالإنترنت في مصر", "category": "off-topic"}

**ملاحظة مهمة:**
- كن متسامحاً مع الأخطاء الإملائية
- ركز على المحتوى وليس الشكل
- إذا كانت الأمنية تدعم الحملة بشكل عام، اقبلها حتى لو كانت بسيطة
- ارفض فقط المحتوى المسيء أو المخالف أو الخارج عن الموضوع تماماً`;

    // Call AI API
    const response = await fetch(
      'https://app-9m33yzwjthc1-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Gateway-Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [{ text: prompt }],
            },
          ],
        }),
      }
    );

    if (!response.ok) {
      throw new Error(`AI API error: ${response.status} ${response.statusText}`);
    }

    // Parse streaming response
    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    let fullText = '';

    if (reader) {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value);
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.candidates?.[0]?.content?.parts?.[0]?.text) {
                fullText += data.candidates[0].content.parts[0].text;
              }
              
              // Check safety ratings
              const safetyRatings = data.candidates?.[0]?.safetyRatings;
              if (safetyRatings && Array.isArray(safetyRatings)) {
                for (const rating of safetyRatings) {
                  if (rating.probability === 'HIGH' || rating.probability === 'MEDIUM') {
                    // Content flagged by safety system
                    return new Response(
                      JSON.stringify({
                        success: true,
                        moderation: {
                          approved: false,
                          reason: 'المحتوى يحتوي على عناصر غير مناسبة تم اكتشافها تلقائياً',
                          suggestions: 'يرجى إعادة صياغة الأمنية بشكل محترم وإيجابي',
                          category: 'offensive'
                        }
                      }),
                      {
                        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
                      }
                    );
                  }
                }
              }
            } catch (e) {
              // Skip invalid JSON
              console.error('JSON parse error:', e);
            }
          }
        }
      }
    }

    // Extract JSON from response
    let moderationResult: ModerationResult;
    try {
      // Try to find JSON in the response
      const jsonMatch = fullText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        moderationResult = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('No JSON found in AI response');
      }
    } catch (e) {
      console.error('Failed to parse AI response:', e);
      // Default to approval if AI fails (fail-open approach)
      moderationResult = {
        approved: true,
        reason: 'تمت الموافقة (نظام المراجعة غير متاح حالياً)',
        category: 'appropriate'
      };
    }

    return new Response(
      JSON.stringify({
        success: true,
        moderation: moderationResult,
        rawResponse: fullText
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error) {
    console.error('Error in wish moderation:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'حدث خطأ في مراجعة الأمنية'
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
