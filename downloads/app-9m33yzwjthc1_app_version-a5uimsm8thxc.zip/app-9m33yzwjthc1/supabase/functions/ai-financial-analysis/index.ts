// AI Financial Analysis Edge Function
// تحليل مالي ذكي باستخدام الذكاء الاصطناعي

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface AnalysisRequest {
  monthlySpending: number;
  yearlySpending: number;
  fiveYearSpending: number;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { monthlySpending, yearlySpending, fiveYearSpending }: AnalysisRequest = await req.json();

    // Get API key from environment
    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    if (!apiKey) {
      throw new Error('INTEGRATIONS_API_KEY not configured');
    }

    // Prepare AI prompt for realistic Egyptian financial analysis
    const prompt = `أنت محلل مالي خبير في السوق المصري. قم بتحليل الإنفاق التالي بشكل واقعي ودقيق جداً مع حسابات رياضية صحيحة 100%.

**المبالغ المتاحة:**
- المبلغ الشهري: ${monthlySpending} جنيه مصري
- المبلغ السنوي: ${yearlySpending} جنيه مصري
- المبلغ على 5 سنوات: ${fiveYearSpending} جنيه مصري

**قواعد الحساب الإلزامية:**
1. استخدم الأسعار الحقيقية في السوق المصري (2024-2026):
   - وجبة برجر عادية: 80-120 جنيه
   - وجبة في مطعم متوسط: 150-250 جنيه
   - وجبة فاخرة: 300-500 جنيه
   - اشتراك Netflix: 165 جنيه شهرياً
   - اشتراك Spotify: 50 جنيه شهرياً
   - اشتراك OSN: 100 جنيه شهرياً

2. **احسب بدقة رياضية**: 
   - عدد الوجبات = المبلغ السنوي ÷ سعر الوجبة
   - تأكد من صحة الحساب: عدد الوجبات × سعر الوجبة = المبلغ السنوي (تقريباً)
   - مثال: إذا كان المبلغ السنوي 4860 جنيه وسعر البرجر 400 جنيه
     → عدد الوجبات = 4860 ÷ 400 = 12 وجبة فقط (وليس 46!)

3. **كن واقعياً جداً**:
   - إذا كان المبلغ صغير (أقل من 1000 جنيه سنوياً)، قل الحقيقة: "المبلغ محدود"
   - لا تبالغ في الأرقام
   - استخدم أسعار متوسطة معقولة

4. **راعي حال الناس**:
   - معظم المصريين يأكلون وجبات بسيطة (50-150 جنيه)
   - الوجبات الفاخرة نادرة
   - الاشتراكات الشهرية عبء على الميزانية

**المطلوب:**
1. تحليل المبلغ السنوي (${yearlySpending} جنيه):
   - كم وجبة برجر عادية (100 جنيه)؟ احسب: ${yearlySpending} ÷ 100
   - كم وجبة مطعم متوسط (200 جنيه)؟ احسب: ${yearlySpending} ÷ 200
   - كم شهر اشتراك Netflix (165 جنيه)؟ احسب: ${yearlySpending} ÷ 165
   - استخدامات أخرى واقعية

2. تحليل المبلغ على 5 سنوات (${fiveYearSpending} جنيه):
   - ما الذي يمكن شراؤه فعلياً؟
   - مقارنات واقعية (لابتوب: 15,000-25,000 جنيه، موبايل: 8,000-20,000 جنيه)

3. نصائح مالية عملية

**تنسيق الإجابة (JSON فقط):**
\`\`\`json
{
  "yearlyAnalysis": {
    "meals": {
      "count": [عدد_صحيح_دقيق],
      "pricePerMeal": [السعر_المستخدم],
      "description": "وصف يوضح الحساب: ${yearlySpending} ÷ [السعر] = [العدد] وجبة"
    },
    "subscriptions": {
      "count": [عدد_الأشهر_الصحيح],
      "pricePerMonth": [السعر_الشهري],
      "description": "وصف يوضح الحساب"
    },
    "other": [
      "استخدام واقعي 1 مع السعر",
      "استخدام واقعي 2 مع السعر",
      "استخدام واقعي 3 مع السعر"
    ]
  },
  "fiveYearAnalysis": {
    "bigPurchases": [
      "شراء واقعي 1 مع السعر التقريبي",
      "شراء واقعي 2 مع السعر التقريبي"
    ],
    "investments": [
      "استثمار 1",
      "استثمار 2"
    ]
  },
  "advice": {
    "savingTips": [
      "نصيحة عملية 1",
      "نصيحة عملية 2",
      "نصيحة عملية 3"
    ],
    "alternatives": [
      "بديل أفضل 1",
      "بديل أفضل 2"
    ]
  },
  "summary": "ملخص واقعي يراعي حال الناس ويوضح أن المبلغ ${yearlySpending} جنيه سنوياً يمكن استخدامه في احتياجات أساسية"
}
\`\`\`

**تحذير مهم:** 
- تحقق من صحة كل حساب رياضياً قبل الإجابة
- لا تعطي أرقام خيالية
- كن صادقاً مع المستخدم حتى لو كان المبلغ صغير`;

    // Call AI API
    const response = await fetch(
      'https://app-9m33yzwjthc1-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Gateway-Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [{ text: prompt }],
            },
          ],
        }),
      }
    );

    if (!response.ok) {
      throw new Error(`AI API error: ${response.status} ${response.statusText}`);
    }

    // Parse streaming response
    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    let fullText = '';

    if (reader) {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value);
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.candidates?.[0]?.content?.parts?.[0]?.text) {
                fullText += data.candidates[0].content.parts[0].text;
              }
            } catch (e) {
              // Skip invalid JSON
              console.error('JSON parse error:', e);
            }
          }
        }
      }
    }

    // Extract JSON from response (AI might wrap it in markdown)
    let analysisData;
    try {
      // Try to find JSON in the response
      const jsonMatch = fullText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        analysisData = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('No JSON found in AI response');
      }
    } catch (e) {
      console.error('Failed to parse AI response:', e);
      // Fallback to basic analysis
      analysisData = {
        yearlyAnalysis: {
          meals: {
            count: Math.floor(yearlySpending / 100),
            pricePerMeal: 100,
            description: `${Math.floor(yearlySpending / 100)} وجبة برجر عادية (الحساب: ${yearlySpending} ÷ 100 = ${Math.floor(yearlySpending / 100)} وجبة)`
          },
          subscriptions: {
            count: Math.floor(yearlySpending / 165),
            pricePerMonth: 165,
            description: `${Math.floor(yearlySpending / 165)} شهر Netflix (الحساب: ${yearlySpending} ÷ 165 = ${Math.floor(yearlySpending / 165)} شهر)`
          },
          other: [
            `${Math.floor(yearlySpending / 50)} كتاب (بسعر 50 جنيه للكتاب)`,
            `${Math.floor(yearlySpending / 150)} تذكرة سينما (بسعر 150 جنيه)`,
            `${Math.floor(yearlySpending / 30)} لتر بنزين (بسعر 30 جنيه)`
          ]
        },
        fiveYearAnalysis: {
          bigPurchases: [
            fiveYearSpending >= 15000 ? `لابتوب متوسط (15,000-20,000 جنيه)` : fiveYearSpending >= 8000 ? `موبايل جيد (8,000-12,000 جنيه)` : `موبايل بسيط (${Math.floor(fiveYearSpending)} جنيه)`,
            fiveYearSpending >= 10000 ? `رحلة عائلية (10,000-15,000 جنيه)` : `رحلة قصيرة (${Math.floor(fiveYearSpending / 2)} جنيه)`
          ],
          investments: [
            `شهادة استثمار بمبلغ ${Math.floor(fiveYearSpending * 0.7)} جنيه`,
            `صندوق ادخار شهري`
          ]
        },
        advice: {
          savingTips: [
            'ابحث عن باقات إنترنت غير محدودة بسعر ثابت',
            'قارن الأسعار بين الشركات المختلفة',
            'استخدم عروض الاشتراكات السنوية (توفر 20-30%)'
          ],
          alternatives: [
            'إنترنت منزلي غير محدود (300-400 جنيه شهرياً)',
            'باقات عائلية مشتركة توفر المال'
          ]
        },
        summary: `بإنفاق ${monthlySpending} جنيه شهرياً على باقات الإنترنت، أنت تصرف ${yearlySpending} جنيه سنوياً. هذا المبلغ يمكن أن يغطي ${Math.floor(yearlySpending / 100)} وجبة برجر عادية أو ${Math.floor(yearlySpending / 165)} شهر اشتراك Netflix. المبلغ قد يبدو صغيراً، لكنه يتراكم مع الوقت ويمكن استخدامه في احتياجات أساسية.`
      };
    }

    return new Response(
      JSON.stringify({
        success: true,
        analysis: analysisData,
        rawResponse: fullText
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error) {
    console.error('Error in AI financial analysis:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'حدث خطأ في التحليل المالي'
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
