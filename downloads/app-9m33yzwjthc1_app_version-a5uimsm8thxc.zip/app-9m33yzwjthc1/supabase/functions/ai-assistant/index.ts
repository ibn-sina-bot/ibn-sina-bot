import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-gateway-authorization',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { messages } = await req.json();
    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    
    if (!apiKey) {
      return new Response(JSON.stringify({ error: 'API key not configured' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const systemPrompt = `أنت مساعد ذكي لحملة "نطالب بإنترنت غير محدود في مصر". مهمتك الأساسية هي توجيه المستخدمين لكيفية تقديم شكوى رسمية بشأن خدمات الإنترنت.
إليك الخطوات التي يجب أن تعلمها للمستخدمين:
1. اتصل بخدمة عملاء شركتك (WE, Vodafone, Orange, Etisalat) على رقم 111.
2. أبلغ عن مشكلتك (مثلاً: سرعة الإنترنت منخفضة أو الباقة بتخلص بسرعة بدون استخدام حقيقي).
3. اطلب "رقم شكوى" (رقم تذكرة) واحتفظ به جيداً. هذا الرقم ضروري جداً.
4. انتظر لمدة 48 ساعة (يومي عمل).
5. إذا لم يتم حل المشكلة أو لم يتواصلوا معك، اتصل بالجهاز القومي لتنظيم الاتصالات (NTRA) على رقم 155.
6. قدم لهم رقم الشكوى الذي حصلت عليه من الشركة.

رد دائماً باللغة العربية بأسلوب ودود وداعم للحملة. إذا سألك المستخدم أي سؤال خارج هذا السياق، حاول دائماً ربطه بالحملة وبحق المواطن في إنترنت عادل وغير محدود.`;

    const contents = [
      {
        role: "user",
        parts: [{ text: systemPrompt }]
      },
      {
        role: "model",
        parts: [{ text: "فهمت تماماً. أنا جاهز لمساعدة المواطنين المصريين في الحصول على حقوقهم وتوجيههم لتقديم الشكاوى بالطريقة الصحيحة. كيف يمكنني مساعدتك اليوم؟" }]
      },
      ...messages
    ];

    const response = await fetch("https://app-9m33yzwjthc1-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Gateway-Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({ contents }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      return new Response(JSON.stringify({ error: `API error: ${errorText}` }), {
        status: response.status,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Return the stream directly to the client
    return new Response(response.body, {
      headers: {
        ...corsHeaders,
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });

  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
})
