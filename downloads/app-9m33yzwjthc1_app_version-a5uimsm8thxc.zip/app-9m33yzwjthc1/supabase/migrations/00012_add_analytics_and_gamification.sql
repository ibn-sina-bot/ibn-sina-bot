-- Add analytics fields to votes table
ALTER TABLE votes ADD COLUMN IF NOT EXISTS network_provider TEXT;
ALTER TABLE votes ADD COLUMN IF NOT EXISTS data_usage_type TEXT;
ALTER TABLE votes ADD COLUMN IF NOT EXISTS signature_name TEXT;
ALTER TABLE votes ADD COLUMN IF NOT EXISTS signature_governorate TEXT;

-- Create user_points table for gamification
CREATE TABLE IF NOT EXISTS user_points (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    fingerprint TEXT NOT NULL UNIQUE,
    points INTEGER DEFAULT 0,
    vote_count INTEGER DEFAULT 0,
    share_count INTEGER DEFAULT 0,
    last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index for leaderboard queries
CREATE INDEX IF NOT EXISTS idx_user_points_points ON user_points(points DESC);
CREATE INDEX IF NOT EXISTS idx_user_points_fingerprint ON user_points(fingerprint);

-- RLS policies for user_points
ALTER TABLE user_points ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can view leaderboard" ON user_points FOR SELECT USING (true);
CREATE POLICY "Public can insert points" ON user_points FOR INSERT WITH CHECK (true);
CREATE POLICY "Public can update own points" ON user_points FOR UPDATE USING (true);

-- Function to award points
CREATE OR REPLACE FUNCTION award_points(
    user_fingerprint TEXT,
    points_to_add INTEGER,
    action_type TEXT
) RETURNS void AS $$
BEGIN
    INSERT INTO user_points (fingerprint, points, vote_count, share_count)
    VALUES (
        user_fingerprint, 
        points_to_add,
        CASE WHEN action_type = 'vote' THEN 1 ELSE 0 END,
        CASE WHEN action_type = 'share' THEN 1 ELSE 0 END
    )
    ON CONFLICT (fingerprint) 
    DO UPDATE SET 
        points = user_points.points + points_to_add,
        vote_count = user_points.vote_count + CASE WHEN action_type = 'vote' THEN 1 ELSE 0 END,
        share_count = user_points.share_count + CASE WHEN action_type = 'share' THEN 1 ELSE 0 END,
        last_updated = NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create view for network analytics
CREATE OR REPLACE VIEW network_analytics AS
SELECT 
    network_provider,
    COUNT(*) as vote_count,
    ROUND(COUNT(*) * 100.0 / NULLIF((SELECT COUNT(*) FROM votes WHERE network_provider IS NOT NULL), 0), 1) as percentage
FROM votes
WHERE network_provider IS NOT NULL
GROUP BY network_provider
ORDER BY vote_count DESC;

-- Create view for data usage analytics
CREATE OR REPLACE VIEW data_usage_analytics AS
SELECT 
    data_usage_type,
    COUNT(*) as response_count,
    ROUND(COUNT(*) * 100.0 / NULLIF((SELECT COUNT(*) FROM votes WHERE data_usage_type IS NOT NULL), 0), 1) as percentage
FROM votes
WHERE data_usage_type IS NOT NULL
GROUP BY data_usage_type
ORDER BY response_count DESC;

-- Grant access to views
GRANT SELECT ON network_analytics TO anon, authenticated;
GRANT SELECT ON data_usage_analytics TO anon, authenticated;
