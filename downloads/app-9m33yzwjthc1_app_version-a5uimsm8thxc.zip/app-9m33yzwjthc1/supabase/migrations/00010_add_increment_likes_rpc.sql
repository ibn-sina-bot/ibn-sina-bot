CREATE OR REPLACE FUNCTION increment_post_likes(post_id bigint)
RETURNS void AS $$
BEGIN
  UPDATE forum_posts
  SET likes = likes + 1
  WHERE id = post_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
