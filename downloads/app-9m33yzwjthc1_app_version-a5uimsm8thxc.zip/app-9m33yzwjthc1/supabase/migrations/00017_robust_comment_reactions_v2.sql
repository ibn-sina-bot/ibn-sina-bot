-- Ensure all existing rows have 0 instead of NULL for the new reaction columns
UPDATE public.comments 
SET broken_heart_count = COALESCE(broken_heart_count, 0),
    sad_count = COALESCE(sad_count, 0),
    likes_count = COALESCE(likes_count, 0),
    hearts_count = COALESCE(hearts_count, 0),
    fire_count = COALESCE(fire_count, 0);

-- Make them NOT NULL for good measure
ALTER TABLE public.comments 
ALTER COLUMN broken_heart_count SET NOT NULL,
ALTER COLUMN sad_count SET NOT NULL,
ALTER COLUMN likes_count SET NOT NULL,
ALTER COLUMN hearts_count SET NOT NULL,
ALTER COLUMN fire_count SET NOT NULL;

-- Update the RPC function to be more robust
CREATE OR REPLACE FUNCTION public.react_to_comment(
    target_comment_id UUID,
    user_fingerprint TEXT,
    reaction_kind TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    reaction_exists BOOLEAN;
    new_count INTEGER;
    result JSONB;
    col_name TEXT;
BEGIN
    -- Map kind to column name
    CASE reaction_kind
        WHEN 'like' THEN col_name := 'likes_count';
        WHEN 'heart' THEN col_name := 'hearts_count';
        WHEN 'fire' THEN col_name := 'fire_count';
        WHEN 'broken_heart' THEN col_name := 'broken_heart_count';
        WHEN 'sad' THEN col_name := 'sad_count';
        ELSE 
            RAISE EXCEPTION 'Invalid reaction kind: %', reaction_kind;
    END CASE;

    -- Check if reaction already exists
    SELECT EXISTS (
        SELECT 1 FROM public.comment_reactions 
        WHERE comment_id = target_comment_id 
        AND fingerprint = user_fingerprint 
        AND reaction_type = reaction_kind
    ) INTO reaction_exists;

    IF reaction_exists THEN
        -- Remove reaction
        DELETE FROM public.comment_reactions 
        WHERE comment_id = target_comment_id 
        AND fingerprint = user_fingerprint 
        AND reaction_type = reaction_kind;

        -- Decrement count
        EXECUTE format('UPDATE public.comments SET %I = GREATEST(0, COALESCE(%I, 0) - 1) WHERE id = $1 RETURNING %I', 
            col_name, col_name, col_name)
        USING target_comment_id
        INTO new_count;

        result := jsonb_build_object('action', 'removed', 'count', COALESCE(new_count, 0));
    ELSE
        -- Add reaction
        INSERT INTO public.comment_reactions (comment_id, fingerprint, reaction_type)
        VALUES (target_comment_id, user_fingerprint, reaction_kind);

        -- Increment count
        EXECUTE format('UPDATE public.comments SET %I = COALESCE(%I, 0) + 1 WHERE id = $1 RETURNING %I', 
            col_name, col_name, col_name)
        USING target_comment_id
        INTO new_count;

        result := jsonb_build_object('action', 'added', 'count', COALESCE(new_count, 0));
    END IF;

    RETURN result;
END;
$$;
