-- Remove the old constraint
ALTER TABLE public.comment_reactions 
DROP CONSTRAINT IF EXISTS comment_reactions_reaction_type_check;

-- Add the new constraint
ALTER TABLE public.comment_reactions 
ADD CONSTRAINT comment_reactions_reaction_type_check 
CHECK (reaction_type = ANY (ARRAY['like'::text, 'heart'::text, 'fire'::text, 'broken_heart'::text, 'sad'::text]));
