-- Create a table to track real-time presence
CREATE TABLE IF NOT EXISTS site_presence (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  last_seen TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  governorate TEXT
);

-- Index for performance on counting active users
CREATE INDEX IF NOT EXISTS idx_site_presence_last_seen ON site_presence (last_seen);

-- Add a column to track shared count specifically if not present (it is there)
-- Remove any virtual logic columns from campaign_stats if they exist (virtual_start_time, comment_offset)
-- We'll keep them but stop using them in the code.

-- Policy for site_presence (public insert/update)
ALTER TABLE site_presence ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow anonymous insert for presence" 
ON site_presence FOR INSERT 
TO anon 
WITH CHECK (true);

CREATE POLICY "Allow anonymous update for presence" 
ON site_presence FOR UPDATE 
TO anon 
USING (true)
WITH CHECK (true);

CREATE POLICY "Allow anonymous select for presence" 
ON site_presence FOR SELECT 
TO anon 
USING (true);

-- Function to clean up old presence rows (to keep the table small)
CREATE OR REPLACE FUNCTION clean_old_presence() RETURNS void AS $$
BEGIN
  DELETE FROM site_presence WHERE last_seen < NOW() - INTERVAL '1 hour';
END;
$$ LANGUAGE plpgsql;
