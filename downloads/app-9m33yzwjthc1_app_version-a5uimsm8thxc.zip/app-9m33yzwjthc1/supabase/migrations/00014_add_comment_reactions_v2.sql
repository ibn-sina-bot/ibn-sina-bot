-- Add reaction counts to comments table
ALTER TABLE public.comments 
ADD COLUMN IF NOT EXISTS likes_count INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS hearts_count INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS fire_count INTEGER DEFAULT 0;

-- Create comment_reactions table to track user reactions
CREATE TABLE IF NOT EXISTS public.comment_reactions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    comment_id UUID REFERENCES public.comments(id) ON DELETE CASCADE,
    fingerprint TEXT NOT NULL,
    reaction_type TEXT NOT NULL CHECK (reaction_type IN ('like', 'heart', 'fire')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE(comment_id, fingerprint, reaction_type)
);

-- Enable RLS
ALTER TABLE public.comment_reactions ENABLE ROW LEVEL SECURITY;

-- Policies for comment_reactions
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Anyone can read comment reactions') THEN
        CREATE POLICY "Anyone can read comment reactions" ON public.comment_reactions FOR SELECT USING (true);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Anyone can insert comment reactions') THEN
        CREATE POLICY "Anyone can insert comment reactions" ON public.comment_reactions FOR INSERT WITH CHECK (true);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Anyone can delete own comment reactions') THEN
        CREATE POLICY "Anyone can delete own comment reactions" ON public.comment_reactions FOR DELETE USING (true);
    END IF;
END $$;

-- Function to handle atomic reaction toggle
CREATE OR REPLACE FUNCTION public.react_to_comment(
    target_comment_id UUID,
    user_fingerprint TEXT,
    reaction_kind TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    reaction_exists BOOLEAN;
    new_count INTEGER;
    result JSONB;
    col_name TEXT;
BEGIN
    -- Map kind to column name
    col_name := reaction_kind || 's_count';

    -- Check if reaction already exists
    SELECT EXISTS (
        SELECT 1 FROM public.comment_reactions 
        WHERE comment_id = target_comment_id 
        AND fingerprint = user_fingerprint 
        AND reaction_type = reaction_kind
    ) INTO reaction_exists;

    IF reaction_exists THEN
        -- Remove reaction
        DELETE FROM public.comment_reactions 
        WHERE comment_id = target_comment_id 
        AND fingerprint = user_fingerprint 
        AND reaction_type = reaction_kind;

        -- Decrement count
        EXECUTE format('UPDATE public.comments SET %I = GREATEST(0, %I - 1) WHERE id = $1 RETURNING %I', 
            col_name, col_name, col_name)
        USING target_comment_id
        INTO new_count;

        result := jsonb_build_object('action', 'removed', 'count', new_count);
    ELSE
        -- Add reaction
        INSERT INTO public.comment_reactions (comment_id, fingerprint, reaction_type)
        VALUES (target_comment_id, user_fingerprint, reaction_kind);

        -- Increment count
        EXECUTE format('UPDATE public.comments SET %I = %I + 1 WHERE id = $1 RETURNING %I', 
            col_name, col_name, col_name)
        USING target_comment_id
        INTO new_count;

        result := jsonb_build_object('action', 'added', 'count', new_count);
    END IF;

    RETURN result;
END;
$$;
