-- حذف النسخة التي تستقبل text (النسخة المكررة)
DROP FUNCTION IF EXISTS public.react_to_comment(text, text, text);

-- الآن يوجد فقط النسخة التي تستقبل UUID
-- public.react_to_comment(uuid, text, text)

-- التحقق من أن الدالة المتبقية تعمل بشكل صحيح
COMMENT ON FUNCTION public.react_to_comment(uuid, text, text) IS 'دالة التفاعل مع التعليقات - تستقبل UUID فقط';