-- Ensure tables are public and have proper policies
GRANT SELECT ON public.campaign_stats TO anon;
GRANT SELECT, INSERT ON public.votes TO anon;
GRANT SELECT, INSERT ON public.comments TO anon;

-- Explicitly enable Realtime for tables
ALTER TABLE public.campaign_stats REPLICA IDENTITY FULL;
ALTER TABLE public.votes REPLICA IDENTITY FULL;
ALTER TABLE public.comments REPLICA IDENTITY FULL;

-- Ensure Publication includes all
DROP PUBLICATION IF EXISTS supabase_realtime;
CREATE PUBLICATION supabase_realtime FOR TABLE campaign_stats, votes, comments;
