-- Add new reaction columns to comments table
ALTER TABLE public.comments 
ADD COLUMN IF NOT EXISTS broken_heart_count INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS sad_count INTEGER DEFAULT 0;

-- Update the react_to_comment function to handle more reaction types and use correct naming
CREATE OR REPLACE FUNCTION public.react_to_comment(
    target_comment_id UUID,
    user_fingerprint TEXT,
    reaction_kind TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    reaction_exists BOOLEAN;
    new_count INTEGER;
    result JSONB;
    col_name TEXT;
BEGIN
    -- Map kind to column name
    -- For 'like', 'heart', 'broken_heart', 'sad'
    IF reaction_kind = 'like' THEN col_name := 'likes_count';
    ELSIF reaction_kind = 'heart' THEN col_name := 'hearts_count';
    ELSIF reaction_kind = 'fire' THEN col_name := 'fire_count';
    ELSIF reaction_kind = 'broken_heart' THEN col_name := 'broken_heart_count';
    ELSIF reaction_kind = 'sad' THEN col_name := 'sad_count';
    ELSE 
        RAISE EXCEPTION 'Invalid reaction kind: %', reaction_kind;
    END IF;

    -- Check if reaction already exists
    SELECT EXISTS (
        SELECT 1 FROM public.comment_reactions 
        WHERE comment_id = target_comment_id 
        AND fingerprint = user_fingerprint 
        AND reaction_type = reaction_kind
    ) INTO reaction_exists;

    IF reaction_exists THEN
        -- Remove reaction
        DELETE FROM public.comment_reactions 
        WHERE comment_id = target_comment_id 
        AND fingerprint = user_fingerprint 
        AND reaction_type = reaction_kind;

        -- Decrement count
        EXECUTE format('UPDATE public.comments SET %I = GREATEST(0, %I - 1) WHERE id = $1 RETURNING %I', 
            col_name, col_name, col_name)
        USING target_comment_id
        INTO new_count;

        result := jsonb_build_object('action', 'removed', 'count', new_count);
    ELSE
        -- Add reaction
        INSERT INTO public.comment_reactions (comment_id, fingerprint, reaction_type)
        VALUES (target_comment_id, user_fingerprint, reaction_kind);

        -- Increment count
        EXECUTE format('UPDATE public.comments SET %I = %I + 1 WHERE id = $1 RETURNING %I', 
            col_name, col_name, col_name)
        USING target_comment_id
        INTO new_count;

        result := jsonb_build_object('action', 'added', 'count', new_count);
    END IF;

    RETURN result;
END;
$$;
