-- Enable RLS for forum_posts
ALTER TABLE forum_posts ENABLE ROW LEVEL SECURITY;

-- Allow public select on forum_posts
CREATE POLICY "Allow public select on forum_posts" 
ON forum_posts FOR SELECT 
TO anon 
USING (true);

-- Allow public insert on forum_posts
CREATE POLICY "Allow public insert on forum_posts" 
ON forum_posts FOR INSERT 
TO anon 
WITH CHECK (true);

-- Allow public update on forum_posts (for likes)
CREATE POLICY "Allow public update on forum_posts" 
ON forum_posts FOR UPDATE 
TO anon 
USING (true)
WITH CHECK (true);
