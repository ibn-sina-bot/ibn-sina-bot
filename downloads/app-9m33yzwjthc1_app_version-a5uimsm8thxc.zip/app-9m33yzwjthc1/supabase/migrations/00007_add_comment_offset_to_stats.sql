ALTER TABLE campaign_stats ADD COLUMN comment_offset INTEGER DEFAULT 0;
UPDATE campaign_stats SET comment_offset = 6948 WHERE id = 1;