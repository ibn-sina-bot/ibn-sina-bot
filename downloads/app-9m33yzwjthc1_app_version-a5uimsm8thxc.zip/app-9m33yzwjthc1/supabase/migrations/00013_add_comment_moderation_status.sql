-- Add moderation status to comments table
ALTER TABLE comments ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected'));

-- Add moderation reason column
ALTER TABLE comments ADD COLUMN IF NOT EXISTS moderation_reason TEXT;

-- Create index for faster filtering by status
CREATE INDEX IF NOT EXISTS idx_comments_status ON comments(status);

-- Update existing comments to approved status
UPDATE comments SET status = 'approved' WHERE status IS NULL OR status = 'pending';