-- Ensure the table exists and has the row
INSERT INTO campaign_stats (id, vote_count) VALUES (1, 0) ON CONFLICT (id) DO NOTHING;

-- Re-create the function with explicit schema
CREATE OR REPLACE FUNCTION public.increment_vote_count()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE public.campaign_stats SET vote_count = vote_count + 1 WHERE id = 1;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop and re-create trigger
DROP TRIGGER IF EXISTS on_vote_added ON public.votes;
CREATE TRIGGER on_vote_added
AFTER INSERT ON public.votes
FOR EACH ROW
EXECUTE FUNCTION public.increment_vote_count();

-- Recalculate current count just in case
UPDATE public.campaign_stats 
SET vote_count = (SELECT count(*) FROM public.votes) 
WHERE id = 1;
