-- Add fingerprint column to votes for better tracking
ALTER TABLE votes ADD COLUMN IF NOT EXISTS fingerprint TEXT;

-- Create a table to track rate limiting per fingerprint
CREATE TABLE IF NOT EXISTS vote_rate_limit (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    fingerprint TEXT NOT NULL,
    last_attempt TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    count INTEGER DEFAULT 1
);

-- Index for performance
CREATE INDEX IF NOT EXISTS idx_vote_rate_limit_fingerprint ON vote_rate_limit(fingerprint);

-- Policy to allow anonymous read/insert for vote_rate_limit (internal use mostly but frontend needs to check)
ALTER TABLE vote_rate_limit ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can see their own rate limits" ON vote_rate_limit FOR SELECT USING (true);
CREATE POLICY "Public can insert/update rate limits" ON vote_rate_limit FOR INSERT WITH CHECK (true);
CREATE POLICY "Public can update their own rate limit" ON vote_rate_limit FOR UPDATE USING (true);

-- Update RLS for votes to include fingerprint check (optional, but good for data integrity)
-- Existing policies might need update if we want to enforce fingerprint uniqueness at DB level
-- For now, we will use a UNIQUE constraint on fingerprint to prevent duplicate votes
-- Note: This might be too strict if multiple people share a device, but for bot protection it is good.
-- However, user requested "protection" so we will add it.
-- We will handle the "one vote per fingerprint" logic.

-- First, clear existing duplicates if any (just in case)
-- Actually, since we are adding a UNIQUE constraint, we should be careful.
-- Let's just use it as a tracking field for now and enforce logic in API.
