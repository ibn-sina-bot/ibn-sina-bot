-- Create comments table
CREATE TABLE comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  governorate TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create votes table (to track unique entries, even if anonymous)
CREATE TABLE votes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create stats table for quick counter access
CREATE TABLE campaign_stats (
  id INT PRIMARY KEY DEFAULT 1,
  vote_count INT DEFAULT 0
);

-- Initialize stats
INSERT INTO campaign_stats (id, vote_count) VALUES (1, 0) ON CONFLICT (id) DO NOTHING;

-- Function to increment vote count
CREATE OR REPLACE FUNCTION increment_vote_count()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE campaign_stats SET vote_count = vote_count + 1 WHERE id = 1;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to increment vote count on new vote
CREATE TRIGGER on_vote_added
AFTER INSERT ON votes
FOR EACH ROW
EXECUTE FUNCTION increment_vote_count();

-- RLS Policies (Public access)
ALTER TABLE comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE votes ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaign_stats ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public select on comments" ON comments FOR SELECT TO anon USING (true);
CREATE POLICY "Allow public insert on comments" ON comments FOR INSERT TO anon WITH CHECK (true);

CREATE POLICY "Allow public select on votes" ON votes FOR SELECT TO anon USING (true);
CREATE POLICY "Allow public insert on votes" ON votes FOR INSERT TO anon WITH CHECK (true);

CREATE POLICY "Allow public select on campaign_stats" ON campaign_stats FOR SELECT TO anon USING (true);

-- Enable Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE campaign_stats;
ALTER PUBLICATION supabase_realtime ADD TABLE comments;
