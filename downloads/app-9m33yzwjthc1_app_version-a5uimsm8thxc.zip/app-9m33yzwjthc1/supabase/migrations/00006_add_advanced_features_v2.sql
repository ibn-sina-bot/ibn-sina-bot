-- Polls
CREATE TABLE IF NOT EXISTS polls (
  id BIGSERIAL PRIMARY KEY,
  question TEXT NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS poll_options (
  id BIGSERIAL PRIMARY KEY,
  poll_id BIGINT REFERENCES polls(id) ON DELETE CASCADE,
  option_text TEXT NOT NULL,
  vote_count INT DEFAULT 0
);

-- Discussion Forum
CREATE TABLE IF NOT EXISTS forum_posts (
  id BIGSERIAL PRIMARY KEY,
  user_name TEXT DEFAULT 'مواطن مصري',
  content TEXT NOT NULL,
  likes INT DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Changelog / Official Updates
CREATE TABLE IF NOT EXISTS campaign_updates (
  id BIGSERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  update_date DATE DEFAULT CURRENT_DATE,
  impact_level TEXT DEFAULT 'info', -- success, warning, info
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Expert Articles
CREATE TABLE IF NOT EXISTS expert_articles (
  id BIGSERIAL PRIMARY KEY,
  author_name TEXT NOT NULL,
  title TEXT NOT NULL,
  summary TEXT NOT NULL,
  content TEXT NOT NULL,
  video_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Seed Data
INSERT INTO polls (question) VALUES ('ما هي أكثر شركة إنترنت تعاني من خدماتها حالياً؟');
INSERT INTO poll_options (poll_id, option_text) VALUES 
(1, 'المصرية للاتصالات (WE)'),
(1, 'فودافون مصر'),
(1, 'أورنج مصر'),
(1, 'اتصالات من e&');

INSERT INTO campaign_updates (title, content, impact_level) VALUES 
('تجاوز 10,000 صوت', 'بفضل دعمكم، تخطينا اليوم حاجز الـ 10 آلاف صوت في أول 24 ساعة!', 'success'),
('تغطية إعلامية جديدة', 'أحد المواقع التقنية الكبرى تناول مطالب الحملة في مقال مفصل.', 'info');

INSERT INTO expert_articles (author_name, title, summary, content) VALUES 
('م. محمد خالد', 'الإنترنت غير المحدود: ضرورة اقتصادية', 'شرح لكيفية تأثير نظام الباقات سلباً على الناتج المحلي المصري.', 'محتوى المقال المفصل هنا...');
