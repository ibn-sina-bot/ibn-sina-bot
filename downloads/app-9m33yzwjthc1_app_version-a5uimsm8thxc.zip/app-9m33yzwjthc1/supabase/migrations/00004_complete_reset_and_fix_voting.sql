-- Drop everything and start fresh
DROP TRIGGER IF EXISTS on_vote_added ON votes;
DROP FUNCTION IF EXISTS increment_vote_count();

-- Recreate the function with better error handling
CREATE OR REPLACE FUNCTION increment_vote_count()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql AS $$
BEGIN
  UPDATE campaign_stats 
  SET vote_count = vote_count + 1 
  WHERE id = 1;
  
  -- If no row was updated, insert it
  IF NOT FOUND THEN
    INSERT INTO campaign_stats (id, vote_count) 
    VALUES (1, 1)
    ON CONFLICT (id) DO UPDATE 
    SET vote_count = campaign_stats.vote_count + 1;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create the trigger
CREATE TRIGGER on_vote_added
  AFTER INSERT ON votes
  FOR EACH ROW
  EXECUTE FUNCTION increment_vote_count();

-- Sync current count
UPDATE campaign_stats 
SET vote_count = (SELECT COUNT(*) FROM votes) 
WHERE id = 1;

-- Ensure the row exists
INSERT INTO campaign_stats (id, vote_count) 
VALUES (1, (SELECT COUNT(*) FROM votes))
ON CONFLICT (id) 
DO UPDATE SET vote_count = (SELECT COUNT(*) FROM votes);

-- Verify
SELECT 
  (SELECT COUNT(*) FROM votes) as actual_votes,
  (SELECT vote_count FROM campaign_stats WHERE id = 1) as displayed_count;
