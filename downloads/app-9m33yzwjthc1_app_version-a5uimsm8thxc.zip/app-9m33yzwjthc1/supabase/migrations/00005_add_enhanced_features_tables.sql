-- International Comparisons
CREATE TABLE IF NOT EXISTS international_comparisons (
  id BIGSERIAL PRIMARY KEY,
  country_name TEXT NOT NULL,
  country_code TEXT NOT NULL,
  avg_speed TEXT NOT NULL,
  avg_price TEXT NOT NULL,
  is_unlimited BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- FAQs
CREATE TABLE IF NOT EXISTS faqs (
  id BIGSERIAL PRIMARY KEY,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  category TEXT DEFAULT 'general',
  display_order INT DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Testimonials / Success Stories
CREATE TABLE IF NOT EXISTS testimonials (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  role TEXT NOT NULL,
  story TEXT NOT NULL,
  avatar_url TEXT,
  impact_score INT DEFAULT 5,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Facts / Did You Know
CREATE TABLE IF NOT EXISTS campaign_facts (
  id BIGSERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  icon TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Seed Data
INSERT INTO international_comparisons (country_name, country_code, avg_speed, avg_price, is_unlimited) VALUES
('مصر 🇪🇬', 'EG', '30 Mbps', '10$', FALSE),
('الإمارات 🇦🇪', 'AE', '250 Mbps', '40$', TRUE),
('السعودية 🇸🇦', 'SA', '150 Mbps', '35$', TRUE),
('فرنسا 🇫🇷', 'FR', '400 Mbps', '25$', TRUE),
('الولايات المتحدة 🇺🇸', 'US', '200 Mbps', '50$', TRUE);

INSERT INTO faqs (question, answer, display_order) VALUES
('لماذا نطالب بإنترنت غير محدود؟', 'لأن الإنترنت أصبح عصب الحياة للتعليم، العمل الحر، والترفيه، ونظام الباقات يعيق التقدم الرقمي لمصر.', 1),
('هل البنية التحتية تتحمل؟', 'نعم، استثمارات الدولة في الكابلات البحرية والداخلية كبيرة، والإنترنت غير المحدود هو الاستغلال الأمثل لهذه البنية.', 2),
('كيف أساهم في الحملة؟', 'من خلال التصويت، كتابة تعليقك، ومشاركة الرابط على منصات التواصل الاجتماعي.', 3);

INSERT INTO testimonials (name, role, story) VALUES
('أحمد محمود', 'مبرمج حر', 'أضطر لشحن باقات إضافية مرتين في الشهر لرفع أكواد العملاء، وهذا يقلل من صافي ربحي بشكل كبير.'),
('سارة علي', 'طالبة جامعية', 'المحاضرات المسجلة تستهلك الباقة في أول أسبوع، مما يصعب علي متابعة دراستي عن بعد.');

INSERT INTO campaign_facts (title, content, icon) VALUES
('حقيقة 1', 'مصر تمتلك أكبر عدد من مستخدمي الإنترنت في أفريقيا، لكنها من الأقل في توفير سعات غير محدودة.', '📊'),
('حقيقة 2', 'العمل الحر يوفر مليارات الدولارات سنوياً لمصر، والإنترنت هو الأداة الأساسية لهؤلاء الشباب.', '💰');
