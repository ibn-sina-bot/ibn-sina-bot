-- Update the RPC function to handle TEXT id and cast it, which is safer for some clients
CREATE OR REPLACE FUNCTION public.react_to_comment(
    target_comment_id TEXT,
    user_fingerprint TEXT,
    reaction_kind TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    reaction_exists BOOLEAN;
    new_count INTEGER;
    result JSONB;
    col_name TEXT;
    target_uuid UUID;
BEGIN
    -- Try casting to UUID
    BEGIN
        target_uuid := target_comment_id::UUID;
    EXCEPTION WHEN OTHERS THEN
        RAISE EXCEPTION 'Invalid comment ID format: %', target_comment_id;
    END;

    -- Map kind to column name
    CASE reaction_kind
        WHEN 'like' THEN col_name := 'likes_count';
        WHEN 'heart' THEN col_name := 'hearts_count';
        WHEN 'fire' THEN col_name := 'fire_count';
        WHEN 'broken_heart' THEN col_name := 'broken_heart_count';
        WHEN 'sad' THEN col_name := 'sad_count';
        ELSE 
            RAISE EXCEPTION 'Invalid reaction kind: %', reaction_kind;
    END CASE;

    -- Check if reaction already exists
    SELECT EXISTS (
        SELECT 1 FROM public.comment_reactions 
        WHERE comment_id = target_uuid 
        AND fingerprint = user_fingerprint 
        AND reaction_type = reaction_kind
    ) INTO reaction_exists;

    IF reaction_exists THEN
        -- Remove reaction
        DELETE FROM public.comment_reactions 
        WHERE comment_id = target_uuid 
        AND fingerprint = user_fingerprint 
        AND reaction_type = reaction_kind;

        -- Decrement count
        EXECUTE format('UPDATE public.comments SET %I = GREATEST(0, COALESCE(%I, 0) - 1) WHERE id = $1 RETURNING %I', 
            col_name, col_name, col_name)
        USING target_uuid
        INTO new_count;

        result := jsonb_build_object('action', 'removed', 'count', COALESCE(new_count, 0));
    ELSE
        -- Add reaction
        INSERT INTO public.comment_reactions (comment_id, fingerprint, reaction_type)
        VALUES (target_uuid, user_fingerprint, reaction_kind);

        -- Increment count
        EXECUTE format('UPDATE public.comments SET %I = COALESCE(%I, 0) + 1 WHERE id = $1 RETURNING %I', 
            col_name, col_name, col_name)
        USING target_uuid
        INTO new_count;

        result := jsonb_build_object('action', 'added', 'count', COALESCE(new_count, 0));
    END IF;

    RETURN result;
END;
$$;
