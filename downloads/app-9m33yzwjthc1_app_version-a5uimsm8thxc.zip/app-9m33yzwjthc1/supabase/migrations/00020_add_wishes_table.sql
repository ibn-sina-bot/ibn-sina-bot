-- إنشاء جدول الأمنيات الرقمية
CREATE TABLE IF NOT EXISTS wishes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  content TEXT NOT NULL,
  author_name TEXT DEFAULT 'مواطن مصري',
  governorate TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  status TEXT DEFAULT 'approved' CHECK (status IN ('pending', 'approved', 'rejected')),
  likes_count INTEGER DEFAULT 0
);

-- إنشاء فهرس للبحث السريع
CREATE INDEX IF NOT EXISTS idx_wishes_created_at ON wishes(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_wishes_status ON wishes(status);

-- سياسات الأمان: السماح للجميع بالقراءة
CREATE POLICY "الجميع يمكنهم قراءة الأمنيات المعتمدة"
  ON wishes FOR SELECT
  USING (status = 'approved');

-- السماح للجميع بإضافة أمنية جديدة
CREATE POLICY "الجميع يمكنهم إضافة أمنية"
  ON wishes FOR INSERT
  WITH CHECK (true);

-- تفعيل RLS
ALTER TABLE wishes ENABLE ROW LEVEL SECURITY;