# دليل إعداد نطاق مخصص للموقع
# Custom Domain Setup Guide

## 🌐 المشكلة الحالية

**الرابط الحالي**: `app-9m33yzwjthc1.appmedo.com`

هذا رابط تقني من منصة الاستضافة، وليس احترافياً للمشاركة على وسائل التواصل الاجتماعي أو محركات البحث.

---

## ✅ الحل: نطاق مخصص (Custom Domain)

### الخيارات المقترحة:

#### 🇪🇬 نطاقات عربية مقترحة:
1. `internet-unlimited-egypt.com`
2. `unlimited-internet-egypt.com`
3. `egypt-unlimited-internet.com`
4. `internet-unlimited.eg` (نطاق مصري)
5. `unlimited-internet.eg`

#### 🌍 نطاقات إنجليزية مقترحة:
1. `unlimitedinternetegypt.com`
2. `egyptunlimitedinternet.com`
3. `internetunlimitedeg.com`

#### 💡 نطاقات قصيرة وسهلة:
1. `unltd-eg.com`
2. `inet-egypt.com`
3. `eg-unlimited.com`

---

## 📋 خطوات الحصول على نطاق مخصص

### الخطوة 1: شراء النطاق (Domain Purchase)

#### أفضل مواقع شراء النطاقات:

**1. Namecheap** (موصى به - رخيص وسهل)
- الموقع: https://www.namecheap.com
- السعر: ~$10-15/سنة
- المميزات: 
  - ✅ أسعار منافسة
  - ✅ خصوصية مجانية (WHOIS Privacy)
  - ✅ واجهة سهلة الاستخدام
  - ✅ دعم فني ممتاز

**2. GoDaddy**
- الموقع: https://www.godaddy.com
- السعر: ~$12-20/سنة
- المميزات:
  - ✅ شهرة عالمية
  - ✅ دعم عربي
  - ✅ خيارات دفع متعددة

**3. Google Domains** (الآن Squarespace Domains)
- الموقع: https://domains.google
- السعر: ~$12/سنة
- المميزات:
  - ✅ بسيط وموثوق
  - ✅ تكامل مع خدمات Google
  - ✅ خصوصية مجانية

**4. Cloudflare Registrar** (الأرخص)
- الموقع: https://www.cloudflare.com/products/registrar/
- السعر: ~$8-10/سنة (بدون هامش ربح)
- المميزات:
  - ✅ أرخص الأسعار
  - ✅ حماية DDoS مجانية
  - ✅ SSL مجاني
  - ✅ DNS سريع

#### خطوات الشراء:
1. اذهب إلى أحد المواقع أعلاه
2. ابحث عن النطاق المطلوب (مثلاً: `unlimited-internet-egypt.com`)
3. تحقق من التوفر
4. أضف إلى السلة واشتري (بطاقة ائتمان أو PayPal)
5. أكمل التسجيل

---

### الخطوة 2: إعداد DNS (Domain Configuration)

بعد شراء النطاق، يجب ربطه بالموقع الحالي:

#### الطريقة 1: استخدام CNAME Record (موصى به)

1. اذهب إلى لوحة تحكم النطاق (Domain Control Panel)
2. ابحث عن "DNS Settings" أو "DNS Management"
3. أضف CNAME Record جديد:

```
Type: CNAME
Name: www (أو @ للنطاق الرئيسي)
Value: app-9m33yzwjthc1.appmedo.com
TTL: 3600 (أو Auto)
```

4. احفظ التغييرات

#### الطريقة 2: استخدام A Record

إذا كان لديك IP Address للموقع:

```
Type: A
Name: @ (للنطاق الرئيسي)
Value: [IP Address]
TTL: 3600
```

---

### الخطوة 3: ربط النطاق بالمنصة (Platform Configuration)

**مهم جداً**: يجب إخبار منصة الاستضافة (appmedo.com) بالنطاق الجديد.

#### خطوات الربط:

1. **تواصل مع دعم المنصة**:
   - أرسل رسالة إلى دعم appmedo.com
   - اطلب ربط النطاق المخصص بالتطبيق
   - قدم المعلومات التالية:
     * اسم التطبيق: `app-9m33yzwjthc1`
     * النطاق الجديد: `unlimited-internet-egypt.com` (مثال)
     * DNS Records المضافة

2. **انتظر التفعيل**:
   - عادة يستغرق 24-48 ساعة
   - ستتلقى تأكيد عند اكتمال الربط

3. **تحقق من SSL**:
   - تأكد من أن الموقع يعمل عبر HTTPS
   - المنصة عادة توفر SSL تلقائياً

---

### الخطوة 4: تحديث الموقع (Update Website)

بعد تفعيل النطاق، يجب تحديث الروابط في الموقع:

#### الملفات التي تحتاج تحديث:

**1. index.html**
```html
<!-- قبل -->
<link rel="canonical" href="https://app-9m33yzwjthc1.appmedo.com/" />
<meta property="og:url" content="https://app-9m33yzwjthc1.appmedo.com/" />

<!-- بعد -->
<link rel="canonical" href="https://unlimited-internet-egypt.com/" />
<meta property="og:url" content="https://unlimited-internet-egypt.com/" />
```

**2. sitemap.xml**
```xml
<!-- قبل -->
<loc>https://app-9m33yzwjthc1.appmedo.com/</loc>

<!-- بعد -->
<loc>https://unlimited-internet-egypt.com/</loc>
```

**3. robots.txt**
```
# قبل
Sitemap: https://app-9m33yzwjthc1.appmedo.com/sitemap.xml

# بعد
Sitemap: https://unlimited-internet-egypt.com/sitemap.xml
```

**4. Schema Markup (JSON-LD)**
```json
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "url": "https://unlimited-internet-egypt.com/"
}
```

---

## 🚀 الحل المؤقت: تحسين ظهور الاسم

حتى تحصل على نطاق مخصص، يمكن تحسين ظهور اسم الموقع بدلاً من الرابط:

### ✅ ما تم تطبيقه بالفعل:

1. **عنوان الموقع محسّن**:
   ```html
   <title>إنترنت غير محدود في مصر | موقع تصويت الإنترنت ورأي الناس 🇪🇬</title>
   ```

2. **Open Graph Tags محسّنة**:
   ```html
   <meta property="og:site_name" content="Unlimited Internet - إنترنت غير محدود في مصر" />
   <meta property="og:title" content="إنترنت غير محدود في مصر | موقع تصويت الإنترنت 🇪🇬" />
   ```

3. **Schema Markup محسّن**:
   ```json
   {
     "name": "Unlimited Internet - إنترنت غير محدود في مصر",
     "alternateName": "موقع تصويت الإنترنت غير المحدود في مصر"
   }
   ```

### النتيجة:
- ✅ في نتائج البحث: يظهر **"إنترنت غير محدود في مصر"** بدلاً من الرابط
- ✅ في Facebook/Twitter: يظهر **"Unlimited Internet"** كاسم الموقع
- ✅ في Google: يظهر العنوان المحسّن مع الوصف

---

## 📊 مقارنة الخيارات

| الخيار | التكلفة | الوقت | الاحترافية | التوصية |
|--------|---------|-------|------------|----------|
| **نطاق مخصص** | $10-15/سنة | 2-3 أيام | ⭐⭐⭐⭐⭐ | ✅ موصى به بشدة |
| **تحسين SEO** | مجاني | فوري | ⭐⭐⭐ | ✅ حل مؤقت |
| **subdomain مخصص** | مجاني | 1 يوم | ⭐⭐⭐⭐ | ⚠️ يعتمد على المنصة |

---

## 🎯 التوصية النهائية

### للحصول على أفضل نتيجة:

1. **قصير المدى** (الآن):
   - ✅ استخدم التحسينات الحالية (مطبقة بالفعل)
   - ✅ شارك الموقع باستخدام العنوان المحسّن
   - ✅ اعتمد على SEO لإظهار الاسم بدلاً من الرابط

2. **متوسط المدى** (خلال أسبوع):
   - ✅ اشتري نطاق مخصص من Namecheap أو Cloudflare
   - ✅ اربطه بالموقع الحالي
   - ✅ حدّث جميع الروابط

3. **طويل المدى** (بعد شهر):
   - ✅ راقب أداء النطاق الجديد
   - ✅ حدّث Google Search Console
   - ✅ أعد إرسال sitemap.xml

---

## 📞 الدعم والمساعدة

### إذا احتجت مساعدة في:

**1. اختيار النطاق**:
- تحقق من التوفر على: https://www.namecheap.com
- اختر اسم قصير وسهل التذكر
- تجنب الأرقام والرموز

**2. إعداد DNS**:
- اتبع دليل المنصة (Namecheap/GoDaddy)
- استخدم CNAME Record
- انتظر 24-48 ساعة للتفعيل

**3. ربط النطاق بالمنصة**:
- تواصل مع دعم appmedo.com
- قدم معلومات النطاق
- اطلب تفعيل SSL

---

## ✅ الخلاصة

**الوضع الحالي**:
- ✅ الموقع يعمل بشكل ممتاز
- ✅ SEO محسّن بالكامل
- ✅ الاسم يظهر بشكل احترافي في نتائج البحث
- ⚠️ الرابط تقني وطويل (app-9m33yzwjthc1.appmedo.com)

**الحل الموصى به**:
1. **الآن**: استخدم الموقع كما هو (SEO محسّن)
2. **خلال أسبوع**: اشتري نطاق مخصص (~$10)
3. **بعد الربط**: حدّث جميع الروابط

**النتيجة المتوقعة**:
- ✅ رابط احترافي وقصير
- ✅ سهل المشاركة والتذكر
- ✅ مصداقية أعلى
- ✅ SEO أفضل

---

**آخر تحديث**: 2026-02-13  
**الإصدار**: 1.0  
**الحالة**: ✅ جاهز للتطبيق
