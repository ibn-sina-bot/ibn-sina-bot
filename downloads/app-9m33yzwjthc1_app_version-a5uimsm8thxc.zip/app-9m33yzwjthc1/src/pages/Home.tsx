import React, { useState, useEffect, useRef, Suspense } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Link } from 'react-router-dom';
import { 
  Globe, 
  MapPin, 
  MessageSquare, 
  Share2, 
  TrendingUp, 
  Laptop, 
  GraduationCap, 
  Gamepad2, 
  Zap, 
  CheckCircle2,
  Copy,
  Facebook,
  Twitter,
  Send,
  Loader2,
  Gauge,
  ExternalLink,
  Heart,
  ThumbsUp,
  Flame,
  Search,
  Filter,
  ArrowRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { toast } from 'sonner';
import { generateFingerprint } from '@/lib/utils';

import { 
  getCampaignStats, 
  castVote, 
  getComments, 
  getCommentsCount,
  reactToComment,
  getUserReactions,
  addComment, 
  getForumPosts,
  addForumPost,
  likeForumPost,
  subscribeToForumPosts,
  subscribeToStats, 
  subscribeToComments,
  subscribeToVotes,
  getInternationalComparisons,
  getFAQs,
  getTestimonials,
  getFacts,
  getCampaignUpdates,
  updatePresence,
  getActiveUsersCount,
  getLatestGovernorate,
  getGovernorateDistribution,
  getLeaderboard,
  getNetworkAnalytics,
  getDataUsageAnalytics,
  awardSharePoints,
  Comment,
  CampaignStats,
  InternationalComparison,
  FAQ,
  Testimonial,
  Fact,
  CampaignUpdate,
  ForumPost
} from '@/db/api';
import { ComparisonTable } from '@/components/enhanced/ComparisonTable';
import { RealSpeedTest } from '@/components/enhanced/RealSpeedTest';
import { HumanVerification } from '@/components/enhanced/HumanVerification';
import { PostVoteSurvey } from '@/components/enhanced/PostVoteSurvey';
import { UpdateNotification } from '@/components/enhanced/UpdateNotification';
import { BottomNav } from '@/components/layout/BottomNav';
import { AIChat } from '@/components/ai/AIChat';

// Lazy load non-critical heavy components for performance
const NetworkAnalytics = React.lazy(() => import('@/components/enhanced/NetworkAnalytics').then(m => ({ default: m.NetworkAnalytics })));
const PointsLeaderboard = React.lazy(() => import('@/components/enhanced/PointsLeaderboard').then(m => ({ default: m.PointsLeaderboard })));
const SupportCardGenerator = React.lazy(() => import('@/components/enhanced/SupportCardGenerator').then(m => ({ default: m.SupportCardGenerator })));
const CampaignMap = React.lazy(() => import('@/components/enhanced/CampaignMap').then(m => ({ default: m.CampaignMap })));
const FAQSection = React.lazy(() => import('@/components/enhanced/FAQSection').then(m => ({ default: m.FAQSection })));
const Testimonials = React.lazy(() => import('@/components/enhanced/Testimonials').then(m => ({ default: m.Testimonials })));
const LiveDashboard = React.lazy(() => import('@/components/enhanced/LiveDashboard').then(m => ({ default: m.LiveDashboard })));
const ProfileFrameGenerator = React.lazy(() => import('@/components/enhanced/ProfileFrameGenerator').then(m => ({ default: m.ProfileFrameGenerator })));
const CampaignChangelog = React.lazy(() => import('@/components/enhanced/CampaignChangelog').then(m => ({ default: m.CampaignChangelog })));
const GamificationGuide = React.lazy(() => import('@/components/enhanced/GamificationGuide').then(m => ({ default: m.GamificationGuide })));
const GovernoratesLeaderboard = React.lazy(() => import('@/components/enhanced/GovernoratesLeaderboard').then(m => ({ default: m.GovernoratesLeaderboard })));
const GlobalSuccessStories = React.lazy(() => import('@/components/enhanced/GlobalSuccessStories').then(m => ({ default: m.GlobalSuccessStories })));
const FutureRoadmap = React.lazy(() => import('@/components/enhanced/FutureRoadmap').then(m => ({ default: m.FutureRoadmap })));
const FloatingLiveActivity = React.lazy(() => import('@/components/enhanced/FloatingLiveActivity').then(m => ({ default: m.FloatingLiveActivity })));
const ModerationOverlay = React.lazy(() => import('@/components/moderation/ModerationOverlay').then(m => ({ default: m.ModerationOverlay })));
const UserLevelCard = React.lazy(() => import('@/components/enhanced/UserLevelCard').then(m => ({ default: m.UserLevelCard })));
import { ThemeToggle } from '@/components/ThemeToggle';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Info } from 'lucide-react';
import { SEO } from '@/components/SEO';
import { sanitizeComment, sanitizeName } from '@/lib/security';
// الميزات الجديدة
import { SavingsCalculator } from '@/components/enhanced/SavingsCalculator';
import { WishWall } from '@/components/enhanced/WishWall';
import { TopNavMenu } from '@/components/layout/TopNavMenu';

const GOVERNORATES = [
  "القاهرة", "الجيزة", "الإسكندرية", "الدقهلية", "البحر الأحمر", "البحيرة", 
  "الفيوم", "الغربية", "الإسماعيلية", "المنوفية", "المنيا", "القليوبية", 
  "الوادي الجديد", "السويس", "الشرقية", "دمياط", "بورسعيد", "جنوب سيناء", 
  "كفر الشيخ", "مطروح", "قنا", "شمال سيناء", "سوهاج", "بني سويف", "الأقصر", 
  "أسوان", "أسيوط"
];

const BG_IMAGE = "https://miaoda-site-img.s3cdn.medo.dev/images/KLing_37ecb8cd-2e01-40c5-b7a8-88b835c68781.jpg";
const LOGO_IMAGE = "https://miaoda-conversation-file.s3cdn.medo.dev/user-9il5qwkjedq8/conv-9m33yzwjthc0/20260310/file-a5uac79v6kg0.png";

const ComponentLoading = () => (
  <div className="w-full h-[200px] flex items-center justify-center bg-muted/20 animate-pulse rounded-3xl border border-white/5">
    <Loader2 className="w-6 h-6 animate-spin text-primary" />
  </div>
);

export default function Home() {
  // Loading state
  const [isInitialLoading, setIsInitialLoading] = useState(true);

  const [stats, setStats] = useState<CampaignStats | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [totalCommentsCount, setTotalCommentsCount] = useState(0);
  const [hasMoreToLoad, setHasMoreToLoad] = useState(true);
  const [displayVotes, setDisplayVotes] = useState(0);
  const [displayShares, setDisplayShares] = useState(0);
  const [displayComments, setDisplayComments] = useState(0);
  const [currentPage, setCurrentPage] = useState(0);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [hasVoted, setHasVoted] = useState(false);
  const [isSubmittingVote, setIsSubmittingVote] = useState(false);
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  const [isModerating, setIsModerating] = useState(false);
  const [moderationComplete, setModerationComplete] = useState(false);
  const [activeUsers, setActiveUsers] = useState(1);
  const [latestGov, setLatestGov] = useState('القاهرة');
  const [governorateData, setGovernorateData] = useState<{ name: string; support: number }[]>([]);
  const presenceIdRef = useRef<string | undefined>(undefined);
  const [activeTab, setActiveTab] = useState('updates');

  // New features data
  const [scrollProgress, setScrollProgress] = useState(0);

  const [comparisons, setComparisons] = useState<InternationalComparison[]>([]);
  const [faqs, setFaqs] = useState<FAQ[]>([]);
  const [testimonialsData, setTestimonialsData] = useState<Testimonial[]>([]);
  const [facts, setFacts] = useState<Fact[]>([]);

  // Advanced features data
  const [campaignUpdates, setCampaignUpdates] = useState<CampaignUpdate[]>([]);
  const [forumPosts, setForumPosts] = useState<ForumPost[]>([]);

  // Form states
  const [name, setName] = useState('');
  const [governorate, setGovernorate] = useState('');
  const [recentActivity, setRecentActivity] = useState<{id: string, type: 'vote' | 'comment', text: string}[]>([]);
  const [lastVoteToastTime, setLastVoteToastTime] = useState(0);

  const [commentText, setCommentText] = useState('');
  const [forumName, setForumName] = useState('');
  const [forumContent, setForumContent] = useState('');
  const [isSubmittingPost, setIsSubmittingPost] = useState(false);

  // Comment search/filter states
  const [commentSearchQuery, setCommentSearchQuery] = useState('');
  const [commentFilterGovernorate, setCommentFilterGovernorate] = useState<string>('all');

  // تحديث الأرقام بناءً على البيانات الحقيقية من قاعدة البيانات
  useEffect(() => {
    if (!stats) return;

    setDisplayVotes(stats.vote_count);
    setDisplayShares(stats.shared_count);
    setDisplayComments(totalCommentsCount);
  }, [stats, totalCommentsCount]);

  // Presence Heartbeat
  useEffect(() => {
    const heartbeat = async () => {
      try {
        const id = await updatePresence(presenceIdRef.current);
        if (id) {
          presenceIdRef.current = id;
        }

        const [count, gov] = await Promise.all([
          getActiveUsersCount(),
          getLatestGovernorate()
        ]);
        setActiveUsers(count);
        setLatestGov(gov);
      } catch (error) {
        console.error('Presence error:', error);
      }
    };

    heartbeat();
    const interval = setInterval(heartbeat, 30000); // Heartbeat every 30s
    return () => clearInterval(interval);
  }, []);

  // جلب البيانات الأولية عند تحميل الصفحة
  useEffect(() => {
    console.log('🚀 بدء تحميل الصفحة...');

    const voted = localStorage.getItem('egypt_unlimited_voted_v2');
    if (voted) {
      console.log('✅ المستخدم صوّت مسبقاً');
      setHasVoted(true);
    }

    const initData = async () => {
      console.log('📊 جلب البيانات الأولية...');

      try {
        // Load critical data first
        const statsData = await getCampaignStats();
        setStats(statsData);

        // Set user fingerprint immediately
        const fp = generateFingerprint();
        console.log('🔑 Fingerprint المستخدم:', fp);
        setUserFingerprint(fp);

        // Load essential data for initial render
        const [commentsData, count] = await Promise.all([
          getComments(0, 15),
          getCommentsCount()
        ]);

        setComments(commentsData);
        setTotalCommentsCount(count);
        setHasMoreToLoad(commentsData.length >= 15);

        // جلب تفاعلات المستخدم على التعليقات المحملة
        if (commentsData.length > 0) {
          console.log('🔍 جلب تفاعلات المستخدم للتعليقات:', commentsData.length);
          const reactions = await getUserReactions(fp, commentsData.map(c => c.id));
          console.log('✅ تفاعلات المستخدم:', reactions);
          setUserReactions(reactions);
        }
      } catch (error) {
        console.error('❌ خطأ في تحميل البيانات الأولية:', error);
        toast.error('حدث خطأ أثناء تحميل البيانات، يرجى تحديث الصفحة');
      } finally {
        // Mark initial loading as complete regardless of outcome
        setIsInitialLoading(false);
      }

      // Load remaining data in background (non-blocking) - Increased delay for better perceived performance
      setTimeout(async () => {
        const [
          comparisonsData, 
          faqsData, 
          testimonialsList, 
          factsData, 
          updatesData, 
          distribution, 
          forumData,
          leaderboardData,
          networkData,
          dataUsageData
        ] = await Promise.all([
          getInternationalComparisons(),
          getFAQs(),
          getTestimonials(),
          getFacts(),
          getCampaignUpdates(),
          getGovernorateDistribution(),
          getForumPosts(0, 20),
          getLeaderboard(10),
          getNetworkAnalytics(),
          getDataUsageAnalytics()
        ]);

        setComparisons(comparisonsData);
        setFaqs(faqsData);
        setTestimonialsData(testimonialsList);
        setFacts(factsData);
        setCampaignUpdates(updatesData);
        setGovernorateData(distribution);
        setForumPosts(forumData);
        setLeaderboard(leaderboardData);
        setNetworkStats(networkData);
        setDataUsageStats(dataUsageData);

        console.log('✅ تم جلب جميع البيانات بنجاح');
      }, 1500);

      console.log('✅ تم جلب البيانات الأساسية');
    };

    initData();

    // التعامل مع الروابط المباشرة للتبويبات (مثلاً عند الضغط من القائمة السفلية)
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash === '#speed-section') {
        setActiveTab('speed');
        const element = document.getElementById('speed-section');
        if (element) element.scrollIntoView({ behavior: 'smooth' });
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange(); // Check on initial load

    // الاشتراك في التحديثات اللحظية للعداد والتعليقات
    console.log('📡 بدء الاشتراك في التحديثات اللحظية...');

    const statsSub = subscribeToStats((newStats) => {
      console.log('🔴 تحديث العداد اللحظي:', newStats);
      setStats(newStats);
    });

    // اشتراك إضافي للتصويتات الجديدة لضمان التحديث
    const votesSub = subscribeToVotes(async () => {
      console.log('🔴 صوت جديد! جلب الإحصائيات المحدثة...');
      const freshStats = await getCampaignStats();
      if (freshStats) {
        setStats(freshStats);
      }
      setRecentActivity(prev => [{id: Math.random().toString(), type: 'vote' as const, text: 'صوت جديد تم تسجيله الآن! ✅'}, ...prev].slice(0, 3));

      // إظهار إشعار toast للتصويت الجديد (مع throttle لتجنب الإزعاج)
      const now = Date.now();
      if (now - lastVoteToastTime > 5000) { // إظهار toast كل 5 ثوانٍ على الأكثر
        setLastVoteToastTime(now);
        toast.success('🎉 صوت جديد تم تسجيله للتو!', {
          description: 'مواطن مصري آخر انضم للحملة الآن',
          duration: 3000,
        });
      }
    });

    const commentsSub = subscribeToComments(async (updatedComment) => {
      console.log('🔴 تحديث في التعليقات:', updatedComment);

      setComments((prev) => {
        const index = prev.findIndex(c => c.id === updatedComment.id);
        if (index !== -1) {
          // Update existing comment
          const newComments = [...prev];
          newComments[index] = updatedComment;
          return newComments;
        } else {
          // Add new comment
          setTotalCommentsCount((prevTotal) => prevTotal + 1);
          return [updatedComment, ...prev];
        }
      });

      if (!comments.some(c => c.id === updatedComment.id)) {
        const newDistribution = await getGovernorateDistribution();
        setGovernorateData(newDistribution);
        setRecentActivity(prev => [{id: Math.random().toString(), type: 'comment' as const, text: `تعليق جديد من ${updatedComment.governorate} 📍`}, ...prev].slice(0, 3));
      }
    });

    const forumSub = subscribeToForumPosts((newPost) => {
      console.log('🔴 منشور جديد في المنتدى:', newPost);
      setForumPosts((prev) => [newPost, ...prev]);
    });

    // Throttle scroll event for better performance
    let scrollTimeout: ReturnType<typeof setTimeout> | null = null;

    const handleScroll = () => {
      const scrolled = window.scrollY;
      const maxHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = (scrolled / maxHeight) * 100;
      setScrollProgress(progress);
    };

    const throttledScroll = () => {
      if (scrollTimeout) clearTimeout(scrollTimeout);
      scrollTimeout = setTimeout(handleScroll, 100);
    };

    window.addEventListener('scroll', throttledScroll, { passive: true });

    return () => {
      console.log('🔌 إلغاء الاشتراكات...');
      window.removeEventListener('scroll', throttledScroll);
      if (scrollTimeout) clearTimeout(scrollTimeout);
      statsSub.unsubscribe();
      votesSub.unsubscribe();
      commentsSub.unsubscribe();
      forumSub.unsubscribe();
    };
  }, []);


  const [isVerifying, setIsVerifying] = useState(false);
  const [showResetButton, setShowResetButton] = useState(false);
  const [showSurvey, setShowSurvey] = useState(false);
  const [surveyData, setSurveyData] = useState<{ networkProvider: string; dataUsageType: string } | null>(null);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [networkStats, setNetworkStats] = useState<any[]>([]);
  const [dataUsageStats, setDataUsageStats] = useState<any[]>([]);
  const [userFingerprint, setUserFingerprint] = useState('');
  const [userReactions, setUserReactions] = useState<Record<string, string[]>>({});

  // Developer tool: Press Ctrl+Shift+R to show reset button
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'R') {
        e.preventDefault();
        setShowResetButton(prev => !prev);
        toast.info(showResetButton ? 'أداة إعادة التعيين مخفية' : 'أداة إعادة التعيين ظاهرة الآن');
      }
    };
    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [showResetButton]);

  const handleResetVote = () => {
    localStorage.removeItem('egypt_unlimited_voted_v2');
    localStorage.removeItem('has_voted');
    setHasVoted(false);
    toast.success('تم إعادة تعيين حالة التصويت! يمكنك التصويت مرة أخرى.');
  };

  // دالة التعامل مع عملية التصويت
  const handleVote = () => {
    if (hasVoted) {
      toast.info('شكراً! لقد قمت بالتصويت بالفعل ✅');
      return;
    }
    setIsVerifying(true);
  };

  const onVerified = async () => {
    // Show survey first
    setShowSurvey(true);
  };

  const onSurveyComplete = async (data: { networkProvider: string; dataUsageType: string }) => {
    console.log('🗳️ بدء عملية التصويت بعد التحقق والاستبيان...');
    setIsSubmittingVote(true);
    setSurveyData(data);

    try {
      // Fingerprint implementation
      const fingerprint = generateFingerprint();

      const result = await castVote(fingerprint, data);

      if (result.success) {
        console.log('✅ تم إرسال الصوت بنجاح');
        localStorage.setItem('egypt_unlimited_voted_v2', 'true');
        setHasVoted(true);

        // جلب البيانات فوراً لضمان التحديث السريع للمستخدم
        const freshStats = await getCampaignStats();
        if (freshStats) setStats(freshStats);

        // Refresh analytics
        const [leaderboardData, networkData, dataUsageData] = await Promise.all([
          getLeaderboard(10),
          getNetworkAnalytics(),
          getDataUsageAnalytics()
        ]);
        setLeaderboard(leaderboardData);
        setNetworkStats(networkData);
        setDataUsageStats(dataUsageData);

        // تأثير الاحتفال
        confetti({
          particleCount: 150,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#0A2240', '#4A90E2', '#7ED321', '#FFFFFF']
        });

        toast.success('صوتك وصل! هتكمل إن شاء الله 🚀', {
          duration: 5000,
          position: 'top-center'
        });

        // طلب المشاركة والتعليق بشكل صريح
        toast.info('شكراً لدعمك! يرجى الآن إضافة تعليقك ومشاركة الحملة مع أصدقائك لنصل صوتنا للجميع. ✨', {
          duration: 8000,
          position: 'top-center'
        });

        // توجيه المستخدم للمشاركة والتعليق بعد ثانية
        setTimeout(() => {
          const commentForm = document.getElementById('comment-form');
          if (commentForm) {
            commentForm.scrollIntoView({ behavior: 'smooth' });
          }
        }, 2000);
      } else {
        toast.error(result.error || 'حدث خطأ أثناء التصويت');
      }
    } catch (error) {
      console.error('❌ خطأ في التصويت:', error);
      toast.error('حدث خطأ أثناء الاتصال بالخادم، يرجى المحاولة لاحقاً');
    } finally {
      setIsSubmittingVote(false);
    }
  };

  // دالة إرسال التعليق الجديد
  const handleCommentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) {
      toast.error('يرجى كتابة تعليقك');
      return;
    }
    if (!governorate) {
      toast.error('يرجى اختيار المحافظة');
      return;
    }

    // Sanitize input
    const sanitizedNameText = sanitizeName(name || 'مواطن مصري');
    const sanitizedCommentText = sanitizeComment(commentText);

    if (sanitizedCommentText.trim().length < 3) {
      toast.error('التعليق قصير جداً، اكتب على الأقل 3 حروف');
      return;
    }

    setIsSubmittingComment(true);
    setIsModerating(false);
    setModerationComplete(false);

    try {
      // مرحلة 1: إرسال التعليق
      setIsSubmittingComment(false);
      setIsModerating(true);

      const result = await addComment({
        name: sanitizedNameText,
        governorate,
        content: sanitizedCommentText.trim()
      });

      // مرحلة 2: اكتمال المراجعة
      setIsModerating(false);
      setModerationComplete(true);

      setName('');
      setCommentText('');
      setGovernorate('');

      // عرض رسالة بناءً على نتيجة المراجعة
      if (result.approved) {
        toast.success('✅ تم نشر تعليقك بنجاح!', {
          duration: 5000,
        });
      } else {
        toast.error('❌ لم يتم نشر تعليقك. ' + (result.reason || 'التعليق لا يدعم الحملة'), {
          duration: 7000,
        });
      }

      // إعادة تعيين حالة الاكتمال بعد 3 ثواني
      setTimeout(() => {
        setModerationComplete(false);
      }, 3000);

    } catch (error: any) {
      const errorMsg = error?.message || 'حدث خطأ أثناء إضافة التعليق.';
      toast.error(errorMsg);
      setIsModerating(false);
      setModerationComplete(false);
    } finally {
      setIsSubmittingComment(false);
    }
  };

  const handlePostSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forumContent.trim()) {
      toast.error('يرجى كتابة محتوى المنشور');
      return;
    }

    // Sanitize input
    const sanitizedForumName = sanitizeName(forumName || 'مواطن مصري');
    const sanitizedForumContent = sanitizeComment(forumContent);

    if (sanitizedForumContent.trim().length < 5) {
      toast.error('المنشور قصير جداً، اكتب على الأقل 5 حروف');
      return;
    }

    setIsSubmittingPost(true);
    try {
      await addForumPost({
        user_name: sanitizedForumName,
        content: sanitizedForumContent.trim()
      });
      setForumName('');
      setForumContent('');
      toast.success('تم نشر مشاركتك في المنتدى بنجاح! 🚀');
    } catch (error: any) {
      toast.error(error.message || 'حدث خطأ أثناء النشر.');
    } finally {
      setIsSubmittingPost(false);
    }
  };

  const handleReactToComment = async (commentId: string, type: 'like' | 'heart' | 'broken_heart' | 'sad') => {
    if (!userFingerprint) {
      console.error('❌ لا يوجد fingerprint للمستخدم');
      toast.error('حدث خطأ في التعرف على المستخدم');
      return;
    }

    console.log('🔄 بدء التفاعل:', { commentId, type, userFingerprint });

    try {
      const result = await reactToComment(commentId, userFingerprint, type);

      console.log('✅ نتيجة التفاعل:', result);

      if (!result) {
        console.error('❌ استجابة فارغة من reactToComment');
        toast.error('حدث خطأ أثناء التفاعل');
        return;
      }

      // تحديث حالة تفاعلات المستخدم
      setUserReactions(prev => {
        const newReactions = { ...prev };
        if (!newReactions[commentId]) newReactions[commentId] = [];

        if (result.action === 'added') {
          // إضافة التفاعل
          if (!newReactions[commentId].includes(type)) {
            newReactions[commentId] = [...newReactions[commentId], type];
          }
        } else {
          // إزالة التفاعل
          newReactions[commentId] = newReactions[commentId].filter(r => r !== type);
        }

        console.log('📊 تحديث تفاعلات المستخدم:', newReactions);
        return newReactions;
      });

      // تحديث واجهة المستخدم فوراً
      setComments((prev) => {
        const index = prev.findIndex(c => c.id === commentId);
        if (index === -1) {
          console.warn('⚠️ التعليق غير موجود في القائمة');
          return prev;
        }

        const newComments = [...prev];
        const comment = { ...newComments[index] };

        // تحديد اسم العمود الصحيح
        const countKey = (type === 'broken_heart' ? 'broken_heart_count' : 
                         type === 'sad' ? 'sad_count' : 
                         `${type}s_count`) as keyof Comment;

        console.log(`📈 تحديث العدد: ${countKey} من ${comment[countKey]} إلى ${result.count}`);

        // @ts-ignore
        comment[countKey] = result.count || 0;

        newComments[index] = comment;
        return newComments;
      });

      // تم إزالة رسائل Toast بناءً على طلب المستخدم
      // التفاعل يعمل بصمت مع تحديث العدد فقط

    } catch (error: any) {
      console.error('❌ خطأ في التفاعل:', error);
      console.error('❌ تفاصيل الخطأ:', error?.message || error);
      toast.error(`حدث خطأ: ${error?.message || 'خطأ غير معروف'}`);
    }
  };

  const handleLikePost = async (id: number) => {
    try {
      await likeForumPost(id);
      setForumPosts(prev => prev.map(p => p.id === id ? { ...p, likes: p.likes + 1 } : p));
    } catch (error) {
      console.error('Error liking post:', error);
    }
  };

  const handleLoadMore = async () => {
    setIsLoadingMore(true);
    const nextPage = currentPage + 1;
    try {
      const moreComments = await getComments(nextPage, 15);
      if (moreComments.length === 0) {
        setHasMoreToLoad(false);
        toast.info('وصلت إلى نهاية التعليقات المتاحة حالياً.');
      } else {
        setComments(prev => [...prev, ...moreComments]);
        setCurrentPage(nextPage);
        setHasMoreToLoad(moreComments.length >= 15);

        // جلب تفاعلات المستخدم على التعليقات الجديدة
        if (userFingerprint && moreComments.length > 0) {
          const newReactions = await getUserReactions(userFingerprint, moreComments.map(c => c.id));
          setUserReactions(prev => ({ ...prev, ...newReactions }));
        }
      }
    } catch (error) {
      toast.error('خطأ في تحميل المزيد من التعليقات');
    } finally {
      setIsLoadingMore(false);
    }
  };

  const shareUrl = window.location.origin + '/v';
  const shareText = `حملة المطالبة بإنترنت غير محدود في مصر 🇪🇬 - صوتنا واحد وهدفنا واحد. انضم إلينا وصوّت الآن! عدد المشاركين وصل إلى ${displayVotes.toLocaleString('ar-EG')} مشارك.`;

  const copyToClipboard = async () => {
    navigator.clipboard.writeText(`${shareText} ${shareUrl}`);
    toast.success('تم نسخ الرابط ونص المشاركة! انشره الآن 🚀');

    // Award share points
    if (userFingerprint) {
      await awardSharePoints(userFingerprint);
      const updatedLeaderboard = await getLeaderboard(10);
      setLeaderboard(updatedLeaderboard);
      toast.info('🎉 +2 نقطة! شكراً لمشاركتك');
    }
  };

  const shareToWhatsApp = () => {
    const text = encodeURIComponent(`${shareText} ${shareUrl}`);
    window.open(`https://wa.me/?text=${text}`, '_blank');
    toast.success('فتح واتساب للمشاركة! 💚');
    if (userFingerprint) {
      awardSharePoints(userFingerprint);
    }
  };

  const shareToTelegram = () => {
    const text = encodeURIComponent(shareText);
    const url = encodeURIComponent(shareUrl);
    window.open(`https://t.me/share/url?url=${url}&text=${text}`, '_blank');
    toast.success('فتح تليجرام للمشاركة! ✈️');
    if (userFingerprint) {
      awardSharePoints(userFingerprint);
    }
  };

  const shareToTwitter = () => {
    const text = encodeURIComponent(shareText);
    const url = encodeURIComponent(shareUrl);
    window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank');
    toast.success('فتح تويتر للمشاركة! 🐦');
    if (userFingerprint) {
      awardSharePoints(userFingerprint);
    }
  };

  const shareToFacebook = () => {
    const url = encodeURIComponent(shareUrl);
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, '_blank');
    toast.success('فتح فيسبوك للمشاركة! 👍');
    if (userFingerprint) {
      awardSharePoints(userFingerprint);
    }
  };

  const currentUserEntry = leaderboard.find(e => e.fingerprint === userFingerprint);
  const userPoints = currentUserEntry ? currentUserEntry.points : (hasVoted ? 1 : 0);


  return (
    <>
      <SEO />
      {isInitialLoading ? (
        // Loading Screen
        <div className="min-h-screen bg-background flex items-center justify-center">
          <div className="text-center space-y-6">
            <div className="relative w-32 h-32 mx-auto">
              <img 
                src={LOGO_IMAGE} 
                alt="شعار الحملة" 
                className="w-full h-full object-contain animate-pulse"
              />
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl md:text-3xl font-bold text-primary animate-pulse">
                جاري التحميل...
              </h2>
              <p className="text-muted-foreground">
                يرجى الانتظار قليلاً
              </p>
            </div>
            <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto" />
          </div>
        </div>
      ) : (
      <div className="min-h-screen bg-background relative overflow-hidden selection:bg-primary selection:text-white font-cairo">
      {/* Top Navigation Menu - NEW */}
      <TopNavMenu />

      {/* Moderation Overlay */}
      <ModerationOverlay isVisible={isModerating} isComplete={moderationComplete} />

      {/* Scroll Progress Bar - Optimized */}
      <div 
        className="fixed top-0 left-0 h-1 bg-primary z-50 transition-all duration-150 shadow-[0_0_10px_#0EA5E9]" 
        style={{ width: `${scrollProgress}%`, willChange: 'width' }} 
      />

      {/* Update Notification */}
      <UpdateNotification />

      {/* Tech Background Background Glows - Optimized */}
      <div className="fixed inset-0 pointer-events-none -z-10 opacity-50">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-primary/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-primary/10 rounded-full blur-[120px]" />
      </div>

      {/* Prominent Unofficial Disclaimer Banner - Enhanced */}
      <div className="sticky top-[60px] z-40 bg-transparent border-b-4 border-amber-500 backdrop-blur-md py-3 shadow-lg shadow-amber-500/20">
        <div className="container px-4">
          <Alert className="bg-transparent border-2 border-amber-500 p-3 rounded-lg shadow-[0_0_20px_rgba(245,158,11,0.3)]">
            <AlertDescription className="text-center text-xs md:text-sm font-bold text-amber-400 flex items-center justify-center gap-2">
              <Info className="w-5 h-5 md:w-6 md:h-6 text-amber-400 animate-pulse flex-shrink-0" />
              <span className="flex-1">
                ⚠️ تنبيه مهم: هذا الموقع غير رسمي وغير تابع لأي جهة حكومية. يهدف فقط لجمع آراء وتطلعات المواطنين المصريين حول جودة وخدمات الإنترنت.
              </span>
            </AlertDescription>
          </Alert>
        </div>
      </div>

      {/* Header / Hero */}
      <header id="hero" className="relative overflow-hidden pt-12 pb-24 md:pt-20 md:pb-32">
        <div className="absolute inset-0 pointer-events-none -z-10 opacity-60">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-primary/10 via-primary/5 to-transparent" />
        </div>

        <div className="container px-4 text-center">
          <div className="flex justify-center mb-8">
            <div className="relative group">
              <div className="absolute -inset-1 bg-primary rounded-full blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200" />
              <img loading="lazy" 
                src={LOGO_IMAGE} 
                alt="شعار حملة نطالب بإنترنت غير محدود في مصر" 
                className="relative w-24 h-24 md:w-32 md:h-32 object-contain rounded-3xl shadow-[0_0_30px_rgba(14,165,233,0.3)]"
              />
            </div>
          </div>
          <h1 className="text-4xl md:text-7xl font-black mb-6 tracking-tight animate-fade-in gradient-text leading-tight">
            إنترنت غير محدود في مصر
          </h1>

          {/* SEO Intro Section - Optimized & Collapsible */}
          <details className="max-w-4xl mx-auto mb-10 text-right group">
            <summary className="cursor-pointer list-none">
              <div className="bg-slate-900/40 backdrop-blur-sm border border-primary/10 rounded-2xl p-3 md:p-4 hover:border-primary/30 transition-colors">
                <div className="flex items-center justify-between">
                  <h2 className="text-sm md:text-base font-bold text-primary">
                    هل يوجد انترنت غير محدود في مصر؟ اقرأ المزيد 📖
                  </h2>
                  <span className="text-primary text-xl group-open:rotate-180 transition-transform">▼</span>
                </div>
              </div>
            </summary>
            <div className="bg-slate-900/40 backdrop-blur-sm border border-primary/10 border-t-0 rounded-b-2xl p-4 md:p-6 space-y-3 mt-[-8px]">
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                مرحباً بك في أكبر <strong className="text-primary">موقع تصويت الانترنت</strong> في مصر! نحن منصة تفاعلية تجمع <strong className="text-primary">رأي الناس في الانترنت غير المحدود</strong> وتتيح لك المشاركة في <strong className="text-primary">تصويت الانترنت غير محدود</strong> للمطالبة بخدمات أفضل. 
              </p>
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                السؤال الذي يشغل بال الملايين: <strong className="text-primary">هل يوجد انترنت غير محدود في مصر</strong>؟ الإجابة للأسف أن معظم الباقات الحالية محدودة ولا تلبي احتياجات المستخدمين. لذلك أنشأنا هذا الموقع لجمع آراء المواطنين المصريين حول <strong className="text-primary">انترنت غير محدود مصر</strong> والمطالبة بتحسين الخدمات.
              </p>
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                من خلال <strong className="text-primary">موقع تصويت الانترنت</strong> هذا، يمكنك التصويت، إضافة تعليقك، ومشاركة تجربتك مع خدمات الإنترنت في مصر. صوتك مهم ويساهم في رسم صورة واضحة عن واقع الإنترنت في مصر ومطالب المواطنين بخدمات <strong className="text-primary">انترنت غير محدود</strong> بأسعار عادلة.
              </p>
            </div>
          </details>

          <p className="text-xl md:text-2xl text-muted-foreground mb-10 max-w-3xl mx-auto animate-fade-in delay-100 leading-relaxed">
            صوّتك يفرق.. خلّي صوتك يوصل. معاً من أجل مستقبل رقمي أفضل لمصر 🇪🇬
          </p>

          {/* Live Activity Feed */}
          {recentActivity.length > 0 && (
            <div className="flex flex-col items-center gap-2 mb-10 animate-in fade-in slide-in-from-bottom-4 duration-1000">
              {recentActivity.map((activity, idx) => (
                <Badge 
                  key={activity.id} 
                  variant="secondary" 
                  className={`py-1.5 px-4 rounded-full border-primary/20 bg-primary/5 text-primary text-xs md:text-sm animate-pulse shadow-sm ${idx > 0 ? 'opacity-50 scale-95' : 'opacity-100'}`}
                >
                  {activity.text}
                </Badge>
              ))}
            </div>
          )}

          {/* Voting Section */}
          <Card id="vote-section" className="max-w-xl mx-auto glass-card border-primary/20 animate-slide-in relative overflow-hidden scroll-mt-24">
            <div className="absolute top-0 right-0 w-full h-1 bg-primary shadow-[0_0_15px_#0EA5E9]" />
            <CardContent className="pt-8 px-6 pb-8">
              <div className="flex flex-col gap-6">
                <div className="text-center relative">
                  <Badge variant="outline" className="mb-4 gap-1.5 border-primary/30 bg-primary/10 text-primary animate-pulse-subtle px-3 py-1 font-bold">
                    <span className="relative flex h-2.5 w-2.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-primary"></span>
                    </span>
                    مباشر الآن
                  </Badge>
                  <p className="text-sm text-muted-foreground mb-2">عدد المصوتين الحالي</p>
                  <h3 className="text-5xl md:text-6xl font-black text-primary mb-2 tracking-tighter shadow-primary/20 drop-shadow-sm">
                    {displayVotes.toLocaleString('ar-EG')}
                  </h3>
                  <p className="text-xs text-muted-foreground">👤 مصري يطالب بإنترنت أفضل</p>
                </div>

                <div className="grid grid-cols-1 gap-4 text-center">
                  <Badge variant="outline" className="justify-center py-2 border-primary/30 text-primary font-bold bg-primary/5">
                    🚀 {displayShares.toLocaleString('ar-EG')} مشاركة تقنية عبر المنصات
                  </Badge>
                </div>

                <Button 
                  size="lg" 
                  className={`w-full text-xl py-8 font-black transition-all transform hover:scale-[1.02] active:scale-95 shadow-[0_0_20px_rgba(14,165,233,0.3)] shimmer-effect ${hasVoted ? 'bg-secondary' : 'bg-primary hover:bg-primary/90'} text-white rounded-2xl`}
                  onClick={handleVote}
                  disabled={isSubmittingVote}
                >
                  {hasVoted ? (
                    <span className="flex items-center gap-2"><CheckCircle2 className="w-6 h-6" /> تم التصويت بنجاح ✅</span>
                  ) : (
                    <span className="flex items-center gap-2">صوّت الآن <Zap className="w-5 h-5" /></span>
                  )}
                </Button>

                {/* Campaign Progress - Goal: 10,000 */}
                <div className="space-y-3 pt-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground font-bold">التقدم نحو الهدف</span>
                    <span className="text-primary font-black">{Math.min(Math.round((displayVotes / 10000) * 100), 100)}%</span>
                  </div>

                  {/* Progress Bar */}
                  <div className="relative h-3 bg-secondary/30 rounded-full overflow-hidden border border-primary/20">
                    <div 
                      className="absolute inset-y-0 right-0 bg-gradient-to-l from-primary via-primary/90 to-primary/70 rounded-full transition-all duration-1000 ease-out shadow-[0_0_10px_rgba(14,165,233,0.5)]"
                      style={{ width: `${Math.min((displayVotes / 10000) * 100, 100)}%` }}
                    >
                      <div className="absolute inset-0 bg-gradient-to-l from-white/20 to-transparent animate-pulse" />
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">الهدف: <span className="font-bold text-primary">10,000</span> صوت</span>
                    <span className="text-muted-foreground">متبقي: <span className="font-bold text-primary">{Math.max(10000 - displayVotes, 0).toLocaleString('ar-EG')}</span></span>
                  </div>
                </div>

                <p className="text-sm text-muted-foreground italic text-center pt-2">
                  * يتم تسجيل صوت واحد فقط لكل جهاز لضمان المصداقية.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </header>

      <main className="container px-4 pb-20 space-y-8">

        <div id="stats">
          <LiveDashboard 
            votes={displayVotes} 
            comments={displayComments} 
            activeUsers={activeUsers}
            latestGov={latestGov}
          />
        </div>

        {/* Condensed Header for Features */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Main Column */}
          <div className="lg:col-span-8 space-y-6">
            {/* Reasons Grid - Tech Style with SEO H2 */}
            <section>
              <h2 className="text-2xl md:text-3xl font-black text-center mb-6 text-primary">
                لماذا نطالب بإنترنت غير محدود في مصر؟
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                {[
                  { icon: <Laptop className="w-6 h-6" />, label: "العمل الحر", desc: "ضرورة اقتصادية" },
                  { icon: <GraduationCap className="w-6 h-6" />, label: "التعليم", desc: "حق أساسي" },
                  { icon: <Gamepad2 className="w-6 h-6" />, label: "الترفيه", desc: "جودة حياة" },
                  { icon: <TrendingUp className="w-6 h-6" />, label: "المنافسة", desc: "تطور تقني" },
                  { icon: <Zap className="w-6 h-6" />, label: "الكفاية", desc: "استخدام بلا قلق" },
                  { icon: <CheckCircle2 className="w-6 h-6" />, label: "الحق", desc: "مطلب شرعي" }
                ].map((reason, i) => (
                  <div key={i} className="flex flex-col items-center gap-3 p-4 glass-card rounded-2xl group cursor-help">
                    <div className="icon-box text-primary group-hover:text-primary-foreground transition-colors duration-300">
                      {reason.icon}
                    </div>
                    <div className="text-center">
                      <p className="font-black text-sm">{reason.label}</p>
                      <p className="text-[10px] text-muted-foreground">{reason.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Content Tabs */}
            <div id="leaderboard-section" className="scroll-mt-24">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-3 md:grid-cols-6 mb-4 h-auto p-1.5 bg-white/5 border border-white/5 rounded-xl">
                <TabsTrigger value="updates" className="text-[10px] py-2 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white transition-all">التحديثات</TabsTrigger>
                <TabsTrigger value="forum" className="text-[10px] py-2 font-bold data-[state=active]:bg-primary data-[state=active]:text-white rounded-lg transition-all">المنتدى</TabsTrigger>
                <TabsTrigger value="compare" className="text-[10px] py-2 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white transition-all">مقارنات</TabsTrigger>
                <TabsTrigger value="faq" className="text-[10px] py-2 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white transition-all">الأسئلة</TabsTrigger>
                <TabsTrigger value="map" className="text-[10px] py-2 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white transition-all">الخريطة</TabsTrigger>
              </TabsList>

              <TabsContent value="updates" className="mt-0"><CampaignChangelog updates={campaignUpdates} /></TabsContent>
              <TabsContent value="forum" className="mt-0">
                <Card className="border-primary/20 bg-primary/5 rounded-2xl overflow-hidden">
                  <CardHeader className="pb-4">
                    <CardTitle className="text-lg flex items-center gap-2 text-primary font-black">
                      <MessageSquare className="w-5 h-5" /> منتدى الحملة الحر
                    </CardTitle>
                    <CardDescription className="text-xs">شاركنا رأيك أو منشورك هنا، صوتك مسموع والكل بيشوفه</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <form onSubmit={handlePostSubmit} className="space-y-4 bg-primary/5 p-4 rounded-2xl border border-primary/10">
                      <Input 
                        placeholder="اسمك (اختياري)" 
                        value={forumName}
                        onChange={(e) => setForumName(e.target.value)}
                        className="bg-slate-900/50 border-white/10 rounded-xl"
                      />
                      <Textarea 
                        placeholder="اكتب منشورك هنا... (خليك محترم عشان المنشور يتقبل)" 
                        value={forumContent}
                        onChange={(e) => setForumContent(e.target.value)}
                        className="min-h-[100px] bg-slate-900/50 border-white/10 rounded-xl"
                      />
                      <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-white rounded-xl font-black" disabled={isSubmittingPost}>
                        {isSubmittingPost ? <Loader2 className="w-4 h-4 animate-spin" /> : 'انشر الآن 🚀'}
                      </Button>
                    </form>

                    <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
                      {forumPosts.map((post) => (
                        <div key={post.id} className="bg-muted/50 p-4 rounded-xl border border-border relative group hover:border-accent/30 transition-all">
                          <div className="flex justify-between items-start mb-2">
                            <span className="font-bold text-primary flex items-center gap-2">
                              <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center text-accent text-xs">
                                {post.user_name?.[0] || 'م'}
                              </div>
                              {post.user_name}
                            </span>
                            <span className="text-[10px] text-muted-foreground">{new Date(post.created_at).toLocaleDateString('ar-EG')}</span>
                          </div>
                          <p className="text-sm leading-relaxed mb-4">{post.content}</p>
                          <div className="flex items-center gap-4">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-8 gap-2 text-xs hover:text-accent"
                              onClick={() => handleLikePost(post.id)}
                            >
                              <Zap className={`w-4 h-4 ${post.likes > 0 ? 'fill-accent text-accent' : ''}`} /> {post.likes}
                            </Button>
                          </div>
                        </div>
                      ))}
                      {forumPosts.length === 0 && (
                        <div className="text-center py-10 text-muted-foreground italic">لا توجد منشورات بعد.. كن أول من يشارك! ✨</div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="compare" className="mt-0" id="comparison-section"><ComparisonTable data={comparisons} /></TabsContent>
              <TabsContent value="faq" className="mt-0" id="faq-section"><FAQSection faqs={faqs} /></TabsContent>
  <TabsContent value="map" className="mt-0" id="map-section"><Suspense fallback={<ComponentLoading />}><CampaignMap data={governorateData} /></Suspense></TabsContent>
  </Tabs>
  </div>
</div>

{/* Sidebar Column */}
<div className="lg:col-span-4 space-y-6">
  <div className="space-y-2" id="gamification-section">
    <Suspense fallback={<ComponentLoading />}><UserLevelCard points={userPoints} /></Suspense>
    <div className="flex justify-center">
      <Suspense fallback={<ComponentLoading />}><GamificationGuide /></Suspense>
    </div>
  </div>
  <Suspense fallback={<ComponentLoading />}><PointsLeaderboard entries={leaderboard} userFingerprint={userFingerprint} /></Suspense>

  {/* لوحة شرف المحافظات - ميزة جديدة */}
  <Suspense fallback={<ComponentLoading />}><GovernoratesLeaderboard /></Suspense>

  <div id="rewards-section" className="scroll-mt-24">
    <Suspense fallback={<ComponentLoading />}><ProfileFrameGenerator /></Suspense>
    <Suspense fallback={<ComponentLoading />}><SupportCardGenerator /></Suspense>
  </div>
</div>
      </div>

        <Separator className="bg-primary/10" />

        {/* حاسبة التوفير الذكية - ميزة جديدة */}
        <section id="calculator-section" className="space-y-6 scroll-mt-24">
          <SavingsCalculator />
        </section>

        <Separator className="bg-primary/10" />

        {/* حائط الأمنيات الرقمي - ميزة جديدة */}
        <section id="wishes-section" className="space-y-6 scroll-mt-24">
          <WishWall />
        </section>

        <Separator className="bg-primary/10" />


        {/* Network Analytics Section */}
        <section id="analytics" className="space-y-6">
          <div className="text-center space-y-2">
            <h2 className="text-3xl font-black gradient-text">📊 تحليلات الحملة</h2>
            <p className="text-sm text-muted-foreground">بيانات حقيقية من المشاركين</p>
          </div>
          <Suspense fallback={<ComponentLoading />}><NetworkAnalytics networkStats={networkStats} dataUsageStats={dataUsageStats} /></Suspense>
        </section>

        <Separator className="bg-primary/10" />

        {/* Global Success & Vision */}
        <section id="roadmap-section" className="space-y-16 py-12 scroll-mt-24">
          <Suspense fallback={<ComponentLoading />}><GlobalSuccessStories /></Suspense>
          <Suspense fallback={<ComponentLoading />}><FutureRoadmap /></Suspense>
        </section>

        <Separator className="bg-primary/10" />


        {/* Interaction Section */}
        <section id="comments-section" className="grid grid-cols-1 lg:grid-cols-12 gap-8 scroll-mt-24">
          {/* Form */}
          <div className="lg:col-span-4 space-y-6" id="comment-form">
            <div className="glass-card p-8 rounded-[2rem] sticky top-24 border-primary/20 shadow-2xl">
              <h2 className="text-2xl font-black mb-6 flex items-center gap-3 text-primary">
                <MessageSquare className="w-6 h-6" /> أضف صوتك
              </h2>
              <form onSubmit={handleCommentSubmit} className="space-y-4">
                <Input placeholder="الاسم (اختياري)" value={name} onChange={(e) => setName(e.target.value)} className="bg-white/5 border-white/10 h-12 rounded-xl text-sm focus:ring-primary focus:border-primary" />
                <Select value={governorate} onValueChange={setGovernorate}>
                  <SelectTrigger className="bg-white/5 border-white/10 h-12 rounded-xl text-sm focus:ring-primary">
                    <SelectValue placeholder="المحافظة" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-900 border-white/10">
                    {GOVERNORATES.map((gov) => <SelectItem key={gov} value={gov} className="focus:bg-primary/20">{gov}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Textarea placeholder="لماذا تريد إنترنت غير محدود؟" value={commentText} onChange={(e) => setCommentText(e.target.value)} className="bg-white/5 border-white/10 min-h-[120px] rounded-xl text-sm focus:ring-primary focus:border-primary" />
                <Button type="submit" className="w-full h-12 font-black text-base md:text-lg bg-primary hover:bg-primary/90 rounded-xl transition-all shadow-lg shadow-primary/20 relative overflow-hidden" disabled={isSubmittingComment || isModerating}>
                  {isSubmittingComment ? (
                    <span className="flex items-center gap-2">
                      <Loader2 className="w-5 h-5 animate-spin" />
                      جاري الحفظ...
                    </span>
                  ) : isModerating ? (
                    <span className="flex items-center gap-2 animate-pulse">
                      <Zap className="w-5 h-5 animate-bounce" />
                      <span className="hidden sm:inline">مراجعة التعليق بالذكاء الاصطناعي...</span>
                      <span className="sm:hidden">جاري المراجعة...</span>
                    </span>
                  ) : moderationComplete ? (
                    <span className="flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5" />
                      <span className="hidden sm:inline">تمت المراجعة - يمكنك النشر الآن ✅</span>
                      <span className="sm:hidden">تمت المراجعة ✅</span>
                    </span>
                  ) : (
                    <>
                      <span className="hidden sm:inline">مراجعة تعليقي بالذكاء الاصطناعي 🤖</span>
                      <span className="sm:hidden">مراجعة ذكية 🤖</span>
                    </>
                  )}
                </Button>
              </form>
            </div>
          </div>

          {/* Feed */}
          <div className="lg:col-span-8">
            <h2 className="text-2xl md:text-3xl font-black text-primary mb-6">
              رأي الناس في الانترنت غير المحدود - تصويت الانترنت المباشر
            </h2>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-black text-primary flex items-center gap-3">
                <TrendingUp className="w-6 h-6" /> أصوات الشعب
              </h3>
              <Badge variant="outline" className="border-primary/30 text-primary bg-primary/5 px-4 py-1 rounded-full font-bold">
                {displayComments.toLocaleString('ar-EG')} مشاركة حية
              </Badge>
            </div>

            {/* Search and Filter */}
            <div className="mb-6 space-y-3">
              <div className="flex flex-col md:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="ابحث في التعليقات..."
                    value={commentSearchQuery}
                    onChange={(e) => setCommentSearchQuery(e.target.value)}
                    className="pr-10 bg-white/5 border-white/10 focus:border-primary/30"
                    dir="rtl"
                  />
                </div>
                <Select value={commentFilterGovernorate} onValueChange={setCommentFilterGovernorate}>
                  <SelectTrigger className="w-full md:w-[200px] bg-white/5 border-white/10">
                    <div className="flex items-center gap-2">
                      <Filter className="w-4 h-4" />
                      <SelectValue placeholder="كل المحافظات" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">كل المحافظات</SelectItem>
                    {GOVERNORATES.map((gov) => (
                      <SelectItem key={gov} value={gov}>{gov}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {(commentSearchQuery || commentFilterGovernorate !== 'all') && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20">
                    {comments.filter(c => {
                      const matchesSearch = !commentSearchQuery || 
                        c.content.toLowerCase().includes(commentSearchQuery.toLowerCase()) ||
                        c.name.toLowerCase().includes(commentSearchQuery.toLowerCase());
                      const matchesGov = commentFilterGovernorate === 'all' || c.governorate === commentFilterGovernorate;
                      return matchesSearch && matchesGov;
                    }).length} نتيجة
                  </Badge>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-6 text-xs"
                    onClick={() => {
                      setCommentSearchQuery('');
                      setCommentFilterGovernorate('all');
                    }}
                  >
                    مسح الفلاتر
                  </Button>
                </div>
              )}
            </div>

            <div className="space-y-4 max-h-[800px] overflow-y-auto pr-4 custom-scrollbar">
              {comments
                .filter(c => {
                  const matchesSearch = !commentSearchQuery || 
                    c.content.toLowerCase().includes(commentSearchQuery.toLowerCase()) ||
                    c.name.toLowerCase().includes(commentSearchQuery.toLowerCase());
                  const matchesGov = commentFilterGovernorate === 'all' || c.governorate === commentFilterGovernorate;
                  return matchesSearch && matchesGov;
                })
                .map((c) => (
                <div key={c.id} className="p-6 rounded-2xl bg-white/5 border border-white/5 hover:border-primary/20 transition-all group">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center font-black text-primary border border-primary/20 group-hover:bg-primary group-hover:text-white transition-colors">
                        {c.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-black text-base">{c.name}</p>
                        <p className="text-xs text-muted-foreground flex items-center gap-1.5 font-bold">
                          <MapPin className="w-3 h-3 text-primary" /> {c.governorate} • {new Date(c.created_at).toLocaleDateString('ar-EG', { day: 'numeric', month: 'long' })}
                        </p>
                      </div>
                    </div>
                  </div>
                  <p className="text-sm leading-relaxed text-muted-foreground font-medium pr-1 mb-4">{c.content}</p>

                  {/* التفاعلات على التعليق - إيموجيات عصرية وجذابة */}
                  <div className="flex items-center gap-2 mt-auto">
                    {/* صاروخ - يلا بينا للأمام */}
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className={`h-8 rounded-full gap-1.5 px-3 border transition-all ${
                        userReactions[c.id]?.includes('heart')
                          ? 'bg-purple-500/20 text-purple-400 border-purple-500/30 hover:bg-purple-500/30'
                          : 'bg-white/5 hover:bg-purple-500/10 hover:text-purple-400 border-white/5'
                      }`}
                      onClick={() => handleReactToComment(c.id, 'heart')}
                      title="يلا بينا للأمام! 🚀"
                    >
                      <span className="text-base">🚀</span>
                      <span className="text-xs font-mono font-bold">{c.hearts_count || 0}</span>
                    </Button>

                    {/* برق - نت سريع زي البرق */}
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className={`h-8 rounded-full gap-1.5 px-3 border transition-all ${
                        userReactions[c.id]?.includes('like')
                          ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30 hover:bg-yellow-500/30'
                          : 'bg-white/5 hover:bg-yellow-500/10 hover:text-yellow-400 border-white/5'
                      }`}
                      onClick={() => handleReactToComment(c.id, 'like')}
                      title="نت سريع زي البرق ⚡"
                    >
                      <span className="text-base">⚡</span>
                      <span className="text-xs font-mono font-bold">{c.likes_count || 0}</span>
                    </Button>

                    {/* انفجار - كلام قوي جداً */}
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className={`h-8 rounded-full gap-1.5 px-3 border transition-all ${
                        userReactions[c.id]?.includes('broken_heart')
                          ? 'bg-orange-500/20 text-orange-400 border-orange-500/30 hover:bg-orange-500/30'
                          : 'bg-white/5 hover:bg-orange-500/10 hover:text-orange-400 border-white/5'
                      }`}
                      onClick={() => handleReactToComment(c.id, 'broken_heart')}
                      title="كلام قوي جداً 💥"
                    >
                      <span className="text-base">💥</span>
                      <span className="text-xs font-mono font-bold">{c.broken_heart_count || 0}</span>
                    </Button>

                    {/* وجه محبط - زهقنا من الوضع */}
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className={`h-8 rounded-full gap-1.5 px-3 border transition-all ${
                        userReactions[c.id]?.includes('sad')
                          ? 'bg-red-500/20 text-red-400 border-red-500/30 hover:bg-red-500/30'
                          : 'bg-white/5 hover:bg-red-500/10 hover:text-red-400 border-white/5'
                      }`}
                      onClick={() => handleReactToComment(c.id, 'sad')}
                      title="زهقنا من الوضع 😤"
                    >
                      <span className="text-base">😤</span>
                      <span className="text-xs font-mono font-bold">{c.sad_count || 0}</span>
                    </Button>
                  </div>
                </div>
              ))}
              {comments.filter(c => {
                const matchesSearch = !commentSearchQuery || 
                  c.content.toLowerCase().includes(commentSearchQuery.toLowerCase()) ||
                  c.name.toLowerCase().includes(commentSearchQuery.toLowerCase());
                const matchesGov = commentFilterGovernorate === 'all' || c.governorate === commentFilterGovernorate;
                return matchesSearch && matchesGov;
              }).length === 0 && (
                <div className="text-center py-12 space-y-3">
                  <div className="text-4xl">🔍</div>
                  <p className="text-muted-foreground">لا توجد نتائج مطابقة للبحث</p>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setCommentSearchQuery('');
                      setCommentFilterGovernorate('all');
                    }}
                  >
                    مسح الفلاتر
                  </Button>
                </div>
              )}
              {hasMoreToLoad && comments.filter(c => {
                const matchesSearch = !commentSearchQuery || 
                  c.content.toLowerCase().includes(commentSearchQuery.toLowerCase()) ||
                  c.name.toLowerCase().includes(commentSearchQuery.toLowerCase());
                const matchesGov = commentFilterGovernorate === 'all' || c.governorate === commentFilterGovernorate;
                return matchesSearch && matchesGov;
              }).length > 0 && (
                <Button variant="ghost" className="w-full text-xs" onClick={handleLoadMore} disabled={isLoadingMore}>
                  {isLoadingMore ? "جاري التحميل..." : "شاهد المزيد"}
                </Button>
              )}
            </div>
          </div>
        </section>

        {/* قسم اختبار السرعة الحقيقي */}
        <section id="speed-section" className="py-8">
          <div className="text-center mb-8">
            <h2 className="text-2xl md:text-3xl font-black mb-3 gradient-text">
              ⚡ اختبر سرعة الإنترنت الحقيقية لديك
            </h2>
            <p className="text-muted-foreground text-sm md:text-base max-w-2xl mx-auto">
              قياس دقيق وفوري لسرعة التحميل والرفع وزمن الاستجابة باستخدام تقنية القياس المباشر
            </p>
          </div>
          <RealSpeedTest />
        </section>

        {/* Enhanced Share Section */}
        <section id="share-section" className="bg-primary/5 rounded-[3rem] p-10 text-center border border-primary/20 relative overflow-hidden group scroll-mt-24">
          <div className="absolute inset-0 bg-primary/5 -z-10 group-hover:scale-110 transition-transform duration-1000" />
          <h2 className="text-2xl md:text-3xl font-black mb-4 flex items-center justify-center gap-3 gradient-text">
            <Share2 className="text-primary w-7 h-7" /> شارك موقع تصويت الانترنت وساعدنا نكبر! 📢
          </h2>
          <p className="text-muted-foreground mb-8 max-w-md mx-auto text-sm leading-relaxed">
            صوتك مهم، ومشاركتك لموقع <strong className="text-primary">تصويت الانترنت غير محدود</strong> بتساعدنا نوصل لمسؤولين أكتر ونحقق التغيير المطلوب.
          </p>

          {/* Prominent Social Media Buttons */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 max-w-2xl mx-auto">
            <Button 
              size="lg" 
              onClick={shareToWhatsApp}
              className="h-24 rounded-2xl bg-[#25D366] hover:bg-[#20BA5A] text-white font-black text-base flex flex-col gap-2 shadow-lg hover:shadow-xl transition-all hover:scale-105"
            >
              <Send className="w-7 h-7" />
              <span>واتساب</span>
            </Button>

            <Button 
              size="lg" 
              onClick={shareToTelegram}
              className="h-24 rounded-2xl bg-[#0088cc] hover:bg-[#006699] text-white font-black text-base flex flex-col gap-2 shadow-lg hover:shadow-xl transition-all hover:scale-105"
            >
              <Send className="w-7 h-7" />
              <span>تليجرام</span>
            </Button>

            <Button 
              size="lg" 
              onClick={shareToFacebook}
              className="h-24 rounded-2xl bg-[#1877F2] hover:bg-[#145DBF] text-white font-black text-base flex flex-col gap-2 shadow-lg hover:shadow-xl transition-all hover:scale-105"
            >
              <Facebook className="w-7 h-7" />
              <span>فيسبوك</span>
            </Button>

            <Button 
              size="lg" 
              onClick={shareToTwitter}
              className="h-24 rounded-2xl bg-[#1DA1F2] hover:bg-[#1A8CD8] text-white font-black text-base flex flex-col gap-2 shadow-lg hover:shadow-xl transition-all hover:scale-105"
            >
              <Twitter className="w-7 h-7" />
              <span>تويتر</span>
            </Button>
          </div>

          {/* Copy Link Button */}
          <div className="flex justify-center mb-4">
            <Button 
              size="lg" 
              variant="outline" 
              onClick={copyToClipboard} 
              className="rounded-2xl h-14 px-8 gap-3 font-black border-primary/20 hover:bg-primary/10 hover:scale-105 transition-all"
            >
              <Copy className="w-5 h-5" /> نسخ الرابط
            </Button>
          </div>

          {/* Share Reward Info */}
          <p className="text-xs text-muted-foreground">
            💡 كل مشاركة تمنحك +2 نقطة في لوحة المتصدرين
          </p>
        </section>

      </main>

      <footer className="bg-slate-950/50 backdrop-blur-md py-12 text-center pb-24 border-t border-white/5 relative overflow-hidden">
        <div className="absolute inset-0 bg-primary/5 -z-10" />
        <div className="container px-4">
          <div className="flex items-center justify-center gap-3 mb-8">
            <div className="relative">
              <div className="absolute -inset-1 bg-primary rounded-full blur opacity-20" />
              <img loading="lazy" src={LOGO_IMAGE} alt="Logo" className="relative w-12 h-12 rounded-xl border border-white/10" />
            </div>
            <span className="font-black text-xl text-primary tracking-tight">نطالب بإنترنت غير محدود في مصر</span>
          </div>
          <p className="text-muted-foreground mb-8 max-w-lg mx-auto leading-relaxed">
            هذا تصويت لجمع آراء المستخدمين الذين يطالبون بإنترنت غير محدود في مصر. هذا ليس إجراءً رسمياً من جهة حكومية أو أي شركة، نحن مواطنون نريد إنترنت مثل باقي دول العالم 🌍
          </p>
          <div className="flex flex-col items-center gap-4">
            <div className="flex items-center gap-2 text-[10px] text-muted-foreground/60 bg-white/5 py-1.5 px-4 rounded-full border border-white/10">
              <span className="w-2 h-2 bg-primary rounded-full animate-pulse shadow-[0_0_10px_#0EA5E9]" />
              حالة النظام: متصل وجاهز • {new Date().toLocaleString('ar-EG', { dateStyle: 'long' })}
            </div>
            <p className="text-xs text-muted-foreground/40 font-mono tracking-widest uppercase flex flex-wrap items-center justify-center gap-2">
              <span>© 2026</span>
            </p>
          </div>
        </div>
      </footer>
      <HumanVerification 
        isOpen={isVerifying} 
        onOpenChange={setIsVerifying} 
        onVerified={onVerified} 
      />

      <PostVoteSurvey 
        isOpen={showSurvey} 
        onOpenChange={setShowSurvey} 
        onComplete={onSurveyComplete} 
      />

      {/* Developer Reset Tool */}
      {showResetButton && (
        <div className="fixed top-4 right-4 z-[200] animate-in fade-in slide-in-from-top-2">
          <Card className="bg-destructive/10 border-destructive/20 shadow-2xl">
            <CardContent className="p-4 space-y-2">
              <p className="text-xs font-bold text-destructive">🔧 أداة المطور</p>
              <Button 
                variant="destructive" 
                size="sm" 
                onClick={handleResetVote}
                className="w-full text-xs"
              >
                إعادة تعيين التصويت
              </Button>
              <p className="text-[9px] text-muted-foreground">اضغط Ctrl+Shift+R للإخفاء</p>
            </CardContent>
          </Card>
        </div>
      )}

      <FloatingLiveActivity initialActivities={comments} />
      <BottomNav />
      <AIChat />
    </div>
    )}
    </>
  );
}
