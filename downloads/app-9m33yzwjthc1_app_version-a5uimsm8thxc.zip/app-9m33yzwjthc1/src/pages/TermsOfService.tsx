import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';

const TermsOfService: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <Card className="glass-card border-primary/20">
          <CardHeader className="text-center border-b border-primary/20">
            <div className="flex items-center justify-center gap-3 mb-4">
              <FileText className="w-10 h-10 text-primary" />
              <CardTitle className="text-3xl md:text-4xl font-black gradient-text">
                شروط الاستخدام
              </CardTitle>
            </div>
            <p className="text-slate-400 text-sm">
              آخر تحديث: 22 فبراير 2026
            </p>
          </CardHeader>

          <CardContent className="prose prose-invert max-w-none p-6 md:p-8 space-y-6">
            {/* مرحباً */}
            <section>
              <h2 className="text-2xl font-bold text-primary mb-4">مرحباً بك!</h2>
              <p className="text-slate-300 leading-relaxed">
                مرحباً بك في موقع "إنترنت غير محدود في مصر". باستخدامك لهذا الموقع، فإنك توافق على الالتزام بشروط الاستخدام التالية. يرجى قراءتها بعناية.
              </p>
              <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4 mt-4">
                <p className="text-amber-400 font-bold text-sm flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5" />
                  ملاحظة مهمة: هذا الموقع غير رسمي وغير تابع لأي جهة حكومية أو شركة اتصالات.
                </p>
              </div>
            </section>

            {/* طبيعة الموقع */}
            <section>
              <h2 className="text-2xl font-bold text-primary mb-4">طبيعة الموقع</h2>
              
              <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4 mb-4">
                <h3 className="text-lg font-bold text-blue-400 mb-2">موقع غير رسمي</h3>
                <ul className="list-disc list-inside text-slate-300 space-y-1 mr-4">
                  <li>غير تابع لأي جهة حكومية</li>
                  <li>غير تابع لأي شركة اتصالات (WE, Vodafone, Orange, Etisalat)</li>
                  <li>غير تابع لجهاز تنظيم الاتصالات</li>
                  <li>منصة مستقلة لجمع آراء المواطنين</li>
                </ul>
              </div>

              <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
                <h3 className="text-lg font-bold text-green-400 mb-2">الغرض من الموقع</h3>
                <ul className="list-disc list-inside text-slate-300 space-y-1 mr-4">
                  <li>جمع آراء المواطنين المصريين حول خدمات الإنترنت</li>
                  <li>توفير منصة للتعبير عن الرأي بشكل سلمي وحضاري</li>
                  <li>عرض إحصائيات وتحليلات حول آراء المشاركين</li>
                  <li>رفع الوعي بأهمية الإنترنت غير المحدود</li>
                </ul>
              </div>
            </section>

            {/* الاستخدام المسموح والمحظور */}
            <section>
              <h2 className="text-2xl font-bold text-primary mb-4">استخدام الموقع</h2>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
                  <h3 className="text-lg font-bold text-green-400 mb-3 flex items-center gap-2">
                    <CheckCircle className="w-5 h-5" />
                    الاستخدام المسموح به
                  </h3>
                  <ul className="list-disc list-inside text-slate-300 space-y-2 text-sm mr-4">
                    <li>التصويت في الاستفتاءات</li>
                    <li>إضافة تعليقات محترمة</li>
                    <li>مشاركة الموقع</li>
                    <li>الاطلاع على الإحصائيات</li>
                    <li>استخدام الأدوات التفاعلية</li>
                  </ul>
                </div>

                <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                  <h3 className="text-lg font-bold text-red-400 mb-3 flex items-center gap-2">
                    <XCircle className="w-5 h-5" />
                    الاستخدام المحظور
                  </h3>
                  <ul className="list-disc list-inside text-slate-300 space-y-2 text-sm mr-4">
                    <li>التصويت المتكرر بطرق احتيالية</li>
                    <li>نشر محتوى مسيء أو بذيء</li>
                    <li>التحريض على العنف</li>
                    <li>انتحال شخصية الآخرين</li>
                    <li>محاولة اختراق الموقع</li>
                    <li>استخدام برامج آلية (Bots)</li>
                    <li>نشر إعلانات (Spam)</li>
                  </ul>
                </div>
              </div>
            </section>

            {/* المحتوى */}
            <section>
              <h2 className="text-2xl font-bold text-primary mb-4">المحتوى الذي ينشئه المستخدم</h2>
              
              <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
                <h3 className="text-lg font-bold text-purple-400 mb-2">مسؤوليتك</h3>
                <ul className="list-disc list-inside text-slate-300 space-y-2 mr-4">
                  <li>أنت مسؤول بالكامل عن المحتوى الذي تنشره</li>
                  <li>يجب أن يكون المحتوى محترماً وخالياً من الألفاظ البذيئة</li>
                  <li>يجب أن يكون متعلقاً بموضوع الحملة (الإنترنت في مصر)</li>
                  <li>لا تنشر معلومات شخصية حساسة</li>
                </ul>
              </div>

              <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4 mt-4">
                <h3 className="text-lg font-bold text-blue-400 mb-2">المراجعة بالذكاء الاصطناعي 🤖</h3>
                <p className="text-slate-300 text-sm">
                  جميع التعليقات والأمنيات تُراجع تلقائياً بالذكاء الاصطناعي. المحتوى المسيء أو المخالف سيُرفض تلقائياً. نحتفظ بالحق في حذف أي محتوى مخالف دون إشعار مسبق.
                </p>
              </div>
            </section>

            {/* إخلاء المسؤولية */}
            <section>
              <h2 className="text-2xl font-bold text-primary mb-4">إخلاء المسؤولية</h2>
              
              <div className="space-y-3">
                <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-3">
                  <h3 className="font-bold text-slate-200 mb-1">دقة المعلومات</h3>
                  <p className="text-slate-400 text-sm">
                    نبذل قصارى جهدنا لضمان دقة المعلومات، لكن لا نضمن دقة أو اكتمال أي معلومات على الموقع.
                  </p>
                </div>

                <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-3">
                  <h3 className="font-bold text-slate-200 mb-1">توفر الخدمة</h3>
                  <p className="text-slate-400 text-sm">
                    قد يكون الموقع غير متاح مؤقتاً بسبب الصيانة أو مشاكل تقنية. لا نتحمل مسؤولية أي خسائر ناتجة عن عدم توفر الموقع.
                  </p>
                </div>

                <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-3">
                  <h3 className="font-bold text-slate-200 mb-1">النتائج</h3>
                  <p className="text-slate-400 text-sm">
                    لا نضمن تحقيق أي نتائج أو تغييرات في سياسات الإنترنت. الموقع هو منصة للتعبير عن الرأي فقط.
                  </p>
                </div>
              </div>
            </section>

            {/* الموافقة النهائية */}
            <section className="text-center bg-gradient-to-r from-primary/20 to-purple-500/20 rounded-lg p-6">
              <h2 className="text-2xl font-bold text-primary mb-4">الموافقة النهائية</h2>
              <p className="text-slate-300 mb-4">
                باستخدامك لهذا الموقع، فإنك قرأت وفهمت شروط الاستخدام هذه وتوافق على الالتزام بجميع الشروط.
              </p>
              <p className="text-primary font-bold text-lg">
                شكراً لمشاركتك! 💚
              </p>
              <p className="text-slate-400 mt-2">
                معاً نطالب بإنترنت غير محدود في مصر! 🇪🇬
              </p>
            </section>

            {/* رابط للنسخة الكاملة */}
            <div className="text-center pt-6 border-t border-primary/20">
              <a 
                href="https://github.com/yourusername/unlimited-internet-egypt/blob/main/TERMS_OF_SERVICE.md" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition-colors"
              >
                <FileText className="w-5 h-5" />
                <span>اقرأ النسخة الكاملة من شروط الاستخدام</span>
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default TermsOfService;
