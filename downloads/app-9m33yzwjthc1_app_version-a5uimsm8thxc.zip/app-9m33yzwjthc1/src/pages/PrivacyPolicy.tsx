import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, Lock, Eye, FileText } from 'lucide-react';

const PrivacyPolicy: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <Card className="glass-card border-primary/20">
          <CardHeader className="text-center border-b border-primary/20">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Shield className="w-10 h-10 text-primary" />
              <CardTitle className="text-3xl md:text-4xl font-black gradient-text">
                سياسة الخصوصية
              </CardTitle>
            </div>
            <p className="text-slate-400 text-sm">
              آخر تحديث: 22 فبراير 2026
            </p>
          </CardHeader>

          <CardContent className="prose prose-invert max-w-none p-6 md:p-8 space-y-6">
            {/* مقدمة */}
            <section>
              <h2 className="text-2xl font-bold text-primary flex items-center gap-2 mb-4">
                <Lock className="w-6 h-6" />
                مقدمة
              </h2>
              <p className="text-slate-300 leading-relaxed">
                نحن في "إنترنت غير محدود في مصر" نلتزم بحماية خصوصيتك وبياناتك الشخصية. هذه السياسة توضح كيفية جمع واستخدام وحماية المعلومات التي تقدمها عند استخدام موقعنا.
              </p>
              <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4 mt-4">
                <p className="text-amber-400 font-bold text-sm">
                  ⚠️ ملاحظة مهمة: هذا الموقع غير رسمي وغير تابع لأي جهة حكومية. نحن منصة مستقلة لجمع آراء المواطنين المصريين حول خدمات الإنترنت.
                </p>
              </div>
            </section>

            {/* المعلومات التي نجمعها */}
            <section>
              <h2 className="text-2xl font-bold text-primary flex items-center gap-2 mb-4">
                <Eye className="w-6 h-6" />
                المعلومات التي نجمعها
              </h2>
              
              <h3 className="text-xl font-bold text-slate-200 mt-4 mb-2">1. المعلومات التي تقدمها طوعاً</h3>
              <ul className="list-disc list-inside text-slate-300 space-y-2 mr-4">
                <li><strong>الاسم</strong>: (اختياري) عند التصويت أو إضافة تعليق أو أمنية</li>
                <li><strong>المحافظة</strong>: لتحليل التوزيع الجغرافي للمشاركين</li>
                <li><strong>التعليقات والأمنيات</strong>: المحتوى النصي الذي تشاركه</li>
                <li><strong>بيانات التصويت</strong>: اختياراتك في الاستفتاءات</li>
              </ul>

              <h3 className="text-xl font-bold text-slate-200 mt-4 mb-2">2. المعلومات التي نجمعها تلقائياً</h3>
              <ul className="list-disc list-inside text-slate-300 space-y-2 mr-4">
                <li><strong>عنوان IP</strong>: لمنع التصويت المتكرر وحماية الموقع من الإساءة</li>
                <li><strong>نوع المتصفح والجهاز</strong>: لتحسين تجربة المستخدم</li>
                <li><strong>تاريخ ووقت الزيارة</strong>: لتحليل أنماط الاستخدام</li>
                <li><strong>الصفحات المزارة</strong>: لفهم سلوك المستخدمين وتحسين الموقع</li>
              </ul>
            </section>

            {/* كيف نستخدم معلوماتك */}
            <section>
              <h2 className="text-2xl font-bold text-primary mb-4">كيف نستخدم معلوماتك</h2>
              
              <h3 className="text-xl font-bold text-green-400 mt-4 mb-2">✅ الأغراض الأساسية:</h3>
              <ul className="list-disc list-inside text-slate-300 space-y-2 mr-4">
                <li>عرض الإحصائيات ونشر عدد المصوتين والتوزيع الجغرافي</li>
                <li>منع الإساءة وحماية الموقع من التصويت المتكرر والمحتوى المسيء</li>
                <li>تحسين الخدمة وفهم احتياجات المستخدمين وتطوير الموقع</li>
                <li>التحليلات ودراسة أنماط الاستخدام لتحسين الأداء</li>
              </ul>

              <h3 className="text-xl font-bold text-red-400 mt-4 mb-2">❌ ما لا نفعله:</h3>
              <ul className="list-disc list-inside text-slate-300 space-y-2 mr-4">
                <li><strong>لا نبيع بياناتك</strong> لأي جهة خارجية</li>
                <li><strong>لا نشارك معلوماتك الشخصية</strong> مع أطراف ثالثة (إلا إذا طلب القانون ذلك)</li>
                <li><strong>لا نرسل رسائل تسويقية</strong> أو بريد إلكتروني غير مرغوب فيه</li>
                <li><strong>لا نستخدم بياناتك</strong> لأغراض تجارية</li>
              </ul>
            </section>

            {/* حماية بياناتك */}
            <section>
              <h2 className="text-2xl font-bold text-primary flex items-center gap-2 mb-4">
                <Shield className="w-6 h-6" />
                حماية بياناتك
              </h2>
              
              <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4 space-y-2">
                <h3 className="text-lg font-bold text-green-400">الإجراءات الأمنية:</h3>
                <ul className="list-disc list-inside text-slate-300 space-y-2 mr-4">
                  <li><strong>التشفير</strong>: جميع البيانات المنقولة محمية بتشفير SSL/TLS (HTTPS)</li>
                  <li><strong>قاعدة بيانات آمنة</strong>: نستخدم Supabase مع سياسات أمان صارمة</li>
                  <li><strong>المراجعة بالذكاء الاصطناعي</strong>: جميع التعليقات والأمنيات تُراجع تلقائياً لمنع المحتوى المسيء</li>
                  <li><strong>تنقية المدخلات</strong>: جميع مدخلات المستخدم تُنقى لمنع هجمات XSS وحقن SQL</li>
                  <li><strong>الحد من معدل الطلبات</strong>: حماية من هجمات DDoS والإساءة</li>
                </ul>
              </div>
            </section>

            {/* حقوقك */}
            <section>
              <h2 className="text-2xl font-bold text-primary mb-4">حقوقك</h2>
              <p className="text-slate-300 mb-4">لديك الحق في:</p>
              <ul className="list-disc list-inside text-slate-300 space-y-2 mr-4">
                <li><strong>الوصول</strong>: طلب نسخة من بياناتك الشخصية</li>
                <li><strong>التصحيح</strong>: طلب تصحيح أي معلومات غير دقيقة</li>
                <li><strong>الحذف</strong>: طلب حذف بياناتك من قاعدة البيانات</li>
                <li><strong>الاعتراض</strong>: الاعتراض على معالجة بياناتك لأغراض معينة</li>
                <li><strong>نقل البيانات</strong>: طلب نقل بياناتك إلى خدمة أخرى</li>
              </ul>
            </section>

            {/* الاتصال */}
            <section className="bg-primary/10 border border-primary/30 rounded-lg p-6">
              <h2 className="text-2xl font-bold text-primary mb-4">الاتصال بنا</h2>
              <p className="text-slate-300 mb-4">
                إذا كان لديك أي أسئلة أو استفسارات حول سياسة الخصوصية، يرجى التواصل معنا عبر نموذج الاتصال في قسم "الدعم والمساعدة".
              </p>
              <p className="text-slate-400 text-sm">
                نحن نرد على جميع الاستفسارات خلال 48 ساعة عمل.
              </p>
            </section>

            {/* الموافقة */}
            <section className="text-center bg-gradient-to-r from-primary/20 to-purple-500/20 rounded-lg p-6">
              <h2 className="text-2xl font-bold text-primary mb-4">الموافقة</h2>
              <p className="text-slate-300">
                باستخدامك لهذا الموقع، فإنك توافق على شروط سياسة الخصوصية هذه. إذا كنت لا توافق على أي جزء من هذه السياسة، يرجى عدم استخدام الموقع.
              </p>
              <p className="text-primary font-bold mt-4 text-lg">
                شكراً لثقتك بنا! 💚
              </p>
            </section>

            {/* رابط للنسخة الكاملة */}
            <div className="text-center pt-6 border-t border-primary/20">
              <a 
                href="https://github.com/yourusername/unlimited-internet-egypt/blob/main/PRIVACY_POLICY.md" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition-colors"
              >
                <FileText className="w-5 h-5" />
                <span>اقرأ النسخة الكاملة من سياسة الخصوصية</span>
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
