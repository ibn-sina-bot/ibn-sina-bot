import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Zap, Share2, MapPin, CheckCircle2, Info, ArrowLeft, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getStats, castVote } from '@/db/api';
import { toast } from 'sonner';
import { generateFingerprint } from '@/lib/utils';

import { HumanVerification } from '@/components/enhanced/HumanVerification';
import { PostVoteSurvey } from '@/components/enhanced/PostVoteSurvey';
import { UpdateNotification } from '@/components/enhanced/UpdateNotification';
import confetti from 'canvas-confetti';

const LOGO_IMAGE = "https://miaoda-conversation-file.s3cdn.medo.dev/user-9il5qwkjedq8/conv-9m33yzwjthc0/20260310/file-a5uac79v6kg0.png";

export const SharePage: React.FC = () => {
  const [stats, setStats] = useState({ votes: 0 });
  const [hasVoted, setHasVoted] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isVoting, setIsVoting] = useState(false);
  const [showSurvey, setShowSurvey] = useState(false);

  useEffect(() => {
    // Initial fetch
    getStats().then(setStats);
    setHasVoted(localStorage.getItem('has_voted') === 'true');
  }, []);

  const handleVoteClick = () => {
    if (hasVoted) {
      toast.info('شكراً! أنت قمت بالتصويت بالفعل ✅');
      return;
    }
    setIsVerifying(true);
  };

  const onVerified = async () => {
    setShowSurvey(true);
  };

  const onSurveyComplete = async (data: { networkProvider: string; dataUsageType: string }) => {
    setIsVoting(true);
    try {
      // Simple fingerprint (user agent + screen resolution hash placeholder)
      const fingerprint = generateFingerprint();
      
      const result = await castVote(fingerprint, data);
      if (result.success) {
        setHasVoted(true);
        localStorage.setItem('has_voted', 'true');
        localStorage.setItem('egypt_unlimited_voted_v2', 'true');
        setStats(prev => ({ ...prev, votes: prev.votes + 1 }));
        
        // Celebration effect
        confetti({
          particleCount: 150,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#0A2240', '#4A90E2', '#7ED321', '#FFFFFF']
        });
        
        toast.success('تم تسجيل صوتك بنجاح! 💪');
      } else {
        toast.error(result.error || 'حدث خطأ أثناء التصويت');
      }
    } catch (err) {
      toast.error('حدث خطأ غير متوقع');
    } finally {
      setIsVoting(false);
    }
  };

  const shareText = `أنا صوّت للمطالبة بإنترنت غير محدود في مصر! 🇪🇬 انضم إلينا وصوّت الآن، عددنا وصل لـ ${stats.votes.toLocaleString('ar-EG')} مشارك.`;
  const shareUrl = window.location.origin + '/v';

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'نطالب بإنترنت غير محدود في مصر',
        text: shareText,
        url: shareUrl,
      });
    } else {
      navigator.clipboard.writeText(`${shareText} ${shareUrl}`);
      toast.success('تم نسخ رابط المشاركة!');
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4 relative overflow-hidden selection:bg-primary selection:text-white font-cairo">
      {/* Update Notification */}
      <UpdateNotification />
      
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-full h-1 bg-primary shadow-[0_0_10px_#0EA5E9]" />
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-primary/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[5%] w-[50%] h-[50%] bg-primary/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="w-full max-w-lg space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-1000">
        {/* Header */}
        <div className="text-center space-y-6">
          <Link to="/" className="inline-flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-muted-foreground hover:text-primary transition-colors bg-white/5 py-1.5 px-4 rounded-full border border-white/5">
            <ArrowLeft className="w-3 h-3" /> العودة للموقع الرئيسي
          </Link>
          
          <div className="flex justify-center">
            <div className="flex items-center gap-2 bg-primary/5 border border-primary/20 rounded-full px-4 py-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
              <span className="text-[10px] font-mono font-black text-primary tracking-tighter">الحملة الرسمية</span>
            </div>
          </div>

          <div className="flex justify-center">
            <div className="relative group">
              <div className="absolute -inset-1 bg-primary rounded-full blur opacity-25 group-hover:opacity-50 transition duration-1000" />
              <img loading="lazy" src={LOGO_IMAGE} alt="Logo" className="relative w-24 h-24 rounded-full shadow-2xl border-4 border-slate-900 bg-slate-900 p-1" />
            </div>
          </div>
          <h1 className="text-3xl font-black gradient-text leading-tight">
            نطالب بإنترنت غير محدود في مصر
          </h1>
          <p className="text-sm text-muted-foreground max-w-xs mx-auto leading-relaxed">
            مبادرة شعبية من أجل إنترنت أسرع، أوفر، وبدون حدود استهلاك 🇪🇬
          </p>
        </div>


        {/* Action Card */}
        <Card className="glass-card border-primary/20 shadow-[0_0_40px_rgba(14,165,233,0.1)] overflow-hidden relative rounded-[2rem]">
          <CardContent className="p-10 space-y-8">
            <div className="text-center space-y-2">
              <Badge variant="outline" className="bg-primary/5 text-primary border-primary/20 animate-pulse px-4 py-1 rounded-full font-bold">مباشر الآن</Badge>
              <div className="text-6xl font-black text-primary tracking-tighter drop-shadow-sm">
                {stats.votes.toLocaleString('ar-EG')}
              </div>
              <p className="text-xs text-muted-foreground font-bold italic tracking-wide">مصري يطالبون بالتغيير حتى الآن</p>
            </div>

            <Button 
              size="lg" 
              className={`w-full py-10 text-2xl font-black transition-all transform hover:scale-[1.02] active:scale-95 shadow-[0_0_20px_rgba(14,165,233,0.3)] shimmer-effect rounded-2xl ${hasVoted ? 'bg-secondary text-white' : 'bg-primary hover:bg-primary/90 text-white'}`}
              onClick={handleVoteClick}
              disabled={isVoting}
            >
              {hasVoted ? (
                <span className="flex items-center gap-2"><CheckCircle2 className="w-8 h-8" /> تم التصويت ✅</span>
              ) : isVoting ? (
                "جاري المعالجة..."
              ) : (
                <span className="flex items-center gap-3"><Zap className="w-6 h-6" /> صوّت الآن</span>
              )}
            </Button>

            <div className="pt-6 border-t border-border/50 grid grid-cols-2 gap-4">
              <Button variant="outline" onClick={handleShare} className="gap-2 text-xs h-12 rounded-xl">
                <Share2 className="w-4 h-4" /> شارك الحملة
              </Button>
              <Link to="/" className="w-full">
                <Button variant="ghost" className="w-full gap-2 text-xs h-12 rounded-xl">
                  عرض المنتدى <ArrowLeft className="w-4 h-4 rotate-180" />
                </Button>
              </Link>
            </div>

            <div className="bg-muted/30 p-4 rounded-2xl flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 text-green-500 mt-0.5 shrink-0" />
              <div className="space-y-1">
                <p className="text-[10px] font-bold">حماية ضد البوتات</p>
                <p className="text-[10px] text-muted-foreground leading-relaxed">
                  نحن نستخدم تقنيات متطورة لضمان أن كل صوت هو لمواطن حقيقي، للحفاظ على مصداقية مطالبنا أمام الجهات المعنية.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>


        {/* Footer Info */}
        <div className="text-center space-y-6">
          <div className="flex items-center justify-center gap-6 text-[10px] text-muted-foreground/40 font-black uppercase tracking-[0.2em] bg-white/5 py-2 px-6 rounded-full border border-white/5 mx-auto w-fit">
            <span className="flex items-center gap-2"><MapPin className="w-3 h-3 text-primary" /> مصر 🇪🇬</span>
            <span className="flex items-center gap-2"><Info className="w-3 h-3 text-primary" /> غير رسمي</span>
          </div>
          <p className="text-[10px] text-muted-foreground/30 leading-relaxed max-w-xs mx-auto font-mono">
            © 2026 Internet Unlimited – Blue Speed Theme
          </p>
        </div>
      </div>

      <HumanVerification 
        isOpen={isVerifying} 
        onOpenChange={setIsVerifying} 
        onVerified={onVerified} 
      />
      
      <PostVoteSurvey
        isOpen={showSurvey}
        onOpenChange={setShowSurvey}
        onComplete={onSurveyComplete}
      />
    </div>
  );
};
