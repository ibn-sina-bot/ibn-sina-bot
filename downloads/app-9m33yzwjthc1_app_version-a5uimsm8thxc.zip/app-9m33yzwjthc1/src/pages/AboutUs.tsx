import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Info, Target, Users, Heart, Shield, Zap } from 'lucide-react';

const AboutUs: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <Card className="glass-card border-primary/20">
          <CardHeader className="text-center border-b border-primary/20">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Info className="w-10 h-10 text-primary" />
              <CardTitle className="text-3xl md:text-4xl font-black gradient-text">
                من نحن
              </CardTitle>
            </div>
            <p className="text-slate-400 text-lg">
              منصة مستقلة لجمع آراء المصريين حول خدمات الإنترنت 🇪🇬
            </p>
          </CardHeader>

          <CardContent className="p-6 md:p-8 space-y-8">
            {/* مقدمة */}
            <section className="text-center">
              <h2 className="text-3xl font-bold gradient-text mb-4">
                إنترنت غير محدود في مصر
              </h2>
              <p className="text-slate-300 text-lg leading-relaxed max-w-2xl mx-auto">
                نحن منصة مستقلة وغير رسمية تهدف إلى جمع آراء المواطنين المصريين حول خدمات الإنترنت في مصر والمطالبة بإنترنت غير محدود بأسعار عادلة.
              </p>
            </section>

            {/* رؤيتنا */}
            <section className="bg-gradient-to-r from-primary/10 to-purple-500/10 border border-primary/30 rounded-lg p-6">
              <div className="flex items-center gap-3 mb-4">
                <Target className="w-8 h-8 text-primary" />
                <h2 className="text-2xl font-bold text-primary">رؤيتنا</h2>
              </div>
              <p className="text-slate-300 leading-relaxed">
                نؤمن بأن الإنترنت غير المحدود حق أساسي لكل مواطن مصري. نسعى لتوفير منصة شفافة وآمنة لجمع الآراء والمطالب، وإيصال صوت المواطنين إلى صناع القرار.
              </p>
            </section>

            {/* أهدافنا */}
            <section>
              <div className="flex items-center gap-3 mb-6">
                <Zap className="w-8 h-8 text-primary" />
                <h2 className="text-2xl font-bold text-primary">أهدافنا</h2>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
                  <h3 className="font-bold text-blue-400 mb-2">📊 جمع الآراء</h3>
                  <p className="text-slate-300 text-sm">
                    توفير منصة سهلة وآمنة لجمع آراء المواطنين حول خدمات الإنترنت في مصر
                  </p>
                </div>

                <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
                  <h3 className="font-bold text-green-400 mb-2">📈 عرض الإحصائيات</h3>
                  <p className="text-slate-300 text-sm">
                    نشر إحصائيات شفافة ودقيقة عن عدد المصوتين والتوزيع الجغرافي
                  </p>
                </div>

                <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
                  <h3 className="font-bold text-purple-400 mb-2">🔊 إيصال الصوت</h3>
                  <p className="text-slate-300 text-sm">
                    العمل على إيصال صوت المواطنين إلى الجهات المعنية وصناع القرار
                  </p>
                </div>

                <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                  <h3 className="font-bold text-amber-400 mb-2">💡 رفع الوعي</h3>
                  <p className="text-slate-300 text-sm">
                    نشر الوعي بأهمية الإنترنت غير المحدود للتعليم والعمل والترفيه
                  </p>
                </div>
              </div>
            </section>

            {/* قيمنا */}
            <section>
              <div className="flex items-center gap-3 mb-6">
                <Heart className="w-8 h-8 text-primary" />
                <h2 className="text-2xl font-bold text-primary">قيمنا</h2>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-start gap-3 bg-slate-800/50 border border-slate-700 rounded-lg p-4">
                  <Shield className="w-6 h-6 text-green-400 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-bold text-green-400 mb-1">الشفافية</h3>
                    <p className="text-slate-300 text-sm">
                      نلتزم بالشفافية الكاملة في جمع البيانات وعرض الإحصائيات. جميع الأرقام حقيقية ومبنية على مشاركات فعلية.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-slate-800/50 border border-slate-700 rounded-lg p-4">
                  <Shield className="w-6 h-6 text-blue-400 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-bold text-blue-400 mb-1">الأمان</h3>
                    <p className="text-slate-300 text-sm">
                      نحمي بياناتك بأعلى معايير الأمان. جميع المدخلات تُراجع بالذكاء الاصطناعي، والبيانات محمية بتشفير SSL/TLS.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-slate-800/50 border border-slate-700 rounded-lg p-4">
                  <Users className="w-6 h-6 text-purple-400 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-bold text-purple-400 mb-1">الاستقلالية</h3>
                    <p className="text-slate-300 text-sm">
                      نحن منصة مستقلة تماماً، غير تابعة لأي جهة حكومية أو شركة اتصالات. نمثل صوت المواطنين فقط.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-slate-800/50 border border-slate-700 rounded-lg p-4">
                  <Heart className="w-6 h-6 text-red-400 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-bold text-red-400 mb-1">الاحترام</h3>
                    <p className="text-slate-300 text-sm">
                      نحترم جميع الآراء ونوفر بيئة آمنة للتعبير عن الرأي بشكل حضاري ومحترم.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* ملاحظة مهمة */}
            <section className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-6">
              <h2 className="text-xl font-bold text-amber-400 mb-3 flex items-center gap-2">
                <Info className="w-6 h-6" />
                ملاحظة مهمة
              </h2>
              <div className="space-y-2 text-slate-300">
                <p>
                  ⚠️ هذا الموقع <strong>غير رسمي</strong> وغير تابع لأي جهة حكومية أو شركة اتصالات.
                </p>
                <p>
                  ⚠️ نحن <strong>لا نقدم خدمات إنترنت فعلية</strong>، بل نوفر منصة لجمع الآراء والمطالب.
                </p>
                <p>
                  ⚠️ <strong>لا نضمن</strong> تحقيق أي مطالب أو تغييرات في سياسات الإنترنت.
                </p>
                <p>
                  ✅ نحن منصة مستقلة تهدف إلى <strong>إيصال صوت المواطنين</strong> بشكل سلمي وحضاري.
                </p>
              </div>
            </section>

            {/* التقنيات المستخدمة */}
            <section>
              <h2 className="text-2xl font-bold text-primary mb-4">التقنيات المستخدمة</h2>
              <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
                <p className="text-slate-300 mb-4">
                  نستخدم أحدث التقنيات لضمان أمان وسرعة وموثوقية الموقع:
                </p>
                <ul className="grid md:grid-cols-2 gap-2 text-slate-400 text-sm">
                  <li>✅ React + TypeScript للواجهة</li>
                  <li>✅ Supabase لقاعدة البيانات الآمنة</li>
                  <li>✅ Google Analytics للتحليلات</li>
                  <li>✅ Gemini AI للمراجعة التلقائية</li>
                  <li>✅ SSL/TLS للتشفير</li>
                  <li>✅ DOMPurify لتنقية المدخلات</li>
                </ul>
              </div>
            </section>

            {/* الاتصال */}
            <section className="text-center bg-gradient-to-r from-primary/20 to-purple-500/20 rounded-lg p-6">
              <h2 className="text-2xl font-bold text-primary mb-4">تواصل معنا</h2>
              <p className="text-slate-300 mb-4">
                لديك أسئلة أو اقتراحات؟ نحن نرحب بتواصلك!
              </p>
              <p className="text-slate-400 text-sm">
                يمكنك التواصل معنا عبر نموذج الاتصال في قسم "الدعم والمساعدة"
              </p>
              <p className="text-primary font-bold mt-6 text-lg">
                معاً نطالب بإنترنت غير محدود في مصر! 🇪🇬💚
              </p>
            </section>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AboutUs;
