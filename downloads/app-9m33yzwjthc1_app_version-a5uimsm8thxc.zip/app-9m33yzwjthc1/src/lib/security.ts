import DOMPurify from 'dompurify';

/**
 * Security Utilities for Input Sanitization and Validation
 * تنقية والتحقق من صحة مدخلات المستخدم
 */

/**
 * Sanitize HTML content to prevent XSS attacks
 * تنقية محتوى HTML لمنع هجمات XSS
 */
export const sanitizeHTML = (dirty: string): string => {
  return DOMPurify.sanitize(dirty, {
    ALLOWED_TAGS: ['b', 'i', 'em', 'strong', 'br'],
    ALLOWED_ATTR: [],
  });
};

/**
 * Sanitize plain text (remove all HTML tags)
 * تنقية النص العادي (إزالة جميع علامات HTML)
 */
export const sanitizeText = (text: string): string => {
  return DOMPurify.sanitize(text, {
    ALLOWED_TAGS: [],
    ALLOWED_ATTR: [],
  });
};

/**
 * Validate and sanitize user name
 * التحقق من صحة وتنقية اسم المستخدم
 */
export const sanitizeName = (name: string): string => {
  // Remove HTML tags
  let clean = sanitizeText(name);
  
  // Remove special characters except Arabic, English letters, spaces, and common punctuation
  clean = clean.replace(/[^a-zA-Z\u0600-\u06FF\s\-.']/g, '');
  
  // Trim and limit length
  clean = clean.trim().slice(0, 50);
  
  return clean;
};

/**
 * Validate and sanitize comment/wish content
 * التحقق من صحة وتنقية محتوى التعليق/الأمنية
 */
export const sanitizeComment = (comment: string): string => {
  // Remove HTML tags
  let clean = sanitizeText(comment);
  
  // Remove potentially dangerous patterns
  clean = clean.replace(/<script[^>]*>.*?<\/script>/gi, '');
  clean = clean.replace(/javascript:/gi, '');
  clean = clean.replace(/on\w+\s*=/gi, '');
  
  // Trim and limit length
  clean = clean.trim().slice(0, 500);
  
  return clean;
};

/**
 * Validate email format
 * التحقق من صحة تنسيق البريد الإلكتروني
 */
export const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email) && email.length <= 254;
};

/**
 * Validate URL format
 * التحقق من صحة تنسيق الرابط
 */
export const isValidURL = (url: string): boolean => {
  try {
    const urlObj = new URL(url);
    return urlObj.protocol === 'http:' || urlObj.protocol === 'https:';
  } catch {
    return false;
  }
};

/**
 * Sanitize URL to prevent javascript: and data: protocols
 * تنقية الرابط لمنع بروتوكولات javascript: و data:
 */
export const sanitizeURL = (url: string): string => {
  if (!isValidURL(url)) {
    return '';
  }
  
  const urlObj = new URL(url);
  if (urlObj.protocol !== 'http:' && urlObj.protocol !== 'https:') {
    return '';
  }
  
  return url;
};

/**
 * Validate file upload (image only)
 * التحقق من صحة رفع الملف (صور فقط)
 */
export const validateImageFile = (file: File): { valid: boolean; error?: string } => {
  // Check file type
  const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
  if (!allowedTypes.includes(file.type)) {
    return { valid: false, error: 'نوع الملف غير مدعوم. يُسمح فقط بـ JPG, PNG, WEBP' };
  }
  
  // Check file size (max 5MB)
  const maxSize = 5 * 1024 * 1024; // 5MB
  if (file.size > maxSize) {
    return { valid: false, error: 'حجم الملف كبير جداً. الحد الأقصى 5 ميجابايت' };
  }
  
  return { valid: true };
};

/**
 * Rate limiting helper (client-side)
 * مساعد للحد من معدل الطلبات (جانب العميل)
 */
export class RateLimiter {
  private attempts: Map<string, number[]> = new Map();
  
  /**
   * Check if action is allowed based on rate limit
   * التحقق من السماح بالإجراء بناءً على معدل الطلبات
   */
  isAllowed(key: string, maxAttempts: number, windowMs: number): boolean {
    const now = Date.now();
    const attempts = this.attempts.get(key) || [];
    
    // Remove old attempts outside the time window
    const recentAttempts = attempts.filter(time => now - time < windowMs);
    
    if (recentAttempts.length >= maxAttempts) {
      return false;
    }
    
    // Add current attempt
    recentAttempts.push(now);
    this.attempts.set(key, recentAttempts);
    
    return true;
  }
  
  /**
   * Reset rate limit for a key
   * إعادة تعيين معدل الطلبات لمفتاح معين
   */
  reset(key: string): void {
    this.attempts.delete(key);
  }
}

/**
 * Escape HTML entities
 * تجنب كيانات HTML
 */
export const escapeHTML = (text: string): string => {
  const map: Record<string, string> = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#x27;',
    '/': '&#x2F;',
  };
  
  return text.replace(/[&<>"'/]/g, (char) => map[char]);
};

/**
 * Generate secure random string
 * توليد سلسلة عشوائية آمنة
 */
export const generateSecureToken = (length: number = 32): string => {
  const array = new Uint8Array(length);
  crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
};

/**
 * Check for suspicious patterns in text
 * التحقق من الأنماط المشبوهة في النص
 */
export const hasSuspiciousContent = (text: string): boolean => {
  const suspiciousPatterns = [
    /<script/i,
    /javascript:/i,
    /on\w+\s*=/i,
    /<iframe/i,
    /eval\(/i,
    /document\./i,
    /window\./i,
    /<embed/i,
    /<object/i,
  ];
  
  return suspiciousPatterns.some(pattern => pattern.test(text));
};

/**
 * Validate governorate name against allowed list
 * التحقق من اسم المحافظة مقابل القائمة المسموح بها
 */
export const EGYPTIAN_GOVERNORATES = [
  'القاهرة',
  'الجيزة',
  'الإسكندرية',
  'الدقهلية',
  'البحيرة',
  'الفيوم',
  'الغربية',
  'الإسماعيلية',
  'المنوفية',
  'المنيا',
  'القليوبية',
  'الوادي الجديد',
  'الشرقية',
  'أسيوط',
  'سوهاج',
  'بني سويف',
  'قنا',
  'أسوان',
  'الأقصر',
  'البحر الأحمر',
  'مطروح',
  'شمال سيناء',
  'جنوب سيناء',
  'بورسعيد',
  'دمياط',
  'السويس',
  'كفر الشيخ',
];

export const isValidGovernorate = (governorate: string): boolean => {
  return EGYPTIAN_GOVERNORATES.includes(governorate);
};
