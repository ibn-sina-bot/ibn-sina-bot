import Home from './pages/Home';
import { SharePage } from './pages/SharePage';
import PrivacyPolicy from './pages/PrivacyPolicy';
import TermsOfService from './pages/TermsOfService';
import AboutUs from './pages/AboutUs';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    element: <Home />
  },
  {
    name: 'Vote',
    path: '/v',
    element: <SharePage />
  },
  {
    name: 'Privacy Policy',
    path: '/privacy',
    element: <PrivacyPolicy />
  },
  {
    name: 'Terms of Service',
    path: '/terms',
    element: <TermsOfService />
  },
  {
    name: 'About Us',
    path: '/about',
    element: <AboutUs />
  }
];

export default routes;
