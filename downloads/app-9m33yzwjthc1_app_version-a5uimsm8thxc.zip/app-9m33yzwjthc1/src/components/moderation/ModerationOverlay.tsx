import React from 'react';
import { Sparkles, CheckCircle2 } from 'lucide-react';

interface ModerationOverlayProps {
  isVisible: boolean;
  isComplete: boolean;
}

export const ModerationOverlay: React.FC<ModerationOverlayProps> = ({ isVisible, isComplete }) => {
  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="relative">
        {/* الدائرة الخارجية المتحركة */}
        <div className="absolute inset-0 animate-ping">
          <div className="w-32 h-32 rounded-full bg-primary/30 blur-xl"></div>
        </div>
        
        {/* الدائرة الرئيسية */}
        <div className="relative w-32 h-32 rounded-full bg-gradient-to-br from-primary via-primary/80 to-primary/60 flex items-center justify-center shadow-2xl shadow-primary/50 animate-pulse">
          {isComplete ? (
            <CheckCircle2 className="w-16 h-16 text-white animate-in zoom-in duration-500" />
          ) : (
            <Sparkles className="w-16 h-16 text-white animate-spin" style={{ animationDuration: '2s' }} />
          )}
        </div>
        
        {/* النص */}
        <div className="mt-8 text-center space-y-2 animate-in slide-in-from-bottom duration-500">
          <h3 className="text-2xl font-black text-white">
            {isComplete ? 'تمت المراجعة ✅' : 'جاري المراجعة...'}
          </h3>
          <p className="text-sm text-white/70 font-bold">
            {isComplete ? 'يمكنك النشر الآن' : 'الذكاء الاصطناعي يراجع تعليقك'}
          </p>
        </div>
        
        {/* النقاط المتحركة */}
        {!isComplete && (
          <div className="flex justify-center gap-2 mt-6">
            <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0ms' }}></div>
            <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '150ms' }}></div>
            <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '300ms' }}></div>
          </div>
        )}
      </div>
    </div>
  );
};
