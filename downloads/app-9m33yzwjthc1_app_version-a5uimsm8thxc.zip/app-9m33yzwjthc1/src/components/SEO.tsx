import { Helmet } from 'react-helmet-async';

interface SEOProps {
  title?: string;
  description?: string;
  keywords?: string;
  image?: string;
  url?: string;
  type?: string;
}

export function SEO({
  title = 'إنترنت غير محدود في مصر | موقع تصويت الإنترنت ورأي الناس 🇪🇬',
  description = 'هل يوجد انترنت غير محدود في مصر؟ شارك برأيك في أكبر موقع تصويت الانترنت غير محدود. انضم لآلاف المصريين في المطالبة بإنترنت غير محدود وبأسعار عادلة. اعرف رأي الناس في الانترنت غير المحدود وصوّت الآن لمستقبل رقمي أفضل لمصر.',
  keywords = 'انترنت غير محدود مصر, تصويت الانترنت غير محدود, رأي الناس في الانترنت غير المحدود, هل يوجد انترنت غير محدود في مصر, موقع تصويت الانترنت, باقات الإنترنت في مصر, تحسين خدمات الإنترنت, حملة الإنترنت المصرية, إنترنت رخيص مصر, وي, فودافون, اورانج, اتصالات, سرعة الإنترنت في مصر, باقات الموبايل, unlimited internet egypt',
  image = 'https://miaoda-conversation-file.s3cdn.medo.dev/user-9il5qwkjedq8/conv-9m33yzwjthc0/20260310/file-a5uac79v6kg0.png',
  url = 'https://app-9m33yzwjthc1.appmedo.com/',
  type = 'website'
}: SEOProps) {
  const schemaOrgJSONLD = {
    "@context": "https://schema.org",
    "@type": type === 'article' ? 'Article' : 'WebSite',
    "name": title,
    "url": url,
    "description": description,
    "image": image,
    "publisher": {
      "@type": "Organization",
      "name": "Unlimited Internet Egypt",
      "logo": {
        "@type": "ImageObject",
        "url": "https://miaoda-conversation-file.s3cdn.medo.dev/user-9il5qwkjedq8/conv-9m33yzwjthc0/20260310/file-a5uac79v6kg0.png"
      }
    }
  };

  return (
    <Helmet>
      {/* Primary Meta Tags */}
      <title>{title}</title>
      <meta name="title" content={title} />
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords} />
      
      {/* Open Graph / Facebook */}
      <meta property="og:type" content={type} />
      <meta property="og:url" content={url} />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={image} />
      
      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:url" content={url} />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={image} />
      
      {/* Canonical URL */}
      <link rel="canonical" href={url} />

      {/* Schema.org JSON-LD */}
      <script type="application/ld+json">
        {JSON.stringify(schemaOrgJSONLD)}
      </script>
    </Helmet>
  );
}
