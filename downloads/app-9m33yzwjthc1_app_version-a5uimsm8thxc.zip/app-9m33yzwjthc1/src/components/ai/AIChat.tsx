import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  X, 
  Send, 
  Loader2, 
  MessageCircle, 
  PhoneCall, 
  ShieldAlert,
  Sparkles
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/db/supabase';
import { Badge } from '@/components/ui/badge';
import { createParser } from 'eventsource-parser';
import { Streamdown } from 'streamdown';
import { sanitizeText } from '@/lib/security';

interface Message {
  role: 'user' | 'model';
  parts: { text: string }[];
}

export const AIChat: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [streamingText, setStreamingText] = useState('');

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, streamingText, isOpen]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    // Sanitize input
    const sanitizedInput = sanitizeText(input.trim());
    if (!sanitizedInput) {
      setInput('');
      return;
    }

    const userMessage: Message = { role: 'user', parts: [{ text: sanitizedInput }] };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);
    setStreamingText('');

    try {
      const { data, error } = await supabase.functions.invoke('ai-assistant', {
        body: {
          messages: [...messages, userMessage].map(m => ({
            role: m.role,
            parts: m.parts
          }))
        }
      });

      if (error || !data) {
        throw new Error('فشل الاتصال بالمساعد الذكي');
      }

      const fullResponse = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
      setMessages(prev => [...prev, { role: 'model', parts: [{ text: fullResponse }] }]);
      setStreamingText('');
    } catch (error) {
      console.error('AI Error:', error);
      setMessages(prev => [...prev, { 
        role: 'model', 
        parts: [{ text: 'عذراً، حدث خطأ أثناء محاولة الاتصال بالمساعد الذكي. حاول مرة أخرى لاحقاً.' }] 
      }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed bottom-24 right-2 md:bottom-8 md:right-4 z-[110]">
      {/* Chat Window */}
      {isOpen && (
        <Card className="mb-4 w-[90vw] md:w-[360px] h-[450px] flex flex-col shadow-2xl border-primary/20 animate-in slide-in-from-bottom-4 duration-300">
          <CardHeader className="bg-primary text-primary-foreground p-3 rounded-t-xl flex flex-row items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <Bot className="w-5 h-5" /> مساعد الحملة الذكي 🇪🇬
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)} className="text-primary-foreground hover:bg-primary/80 h-8 w-8">
              <X className="w-4 h-4" />
            </Button>
          </CardHeader>
          
          <ScrollArea className="flex-1 p-3 bg-muted/30">
            <div className="space-y-3" ref={scrollRef}>
              {/* Initial Welcome Message */}
              <div className="flex justify-start">
                <div className="max-w-[85%] bg-background p-2.5 rounded-xl rounded-tl-none border border-border text-xs leading-relaxed shadow-sm">
                  مرحباً بك! أنا مساعدك الذكي لحملة "إنترنت غير محدود". يمكنني مساعدتك في معرفة كيفية تقديم شكوى رسمية بشأن خدمة الإنترنت الخاصة بك. 🚀
                  <div className="mt-2 space-y-1">
                    <p className="font-bold text-primary flex items-center gap-1 text-[11px]">
                      <PhoneCall className="w-3 h-3" /> الخطوات السريعة:
                    </p>
                    <ul className="text-[10px] list-disc pr-4 space-y-0.5 opacity-80">
                      <li>كلم خدمة العملاء على 111</li>
                      <li>خد رقم الشكوى واحتفظ بيه</li>
                      <li>بعد 48 ساعة كلم 155 (تنظيم الاتصالات)</li>
                    </ul>
                  </div>
                </div>
              </div>

              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] p-2.5 rounded-xl text-xs leading-relaxed shadow-sm ${
                    msg.role === 'user' 
                    ? 'bg-primary text-primary-foreground rounded-tr-none' 
                    : 'bg-background border border-border rounded-tl-none'
                  }`}>
                    {msg.role === 'model' ? (
                      <Streamdown children={msg.parts[0].text} />
                    ) : (
                      msg.parts[0].text
                    )}
                  </div>
                </div>
              ))}

              {streamingText && (
                <div className="flex justify-start">
                  <div className="max-w-[85%] bg-background p-2.5 rounded-xl rounded-tl-none border border-border text-xs leading-relaxed shadow-sm">
                    <Streamdown children={streamingText} />
                  </div>
                </div>
              )}

              {isTyping && !streamingText && (
                <div className="flex justify-start">
                  <div className="bg-background p-2.5 rounded-xl rounded-tl-none border border-border shadow-sm">
                    <Loader2 className="w-4 h-4 animate-spin text-primary" />
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>

          <CardFooter className="p-3 border-t bg-background rounded-b-xl">
            <form 
              onSubmit={(e) => { e.preventDefault(); handleSend(); }}
              className="flex w-full gap-2"
            >
              <Input 
                placeholder="اسألني عن كيفية تقديم شكوى..." 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="flex-1 h-9 text-xs"
                dir="rtl"
              />
              <Button type="submit" size="icon" disabled={isTyping || !input.trim()} className="h-9 w-9 shrink-0">
                <Send className="w-3.5 h-3.5" />
              </Button>
            </form>
          </CardFooter>
        </Card>
      )}

      {/* Floating Toggle Button */}
      <div className="flex flex-col items-end gap-1.5">
        {!isOpen && (
          <Badge variant="secondary" className="animate-bounce bg-accent text-accent-foreground border-accent-foreground/10 px-2 py-0.5 text-[9px] md:text-[10px]">
            كيف أقدم شكوى؟ 🤔
          </Badge>
        )}
        <Button 
          onClick={() => setIsOpen(!isOpen)}
          size="icon"
          className={`h-11 w-11 md:h-12 md:w-12 rounded-full shadow-2xl transition-all duration-500 hover:scale-110 ${
            isOpen ? 'bg-muted text-muted-foreground' : 'bg-primary text-primary-foreground'
          }`}
        >
          {isOpen ? <X className="w-5 h-5" /> : (
            <div className="relative">
              <Bot className="w-5 h-5 md:w-6 md:h-6" />
              <Sparkles className="absolute -top-1.5 -right-1.5 w-3 h-3 text-accent animate-pulse" />
            </div>
          )}
        </Button>
      </div>
    </div>
  );
};
