import React, { useState } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Menu, Home, Vote, MessageSquare, Share2, Calculator, Heart, Trophy, Map, BarChart3, Users, Zap, Gift, BookOpen, HelpCircle, Sparkles, Target, TrendingUp } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';

const LOGO_IMAGE = "https://miaoda-conversation-file.s3cdn.medo.dev/user-9il5qwkjedq8/conv-9m33yzwjthc0/20260310/file-a5uac79v6kg0.png";


interface NavItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  section: string;
  description?: string;
}

const navigationItems: NavItem[] = [
  {
    id: 'home',
    label: 'الرئيسية',
    icon: <Home className="w-5 h-5" />,
    section: 'hero',
    description: 'العودة للصفحة الرئيسية'
  },
  {
    id: 'vote',
    label: 'التصويت',
    icon: <Vote className="w-5 h-5" />,
    section: 'vote-section',
    description: 'صوّت للحملة الآن'
  },
  {
    id: 'comments',
    label: 'التعليقات',
    icon: <MessageSquare className="w-5 h-5" />,
    section: 'comments-section',
    description: 'شارك رأيك مع الجميع'
  },
  {
    id: 'wishes',
    label: 'حائط الأمنيات',
    icon: <Heart className="w-5 h-5" />,
    section: 'wishes-section',
    description: 'شارك أمنيتك الحقيقية'
  },
  {
    id: 'calculator',
    label: 'حاسبة التوفير',
    icon: <Calculator className="w-5 h-5" />,
    section: 'calculator-section',
    description: 'احسب كام بتصرف على الباقات'
  },
  {
    id: 'leaderboard',
    label: 'لوحة الشرف',
    icon: <Trophy className="w-5 h-5" />,
    section: 'leaderboard-section',
    description: 'ترتيب المحافظات والداعمين'
  },
  {
    id: 'share',
    label: 'المشاركة',
    icon: <Share2 className="w-5 h-5" />,
    section: 'share-section',
    description: 'شارك الحملة مع أصدقائك'
  },
  {
    id: 'map',
    label: 'خريطة الحملة',
    icon: <Map className="w-5 h-5" />,
    section: 'map-section',
    description: 'توزيع المشاركين جغرافياً'
  },
  {
    id: 'analytics',
    label: 'التحليلات',
    icon: <BarChart3 className="w-5 h-5" />,
    section: 'analytics',
    description: 'إحصائيات الحملة'
  },
  {
    id: 'testimonials',
    label: 'قصص النجاح',
    icon: <Users className="w-5 h-5" />,
    section: 'testimonials-section',
    description: 'قصص حقيقية من المشاركين'
  },
  {
    id: 'gamification',
    label: 'نظام النقاط',
    icon: <Zap className="w-5 h-5" />,
    section: 'gamification-section',
    description: 'اكسب نقاط وارتقِ بمستواك'
  },
  {
    id: 'rewards',
    label: 'المكافآت',
    icon: <Gift className="w-5 h-5" />,
    section: 'rewards-section',
    description: 'شوف المكافآت المتاحة'
  },
  {
    id: 'facts',
    label: 'هل تعلم؟',
    icon: <BookOpen className="w-5 h-5" />,
    section: 'facts-section',
    description: 'معلومات مهمة عن الإنترنت'
  },
  {
    id: 'faq',
    label: 'الأسئلة الشائعة',
    icon: <HelpCircle className="w-5 h-5" />,
    section: 'faq-section',
    description: 'إجابات على أسئلتك'
  },
  {
    id: 'comparison',
    label: 'المقارنات الدولية',
    icon: <TrendingUp className="w-5 h-5" />,
    section: 'comparison-section',
    description: 'مقارنة مصر بالدول الأخرى'
  },
  {
    id: 'roadmap',
    label: 'خارطة الطريق',
    icon: <Target className="w-5 h-5" />,
    section: 'roadmap-section',
    description: 'أهداف الحملة المستقبلية'
  }
];

export const TopNavMenu: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setIsOpen(false);
    }
  };

  return (
    <>
      {/* Top Navigation Bar - PRD 2.3 */}
      <nav className="fixed top-0 left-0 right-0 h-[60px] bg-background/80 backdrop-blur-md border-b border-border z-[60] flex items-center justify-between px-4 md:px-8 shadow-sm">
        {/* Right Side: Logo & Campaign Name */}
        <div className="flex items-center gap-3">
          <div className="relative w-10 h-10 md:w-12 md:h-12 overflow-hidden rounded-lg bg-slate-950 p-0.5 border border-primary/20">
            <img src={LOGO_IMAGE} alt="Logo" className="w-full h-full object-contain" />
          </div>
          <div className="hidden sm:block text-right">
            <h1 className="text-sm md:text-base font-black text-foreground leading-none">نطالب بإنترنت غير محدود</h1>
            <p className="text-[10px] text-primary font-bold mt-1">حملة شعبية مصرية 🇪🇬</p>
          </div>
          <span className="sm:hidden text-lg">🇪🇬</span>
        </div>

        {/* Left Side: Menu Trigger (Theme Toggle Removed) */}
        <div className="flex items-center gap-2">
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="w-10 h-10 rounded-full hover:bg-primary/10 transition-colors"
              >
                <Menu className="w-7 h-7 text-foreground" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[90vw] sm:w-[400px] p-0 bg-slate-950 border-primary/20">
              <SheetHeader className="p-6 pb-4 bg-gradient-to-b from-primary/10 to-transparent border-b border-primary/20">
                <div className="flex items-center gap-4 mb-2">
                  <div className="w-12 h-12 rounded-xl bg-slate-950 p-1 border border-primary/20">
                    <img src={LOGO_IMAGE} alt="Logo" className="w-full h-full object-contain" />
                  </div>
                  <SheetTitle className="text-xl font-black text-white text-right">
                    نطالب بإنترنت غير محدود
                  </SheetTitle>
                </div>
                <p className="text-sm text-slate-400 font-bold text-right">
                  انتقل سريعاً لأي قسم في الموقع
                </p>
              </SheetHeader>

              <ScrollArea className="h-[calc(100vh-120px)]">
                <div className="p-4 space-y-2">
                  {navigationItems.map((item, index) => (
                    <React.Fragment key={item.id}>
                      <button
                        onClick={() => scrollToSection(item.section)}
                        className="w-full flex items-center gap-4 p-4 rounded-xl bg-slate-900/50 hover:bg-slate-800 border border-slate-800 hover:border-primary/30 transition-all group text-right"
                      >
                        <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary group-hover:bg-primary/20 group-hover:scale-110 transition-all">
                          {item.icon}
                        </div>
                        <div className="flex-1 text-right">
                          <h3 className="text-base font-black text-white group-hover:text-primary transition-colors">
                            {item.label}
                          </h3>
                          {item.description && (
                            <p className="text-xs text-slate-400 font-bold mt-0.5">
                              {item.description}
                            </p>
                          )}
                        </div>
                      </button>
                      {(index + 1) % 4 === 0 && index < navigationItems.length - 1 && (
                        <Separator className="my-3 bg-slate-800" />
                      )}
                    </React.Fragment>
                  ))}
                </div>

                {/* Footer */}
                <div className="p-6 mt-4 border-t border-slate-800">
                  <div className="text-center space-y-2">
                    <p className="text-sm font-black text-primary">
                      نطالب بإنترنت غير محدود في مصر 🇪🇬
                    </p>
                    <p className="text-xs text-slate-500 font-bold">
                      معاً نقدر نغيّر 💪
                    </p>
                  </div>
                </div>
              </ScrollArea>
            </SheetContent>
          </Sheet>
        </div>
      </nav>
    </>
  );
};
