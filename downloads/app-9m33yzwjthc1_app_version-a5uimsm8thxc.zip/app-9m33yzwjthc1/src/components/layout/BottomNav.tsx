import React from 'react';
import { Home, CheckCircle2, MessageSquare, Megaphone, Gauge, Headphones } from 'lucide-react';
import { SupportDialog } from '@/components/enhanced/SupportDialog';

export const BottomNav: React.FC = () => {
  const [active, setActive] = React.useState('home');
  const [isVisible, setIsVisible] = React.useState(true);
  const [lastScrollY, setLastScrollY] = React.useState(0);
  const [isSupportDialogOpen, setIsSupportDialogOpen] = React.useState(false);

  React.useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      // Show nav when scrolling up, hide when scrolling down
      if (currentScrollY < lastScrollY || currentScrollY < 100) {
        setIsVisible(true);
      } else if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setIsVisible(false);
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const navItems = [
    { id: 'home', icon: Home, label: 'الرئيسية', href: '#hero', type: 'scroll' },
    { id: 'vote', icon: CheckCircle2, label: 'صوّت', href: '#vote-section', type: 'scroll' },
    { id: 'speed', icon: Gauge, label: 'السرعة', href: '#speed-section', type: 'scroll' },
    { id: 'comments', icon: MessageSquare, label: 'التعليقات', href: '#comments-section', type: 'scroll' },
    { id: 'share', icon: Megaphone, label: 'شارك', href: '#share-section', type: 'scroll' },
    { id: 'support', icon: Headphones, label: 'الدعم', href: '', type: 'dialog' },
  ];

  const handleClick = (id: string, href: string, type: string) => {
    if (type === 'dialog') {
      // فتح نافذة الدعم
      setIsSupportDialogOpen(true);
      setActive(id);
    } else if (type === 'external') {
      // فتح رابط خارجي في نافذة جديدة
      window.open(href, '_blank', 'noopener,noreferrer');
      setActive(id);
    } else {
      // التمرير إلى القسم
      setActive(id);
      window.location.hash = href;
      const element = document.querySelector(href);
      if (element) {
        const offset = 80;
        const elementPosition = element.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - offset;

        window.scrollTo({
          top: offsetPosition,
          behavior: 'smooth'
        });
      } else if (href === '#hero') {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }
  };

  return (
    <>
      <SupportDialog open={isSupportDialogOpen} onOpenChange={setIsSupportDialogOpen} />
      
      <nav 
        className={`fixed bottom-6 left-1/2 -translate-x-1/2 bg-slate-900/60 backdrop-blur-2xl border border-white/10 z-[100] flex justify-around items-center py-4 px-6 rounded-[2rem] shadow-[0_20px_50px_rgba(0,0,0,0.5)] w-[95%] md:w-auto md:min-w-[520px] transition-all duration-500 ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-32 opacity-0 pointer-events-none'
        }`}
      >
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => handleClick(item.id, item.href, item.type)}
            className={`flex flex-col items-center gap-1.5 transition-all duration-300 relative group ${
              active === item.id ? 'text-primary' : 'text-muted-foreground'
            } ${item.id === 'support' ? 'text-blue-400' : ''}`}
          >
            <div className={`p-1 rounded-xl transition-colors ${
              active === item.id 
                ? 'bg-primary/10' 
                : item.id === 'support' 
                  ? 'bg-blue-500/10 group-hover:bg-blue-500/20' 
                  : 'group-hover:bg-white/5'
            }`}>
              <item.icon className={`w-6 h-6 ${active === item.id ? 'stroke-[2.5px]' : 'stroke-[1.5px]'}`} />
            </div>
            <span className={`text-[11px] font-bold font-cairo ${active === item.id ? 'opacity-100' : 'opacity-80'}`}>
              {item.label}
            </span>
            {active === item.id && (
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-primary rounded-full animate-pulse shadow-[0_0_10px_#0EA5E9]" />
            )}
            {/* نقطة إشعار للدعم */}
            {item.id === 'support' && (
              <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full animate-pulse border border-slate-900" />
            )}
          </button>
        ))}
      </nav>
    </>
  );
};
