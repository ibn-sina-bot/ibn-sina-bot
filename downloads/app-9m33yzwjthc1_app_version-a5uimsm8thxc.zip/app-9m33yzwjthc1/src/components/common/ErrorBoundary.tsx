import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCcw, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
    // Here you could send the error to a logging service like Sentry
  }

  private handleReset = () => {
    this.setState({ hasError: false });
    window.location.reload();
  };

  private handleGoHome = () => {
    this.setState({ hasError: false });
    window.location.href = '/';
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
          <Card className="max-w-md w-full glass-card border-red-500/20">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <div className="p-4 bg-red-500/10 rounded-full">
                  <AlertTriangle className="w-12 h-12 text-red-500" />
                </div>
              </div>
              <CardTitle className="text-2xl font-black text-white">
                عذراً، حدث خطأ غير متوقع
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-slate-400 text-center font-bold">
                لقد واجه الموقع مشكلة تقنية. يرجى محاولة تحديث الصفحة أو العودة للرئيسية.
              </p>
              
              {/* @ts-ignore - safe environment check for Vite */}
              {import.meta.env.DEV && (
                <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                  <p className="text-xs text-red-400 font-mono break-all">
                    {this.state.error?.toString()}
                  </p>
                </div>
              )}

              <div className="flex flex-col gap-3">
                <Button 
                  onClick={this.handleReset}
                  className="w-full h-12 rounded-xl font-black gap-2"
                >
                  <RefreshCcw className="w-5 h-5" />
                  تحديث الصفحة
                </Button>
                <Button 
                  onClick={this.handleGoHome}
                  variant="outline"
                  className="w-full h-12 rounded-xl font-black gap-2"
                >
                  <Home className="w-5 h-5" />
                  العودة للرئيسية
                </Button>
              </div>
              
              <p className="text-[10px] text-slate-500 text-center font-bold">
                نحن نسجل هذه الأخطاء تلقائياً لتحسين تجربة المستخدم. شكراً لتفهمك.
              </p>
            </CardContent>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}
