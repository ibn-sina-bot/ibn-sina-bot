import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Github, Linkedin, Mail, Heart, Code, Shield } from 'lucide-react';

import { Link } from 'react-router-dom';

export const DeveloperFooter: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="mt-20 border-t border-border/50 bg-slate-950/50">
      <div className="container mx-auto px-4 py-12">
        {/* Main Content */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* About Section */}
          <div className="md:col-span-1">
            <h3 className="text-lg font-black mb-4 flex items-center gap-2">
              <Code className="w-5 h-5 text-primary" />
              عن المشروع
            </h3>
            <p className="text-sm text-muted-foreground font-bold leading-relaxed">
              موقع مجتمعي يهدف لجمع أصوات المصريين المطالبين بإنترنت غير محدود. 
              تم تطويره بشغف لخدمة المجتمع الرقمي المصري. منصة مستقلة غير رسمية.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-black mb-4">روابط سريعة</h3>
            <ul className="space-y-2 text-sm font-bold">
              <li>
                <a href="#vote-section" className="text-muted-foreground hover:text-primary transition-colors">
                  التصويت
                </a>
              </li>
              <li>
                <a href="#comments" className="text-muted-foreground hover:text-primary transition-colors">
                  التعليقات
                </a>
              </li>
              <li>
                <a href="#share-section" className="text-muted-foreground hover:text-primary transition-colors">
                  المشاركة
                </a>
              </li>
              <li>
                <a href="https://m.me/ebrahemhany690" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
                  الدعم
                </a>
              </li>
            </ul>
          </div>

          {/* Legal Links (Trust Pages) */}
          <div>
            <h3 className="text-lg font-black mb-4">قوانين الموقع</h3>
            <ul className="space-y-2 text-sm font-bold">
              <li>
                <Link to="/about" className="text-muted-foreground hover:text-primary transition-colors">
                  من نحن (عن الحملة)
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="text-muted-foreground hover:text-primary transition-colors">
                  سياسة الخصوصية
                </Link>
              </li>
              <li>
                <Link to="/terms" className="text-muted-foreground hover:text-primary transition-colors">
                  شروط الاستخدام
                </Link>
              </li>
              <li className="flex items-center gap-2 text-muted-foreground">
                <Shield className="w-3 h-3 text-green-500" />
                <span>موقع آمن ومحمي 🔒</span>
              </li>
            </ul>
          </div>

          {/* Developer Info (للمستقبل) */}
          <div>
            <h3 className="text-lg font-black mb-4">تواصل مع المطور</h3>
            <p className="text-sm text-muted-foreground font-bold mb-4">
              مطور مصري شغوف بالتكنولوجيا والتغيير الإيجابي لمستقبل مصر الرقمي.
            </p>
            <div className="flex gap-3">
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 hover:border-primary/30 transition-all opacity-50 cursor-not-allowed"
              >
                <Github className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 hover:border-primary/30 transition-all opacity-50 cursor-not-allowed"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 hover:border-primary/30 transition-all opacity-50 cursor-not-allowed"
              >
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-border/50 pt-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-muted-foreground font-bold flex items-center gap-2">
              © {currentYear} نطالب بإنترنت غير محدود في مصر. جميع الحقوق محفوظة.
            </p>
            <div className="flex items-center gap-4">
              <p className="text-sm text-muted-foreground font-bold flex items-center gap-2">
                صُنع بـ <Heart className="w-4 h-4 text-red-500 fill-red-500 animate-pulse" /> في مصر
              </p>
              <div className="hidden md:flex items-center gap-2 px-3 py-1 rounded-full bg-green-500/10 border border-green-500/20">
                <Shield className="w-3 h-3 text-green-500" />
                <span className="text-[10px] text-green-500 font-black">HTTPS SECURE</span>
              </div>
            </div>
          </div>
        </div>

        {/* Tech Stack Badge */}
        <div className="mt-6 text-center">
          <Card className="inline-block glass-card border-primary/10">
            <CardContent className="p-3">
              <p className="text-xs text-muted-foreground flex items-center gap-2">
                <Code className="w-3 h-3 text-primary" />
                Built with React + TypeScript + Supabase + Tailwind CSS
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </footer>
  );
};
