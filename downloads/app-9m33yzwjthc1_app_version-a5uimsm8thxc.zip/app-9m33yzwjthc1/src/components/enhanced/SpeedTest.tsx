import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Zap, Gauge, RefreshCw, AlertTriangle, CheckCircle2, Wifi } from 'lucide-react';

const TEST_FILE_URL = "https://miaoda-site-img.s3cdn.medo.dev/images/KLing_8f00da57-26b9-4b74-8da6-e4e2411e5b7f.jpg"; // Approx 2-5MB
const EXPECTED_SIZE_BYTES = 5 * 1024 * 1024; // Fallback if no content-length

export const SpeedTest: React.FC = () => {
  const [status, setStatus] = useState<'idle' | 'pinging' | 'downloading' | 'completed' | 'error'>('idle');
  const [downloadSpeed, setDownloadSpeed] = useState(0); // Mbps
  const [ping, setPing] = useState(0); // ms
  const [progress, setProgress] = useState(0);
  const [errorMessage, setErrorMessage] = useState('');
  
  const abortControllerRef = useRef<AbortController | null>(null);

  const runTest = async () => {
    setStatus('pinging');
    setProgress(0);
    setDownloadSpeed(0);
    setPing(0);
    setErrorMessage('');

    abortControllerRef.current = new AbortController();

    try {
      // Step 1: Ping Test (Latency)
      const pingStart = performance.now();
      await fetch(TEST_FILE_URL, { 
        method: 'HEAD', 
        cache: 'no-store',
        signal: abortControllerRef.current.signal 
      });
      const pingEnd = performance.now();
      setPing(Math.round(pingEnd - pingStart));

      // Step 2: Download Speed Test
      setStatus('downloading');
      const downloadStart = performance.now();
      const response = await fetch(TEST_FILE_URL, { 
        cache: 'no-store',
        signal: abortControllerRef.current.signal 
      });

      if (!response.body) throw new Error("لم نتمكن من بدء تدفق البيانات");

      const reader = response.body.getReader();
      const contentLength = Number(response.headers.get('Content-Length')) || EXPECTED_SIZE_BYTES;
      
      let receivedBytes = 0;
      let lastUpdate = performance.now();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        receivedBytes += value.length;
        const now = performance.now();
        
        // Calculate speed every 200ms
        if (now - lastUpdate > 200) {
          const durationSec = (now - downloadStart) / 1000;
          const currentSpeedMbps = (receivedBytes * 8) / (1024 * 1024 * durationSec);
          setDownloadSpeed(Number(currentSpeedMbps.toFixed(2)));
          setProgress(Math.min(95, Math.round((receivedBytes / contentLength) * 100)));
          lastUpdate = now;
        }
      }

      const totalDurationSec = (performance.now() - downloadStart) / 1000;
      const finalSpeedMbps = (receivedBytes * 8) / (1024 * 1024 * totalDurationSec);
      
      setDownloadSpeed(Number(finalSpeedMbps.toFixed(2)));
      setProgress(100);
      setStatus('completed');

    } catch (err: any) {
      if (err.name === 'AbortError') return;
      console.error("Speed test error:", err);
      setStatus('error');
      setErrorMessage("حدث خطأ أثناء الاتصال بالخادم. تأكد من اتصالك بالإنترنت.");
    }
  };

  const cancelTest = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setStatus('idle');
  };

  useEffect(() => {
    return () => {
      if (abortControllerRef.current) abortControllerRef.current.abort();
    };
  }, []);

  return (
    <Card className="glass-card overflow-hidden border-primary/20 relative">
      {/* Decorative gradient background when testing */}
      {status !== 'idle' && status !== 'error' && (
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 -z-10 animate-pulse" />
      )}

      <CardHeader className="bg-primary/5 pb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${status === 'downloading' ? 'bg-primary/20 animate-pulse' : 'bg-primary/10'}`}>
              <Zap className={`w-6 h-6 ${status === 'downloading' ? 'text-primary' : 'text-primary'}`} />
            </div>
            <div>
              <CardTitle className="text-2xl font-black">اختبار سرعة حقيقي</CardTitle>
              <CardDescription className="text-sm">قياس مباشر من داخل الموقع لسرعة اتصالك الحالية</CardDescription>
            </div>
          </div>
          {status === 'completed' && <Badge className="bg-primary/20 text-primary border-primary/20">تم القياس بنجاح</Badge>}
        </div>
      </CardHeader>

      <CardContent className="p-6 space-y-8">
        {/* Speed Gauges */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Download Gauge */}
          <div className={`relative p-8 rounded-[2.5rem] border-2 transition-all duration-500 flex flex-col items-center justify-center overflow-hidden ${
            status === 'downloading' ? 'border-primary bg-primary/5' : 'border-border bg-muted/20'
          }`}>
            <div className="absolute top-4 right-6 text-xs font-bold opacity-30 uppercase tracking-widest">Download</div>
            <div className="flex flex-col items-center gap-1 z-10">
              <span className={`text-6xl md:text-7xl font-black tracking-tighter ${status === 'completed' ? 'text-primary' : status === 'downloading' ? 'text-primary' : 'text-muted-foreground'}`}>
                {downloadSpeed > 0 ? downloadSpeed : '0.0'}
              </span>
              <span className="text-sm font-bold opacity-60 text-primary">Mbps</span>
            </div>
            {status === 'downloading' && (
              <div className="absolute bottom-0 left-0 h-1 bg-primary shadow-[0_0_15px_#0EA5E9] transition-all duration-200" style={{ width: `${progress}%` }} />
            )}
          </div>

          {/* Latency & Info */}
          <div className="space-y-4">
            <div className="p-5 rounded-3xl bg-muted/40 border border-border flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Wifi className="w-5 h-5 text-primary" />
                <span className="font-bold">زمن الاستجابة (Ping)</span>
              </div>
              <div className="text-right">
                <span className="text-2xl font-black text-primary">{ping > 0 ? ping : '--'}</span>
                <span className="text-xs ml-1 opacity-60">ms</span>
              </div>
            </div>

            <div className="p-5 rounded-3xl bg-muted/40 border border-border flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Gauge className="w-5 h-5 text-primary" />
                <span className="font-bold">درجة الاستقرار</span>
              </div>
              <div className="text-right">
                <span className="text-sm font-bold text-primary">
                  {status === 'completed' ? (downloadSpeed > 20 ? 'ممتاز' : 'متوسط') : '--'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Action Button & Progress */}
        <div className="space-y-4">
          {status === 'downloading' || status === 'pinging' ? (
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs font-bold">
                <span className="flex items-center gap-2">
                  <RefreshCw className="w-3 h-3 animate-spin text-primary" />
                  {status === 'pinging' ? 'جاري قياس زمن الاستجابة...' : 'جاري تحميل ملف الاختبار...'}
                </span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} className="h-2 bg-primary/10" />
              <Button variant="ghost" onClick={cancelTest} className="w-full text-xs text-muted-foreground">إلغاء الاختبار</Button>
            </div>
          ) : (
            <Button 
              onClick={runTest} 
              className="w-full py-8 text-xl font-black gap-3 shadow-[0_0_20px_rgba(14,165,233,0.2)] hover:scale-[1.01] transition-transform active:scale-95 bg-primary hover:bg-primary/90 text-white rounded-2xl"
            >
              <Zap className="w-6 h-6" /> ابدأ الاختبار الآن
            </Button>
          )}

          {status === 'error' && (
            <div className="p-4 rounded-2xl bg-destructive/10 border border-destructive/20 text-destructive text-sm flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <p className="font-bold">{errorMessage}</p>
            </div>
          )}

          {status === 'completed' && (
            <div className="p-6 rounded-3xl bg-green-500/5 border border-green-500/20 space-y-3 animate-in fade-in zoom-in-95 duration-500">
              <div className="flex items-center gap-2 text-green-600 font-black">
                <CheckCircle2 className="w-5 h-5" /> هل هذه السرعة تكفيك؟
              </div>
              <p className="text-sm leading-relaxed text-muted-foreground">
                تذكر أن هذه السرعة الرائعة تستهلك باقتك المحدودة في دقائق معدودة. لهذا السبب نطالب بإنترنت غير محدود، لتستمتع بسرعتك الحقيقية دون خوف من انتهاء الباقة.
              </p>
              <div className="pt-2">
                <Button variant="link" className="p-0 h-auto text-accent font-bold" onClick={() => document.getElementById('vote-section')?.scrollIntoView({behavior:'smooth'})}>
                  صوّت الآن لتغيير هذا الوضع ←
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Technical Footer */}
        <div className="pt-4 border-t border-border flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] text-muted-foreground uppercase tracking-widest font-bold">
          <div className="flex items-center gap-1">
            <span className="w-1 h-1 rounded-full bg-green-500" /> Server: Global Edge Network
          </div>
          <div>Method: TCP Streaming / XHR Progress</div>
          <div>Asset: 4K Reference Image (Ref-092)</div>
        </div>
      </CardContent>
    </Card>
  );
};

const Badge = ({ children, className }: { children: React.ReactNode, className?: string }) => (
  <span className={`px-2 py-0.5 rounded-full text-[10px] font-black border ${className}`}>
    {children}
  </span>
);
