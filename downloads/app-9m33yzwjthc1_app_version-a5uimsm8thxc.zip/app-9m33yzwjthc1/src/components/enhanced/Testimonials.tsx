import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Testimonial } from '@/db/api';
import { Quote } from 'lucide-react';

interface Props {
  testimonials: Testimonial[];
}

export const Testimonials: React.FC<Props> = ({ testimonials }) => {
  return (
    <div className="space-y-8">
      <h2 className="text-3xl font-bold text-center">قصص من قلب الواقع 💬</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {testimonials.map((t) => (
          <Card key={t.id} className="glass-card relative overflow-hidden">
            <Quote className="absolute top-4 left-4 w-12 h-12 text-primary/10 -rotate-12" />
            <CardContent className="p-8 pt-12 space-y-4">
              <p className="text-lg italic leading-relaxed text-foreground/80">
                "{t.story}"
              </p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-xl">
                  {t.name.charAt(0)}
                </div>
                <div>
                  <h4 className="font-bold">{t.name}</h4>
                  <p className="text-xs text-muted-foreground">{t.role}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};
