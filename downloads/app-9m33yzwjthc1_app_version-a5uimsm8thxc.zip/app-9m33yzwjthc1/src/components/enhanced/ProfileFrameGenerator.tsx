import React, { useRef, useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Camera, Download, RotateCcw, ZoomIn, ZoomOut, Move, Share2, Facebook, MessageCircle, RefreshCw } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import Cropper from 'react-easy-crop';
import { toast } from 'sonner';

const LOGO_IMAGE = "https://miaoda-conversation-file.s3cdn.medo.dev/user-9il5qwkjedq8/conv-9m33yzwjthc0/20260310/file-a5uac79v6kg0.png";

export const ProfileFrameGenerator: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState<any>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const onCropComplete = useCallback((_croppedArea: any, croppedAreaPixels: any) => {
    setCroppedAreaPixels(croppedAreaPixels);
  }, []);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error('حجم الصورة كبير جداً، يرجى اختيار صورة أقل من 5 ميجابايت');
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        setImage(event.target?.result as string);
        setZoom(1);
        setCrop({ x: 0, y: 0 });
      };
      reader.readAsDataURL(file);
    }
  };

  const createCroppedImage = async () => {
    if (!image || !croppedAreaPixels) return null;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    const img = new Image();
    img.src = image;
    await new Promise((resolve) => (img.onload = resolve));

    // Set high quality canvas size
    canvas.width = 1000;
    canvas.height = 1000;

    // 1. Draw User Cropped Image
    ctx.drawImage(
      img,
      croppedAreaPixels.x,
      croppedAreaPixels.y,
      croppedAreaPixels.width,
      croppedAreaPixels.height,
      0,
      0,
      1000,
      1000
    );

    // 2. Draw Frame Overlay
    // Design a professional overlay directly on canvas
    
    // Bottom Flag Stripes (Horizontal)
    const stripeHeight = 40;
    const flagYStart = 1000 - (stripeHeight * 3);
    
    // Red Stripe (Top)
    ctx.fillStyle = '#ce1126'; 
    ctx.fillRect(0, flagYStart, 1000, stripeHeight);
    
    // White Stripe (Middle)
    ctx.fillStyle = '#ffffff'; 
    ctx.fillRect(0, flagYStart + stripeHeight, 1000, stripeHeight);
    
    // Black Stripe (Bottom)
    ctx.fillStyle = '#000000'; 
    ctx.fillRect(0, flagYStart + (stripeHeight * 2), 1000, stripeHeight);

    // Add Egyptian Golden Eagle to the left side of the white stripe
    ctx.fillStyle = '#c09300'; // Golden color
    ctx.font = '36px Cairo, system-ui';
    ctx.textAlign = 'left';
    ctx.fillText('🦅', 100, flagYStart + stripeHeight + 30);

    // Text Content on white stripe
    ctx.fillStyle = '#000000'; // Black text on white stripe
    ctx.font = 'bold 30px Cairo, system-ui';
    ctx.textAlign = 'center';
    ctx.direction = 'rtl';
    ctx.fillText('نطالب بإنترنت غير محدود في مصر', 550, flagYStart + stripeHeight + 30);
    
    // URL at the bottom (on black stripe)
    ctx.fillStyle = '#ffffff'; 
    ctx.font = 'bold 22px Courier New, monospace';
    ctx.textAlign = 'center';
    ctx.fillText(window.location.host, 500, flagYStart + (stripeHeight * 2) + 28);

    // Top Right Corner Badge (Updated Design)
    ctx.save();
    ctx.shadowBlur = 15;
    ctx.shadowColor = 'rgba(14, 165, 233, 0.5)';
    ctx.fillStyle = '#0ea5e9';
    ctx.beginPath();
    ctx.moveTo(800, 0);
    ctx.lineTo(1000, 0);
    ctx.lineTo(1000, 150);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // Logo on badge
    const logoImg = new Image();
    logoImg.crossOrigin = "anonymous";
    logoImg.src = LOGO_IMAGE;
    await new Promise((resolve) => {
      logoImg.onload = resolve;
      logoImg.onerror = resolve; // Continue even if logo fails
    });
    
    if (logoImg.complete && logoImg.naturalWidth > 0) {
      ctx.save();
      ctx.shadowBlur = 10;
      ctx.shadowColor = 'rgba(0,0,0,0.5)';
      ctx.drawImage(logoImg, 880, 20, 80, 80);
      ctx.restore();
    }

    return canvas.toDataURL('image/png', 1.0);
  };

  const handleDownload = async () => {
    setIsGenerating(true);
    try {
      const dataUrl = await createCroppedImage();
      if (dataUrl) {
        const link = document.createElement('a');
        link.download = 'unlimited-internet-profile.png';
        link.href = dataUrl;
        link.click();
        toast.success('تم تحميل صورتك بالإطار الجديد! 📸');
      }
    } catch (error) {
      console.error('Error generating frame:', error);
      toast.error('حدث خطأ أثناء معالجة الصورة');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleShare = async () => {
    if (!image) {
      toast.error('يرجى رفع صورتك أولاً');
      return;
    }

    const shareToast = toast.loading('جاري تجهيز صورتك بالإطار...');
    
    try {
      const dataUrl = await createCroppedImage();
      if (!dataUrl) throw new Error('Image creation failed');
      
      const response = await fetch(dataUrl);
      const blob = await response.blob();
      
      const file = new File([blob], 'profile-frame.png', { type: 'image/png' });
      const shareData = {
        files: [file],
        title: 'صورتي الشخصية تدعم إنترنت غير محدود',
        text: 'أنا أدعم حملة إنترنت غير محدود في مصر 🇪🇬 غير صورتك الآن وانضم إلينا!',
        url: window.location.origin,
      };

      if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
        await navigator.share(shareData);
        toast.dismiss(shareToast);
      } else {
        toast.dismiss(shareToast);
        toast.info('ميزة المشاركة المباشرة غير مدعومة، سيتم تحميل الصورة');
        handleDownload();
      }
    } catch (error: any) {
      console.error('Sharing failed:', error);
      toast.dismiss(shareToast);
      if (error.name !== 'AbortError') {
        toast.error('حدث خطأ أثناء المشاركة');
        handleDownload();
      }
    }
  };

  return (
    <Card className="glass-card overflow-hidden border-primary/20">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl font-black gradient-text flex items-center justify-center gap-2">
          🖼️ إطار الداعمين الذهبي
        </CardTitle>
        <CardDescription>
          أضف لمسة احترافية لصورتك الشخصية لتعبر عن انتمائك للحملة
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Image Picker / Cropper Area */}
        <div className="relative aspect-square w-full max-w-[400px] mx-auto bg-slate-900 rounded-3xl overflow-hidden shadow-inner border-2 border-dashed border-white/10 group">
          {image ? (
            <div className="relative w-full h-full">
              <Cropper
                image={image}
                crop={crop}
                zoom={zoom}
                aspect={1}
                onCropChange={setCrop}
                onCropComplete={onCropComplete}
                onZoomChange={setZoom}
                showGrid={false}
                style={{
                  containerStyle: { borderRadius: '1.5rem' }
                }}
              />
              {/* Virtual Overlay for preview */}
              <div className="absolute inset-0 pointer-events-none z-10 flex flex-col justify-end">
                {/* Horizontal Flag Stripes */}
                <div className="w-full h-3 bg-[#ce1126]" />
                <div className="w-full h-3 bg-white flex items-center justify-center gap-1">
                  <span className="text-[6px] text-[#c09300]">🦅</span>
                  <p className="text-[6px] md:text-[8px] font-black text-black leading-none" style={{ direction: 'rtl', unicodeBidi: 'embed', letterSpacing: '0px' }}>نطالب بإنترنت غير محدود في مصر</p>
                </div>
                <div className="w-full h-3 bg-black flex items-center justify-center">
                  <p className="text-[5px] md:text-[6px] text-white font-mono leading-none opacity-80">{window.location.host}</p>
                </div>
                
                {/* Top Right Corner Badge */}
                <div className="absolute top-0 right-0 w-[20%] h-[20%] bg-primary/20 backdrop-blur-sm rounded-bl-3xl border-l border-b border-white/10 flex items-center justify-center">
                  <img src={LOGO_IMAGE} alt="Logo" className="w-6 h-6 opacity-80" />
                </div>
              </div>
            </div>
          ) : (
            <div 
              className="absolute inset-0 flex flex-col items-center justify-center gap-4 cursor-pointer hover:bg-white/5 transition-colors"
              onClick={() => fileInputRef.current?.click()}
            >
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20 animate-pulse">
                <Camera className="w-8 h-8 text-primary" />
              </div>
              <div className="text-center px-4">
                <p className="font-bold text-white">اضغط هنا لرفع صورتك</p>
                <p className="text-xs text-muted-foreground mt-1">يُفضل استخدام صورة مربعة واضحة</p>
              </div>
            </div>
          )}
        </div>

        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleImageUpload} 
          accept="image/*" 
          className="hidden" 
        />

        {image && (
          <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2">
            {/* Controls */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold text-muted-foreground">
                <span className="flex items-center gap-1"><ZoomIn className="w-3 h-3" /> تكبير / تصغير</span>
                <span>{Math.round(zoom * 100)}%</span>
              </div>
              <Slider 
                value={[zoom]} 
                min={1} 
                max={3} 
                step={0.1} 
                onValueChange={([val]) => setZoom(val)}
                className="py-4"
              />
            </div>

            <div className="flex gap-2">
              <Button 
                variant="outline" 
                className="flex-1 rounded-xl gap-2 h-10 text-xs border-white/10"
                onClick={() => { setZoom(1); setCrop({ x: 0, y: 0 }); }}
              >
                <RotateCcw className="w-4 h-4" /> إعادة ضبط
              </Button>
              <Button 
                variant="outline" 
                className="flex-1 rounded-xl gap-2 h-10 text-xs border-white/10"
                onClick={() => fileInputRef.current?.click()}
              >
                <RefreshCw className="w-4 h-4" /> تغيير الصورة
              </Button>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
          <Button 
            className="h-14 rounded-2xl font-black text-lg gap-2 shadow-xl shadow-primary/20 transition-all hover:scale-[1.02]" 
            disabled={!image || isGenerating}
            onClick={handleDownload}
          >
            {isGenerating ? <RotateCcw className="w-5 h-5 animate-spin" /> : <Download className="w-6 h-6" />}
            تحميل الصورة HD
          </Button>
          
          <div className="flex gap-2">
            <Button 
              variant="outline"
              className="flex-1 h-14 rounded-2xl font-bold border-primary/20 gap-2"
              onClick={handleShare}
              disabled={!image}
            >
              <Share2 className="w-5 h-5 text-primary" />
              مشاركة سريعة
            </Button>
            <Button 
              variant="outline"
              size="icon"
              className="w-14 h-14 rounded-2xl border-blue-500/20 text-blue-500"
              onClick={() => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`, '_blank')}
            >
              <Facebook className="w-6 h-6" />
            </Button>
            <Button 
              variant="outline"
              size="icon"
              className="w-14 h-14 rounded-2xl border-green-500/20 text-green-500"
              onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent('أنا أدعم حملة إنترنت غير محدود في مصر! غير صورتك الآن: ' + window.location.href)}`, '_blank')}
            >
              <MessageCircle className="w-6 h-6" />
            </Button>
          </div>
        </div>
        
        <p className="text-[10px] text-center text-muted-foreground italic">
          * نوصي باستخدام متصفح كروم أو سفاري للحصول على أفضل جودة تحميل
        </p>
      </CardContent>
    </Card>
  );
};
