import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Globe2, TrendingUp, Users, Wifi } from 'lucide-react';

export const GlobalSuccessStories: React.FC = () => {
  const stories = [
    {
      country: 'كوريا الجنوبية',
      title: 'المعجزة الكورية',
      description: 'كيف تحولت من دولة نامية إلى صاحبة أسرع إنترنت في العالم بفضل الاستراتيجية الوطنية والطلب الشعبي القوي.',
      icon: <TrendingUp className="w-6 h-6 text-red-500" />,
      stats: 'متوسط سرعة 200+ ميجابت'
    },
    {
      country: 'رومانيا',
      title: 'ثورة الشبكات المحلية',
      description: 'بدأت بمبادرات شبابية لربط الأحياء ببعضها، لتصبح اليوم من أرخص وأسرع خدمات الإنترنت في أوروبا.',
      icon: <Users className="w-6 h-6 text-blue-500" />,
      stats: 'أسعار تبدأ من 5$ شهرياً'
    },
    {
      country: 'إستونيا',
      title: 'الحق الرقمي',
      description: 'أول دولة في العالم تعتبر الوصول للإنترنت حقاً أساسياً للمواطن، مما جعلها رائدة في الخدمات الرقمية.',
      icon: <Wifi className="w-6 h-6 text-green-500" />,
      stats: 'إنترنت مجاني في الأماكن العامة'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-black flex items-center justify-center gap-2">
          <Globe2 className="w-8 h-8 text-primary" /> قصص نجاح عالمية 🌍
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          التغيير ممكن! هذه الدول بدأت من الصفر ووصلت للقمة بفضل الإرادة والعمل المشترك.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stories.map((story) => (
          <Card key={story.country} className="glass-card hover:-translate-y-2 transition-transform duration-300">
            <CardHeader className="space-y-4">
              <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center border border-white/10 mx-auto">
                {story.icon}
              </div>
              <CardTitle className="text-center space-y-1">
                <div className="text-sm text-primary font-bold uppercase tracking-wider">{story.country}</div>
                <div className="text-xl">{story.title}</div>
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <p className="text-sm text-muted-foreground leading-relaxed">
                {story.description}
              </p>
              <div className="py-2 px-4 rounded-full bg-primary/10 text-primary text-xs font-bold inline-block">
                🚀 {story.stats}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-12 text-center">
        <div className="inline-block glass-card p-6 md:px-12 rounded-3xl border-primary/20 shadow-xl shadow-primary/5 hover:scale-[1.02] transition-transform duration-300">
          <p className="text-lg md:text-2xl font-black gradient-text leading-relaxed">
            مصر ليست أقل من هذه الدول، وبصوتك يمكننا أن نكون القصة القادمة 🇪🇬💪
          </p>
        </div>
      </div>
    </div>
  );
};
