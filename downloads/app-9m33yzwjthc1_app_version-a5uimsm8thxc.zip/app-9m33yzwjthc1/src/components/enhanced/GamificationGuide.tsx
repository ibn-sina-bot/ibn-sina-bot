import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Trophy, HelpCircle, Share2, MessageSquare, CheckCircle2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export const GamificationGuide: React.FC = () => {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-2 text-primary hover:text-primary/80 hover:bg-primary/10">
          <HelpCircle className="w-4 h-4" />
          كيف يعمل نظام النقاط؟
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl bg-slate-950 border-primary/20">
        <DialogHeader>
          <DialogTitle className="text-2xl font-black text-center flex items-center justify-center gap-2">
            <Trophy className="w-8 h-8 text-yellow-500" />
            دليل نظام النقاط والرتب
          </DialogTitle>
          <DialogDescription className="text-center pt-2">
            كل تفاعل منك يساهم في نجاح الحملة، ونحن نكافئك عليه بنقاط ترفع رتبتك وتأثيرك!
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {/* Points System */}
          <div className="space-y-3">
            <h3 className="text-lg font-bold text-primary flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5" /> كيف تكسب النقاط؟
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 mx-auto text-green-500" />
                <p className="font-bold">تصويت</p>
                <Badge variant="outline" className="text-green-500 border-green-500/30">+1 نقطة</Badge>
                <p className="text-xs text-muted-foreground">عند التصويت لأول مرة</p>
              </div>
              <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-center space-y-2">
                <Share2 className="w-8 h-8 mx-auto text-blue-500" />
                <p className="font-bold">مشاركة</p>
                <Badge variant="outline" className="text-blue-500 border-blue-500/30">+2 نقطة</Badge>
                <p className="text-xs text-muted-foreground">لكل مشاركة على منصات التواصل</p>
              </div>
              <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-center space-y-2">
                <MessageSquare className="w-8 h-8 mx-auto text-orange-500" />
                <p className="font-bold">تعليق</p>
                <Badge variant="outline" className="text-orange-500 border-orange-500/30">+1 نقطة</Badge>
                <p className="text-xs text-muted-foreground">عند إضافة تعليق (بعد الموافقة)</p>
              </div>
            </div>
          </div>

          {/* Ranks System */}
          <div className="space-y-3">
            <h3 className="text-lg font-bold text-primary flex items-center gap-2">
              <Trophy className="w-5 h-5" /> الرتب والمستويات
            </h3>
            <div className="space-y-2">
              <div className="flex items-center gap-4 p-3 rounded-lg bg-slate-900/50 border border-slate-800">
                <div className="w-10 h-10 rounded-full bg-slate-500/20 flex items-center justify-center">
                  <span className="text-xl">🛡️</span>
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center">
                    <h4 className="font-bold text-slate-400">داعم مشارك</h4>
                    <span className="text-xs font-mono bg-slate-500/20 px-2 py-1 rounded text-slate-400">0 - 4 نقاط</span>
                  </div>
                  <p className="text-xs text-muted-foreground">بداية رحلتك في المطالبة بحقوق الإنترنت.</p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-3 rounded-lg bg-primary/10 border border-primary/20">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                  <span className="text-xl">🎓</span>
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center">
                    <h4 className="font-bold text-primary">سفير الحملة</h4>
                    <span className="text-xs font-mono bg-primary/20 px-2 py-1 rounded text-primary">5 - 14 نقطة</span>
                  </div>
                  <p className="text-xs text-muted-foreground">لقد أثبت التزامك وبدأت في نشر الوعي.</p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                  <span className="text-xl">🚀</span>
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center">
                    <h4 className="font-bold text-red-500">قائد حملة</h4>
                    <span className="text-xs font-mono bg-red-500/20 px-2 py-1 rounded text-red-500">15+ نقطة</span>
                  </div>
                  <p className="text-xs text-muted-foreground">أنت من نخبة المؤثرين والقادة في هذه الحركة!</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
