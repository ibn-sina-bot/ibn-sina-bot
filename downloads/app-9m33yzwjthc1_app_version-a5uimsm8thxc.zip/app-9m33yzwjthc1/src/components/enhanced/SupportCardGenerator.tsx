import React, { useRef, useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Download, Camera, Share2, Facebook, MessageCircle, ShieldCheck, Loader2 } from 'lucide-react';
import html2canvas from 'html2canvas';
import QRCode from 'qrcode';
import { toast } from 'sonner';
import { generateFingerprint } from '@/lib/utils';

import { getUserPoints, getLevelInfo, LevelInfo } from '@/db/api';

const LOGO_IMAGE = "https://miaoda-conversation-file.s3cdn.medo.dev/user-9il5qwkjedq8/conv-9m33yzwjthc0/20260310/file-a5uac79v6kg0.png";

export const SupportCardGenerator: React.FC = () => {
  const [userName, setUserName] = useState('');
  const [userLevel, setUserLevel] = useState<LevelInfo | null>(null);
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('');
  const cardRef = useRef<HTMLDivElement>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    const fetchPoints = async () => {
      const fp = generateFingerprint();
      const data = await getUserPoints(fp);
      if (data) {
        const levelInfo = getLevelInfo(data.points);
        setUserLevel(levelInfo);
      }
    };
    fetchPoints();
    
    // Generate actual QR code for the campaign URL
    const generateQR = async () => {
      try {
        const url = await QRCode.toDataURL(window.location.origin, {
          margin: 1,
          width: 300,
          color: {
            dark: '#0f172a',
            light: '#ffffff'
          }
        });
        setQrCodeUrl(url);
      } catch (err) {
        console.error('QR Error:', err);
      }
    };
    generateQR();
  }, []);

  const downloadCard = async () => {
    if (!userName.trim()) {
      toast.error('يرجى كتابة اسمك أولاً');
      return;
    }

    if (!cardRef.current) return;
    
    setIsGenerating(true);
    try {
      const canvas = await html2canvas(cardRef.current, {
        scale: 4, // Ultra high quality for printing/sharing
        useCORS: true,
        backgroundColor: null,
        logging: false,
        onclone: (clonedDoc) => {
          // Force visibility on cloned document to ensure it renders correctly
          const element = clonedDoc.querySelector('[data-capture-target="id-card"]') as HTMLElement;
          if (element) {
            element.style.display = 'flex';
          }
        }
      });
      
      const link = document.createElement('a');
      link.download = `egypt-unlimited-id-${userName}.png`;
      link.href = canvas.toDataURL('image/png', 1.0);
      link.click();
      toast.success('تم تحميل بطاقتك بنجاح! 🚀');
    } catch (error) {
      console.error('Error generating card:', error);
      toast.error('حدث خطأ أثناء تحميل البطاقة');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleShare = async () => {
    if (!userName.trim()) {
      toast.error('يرجى كتابة اسمك أولاً');
      return;
    }

    if (!cardRef.current) return;

    const shareToast = toast.loading('جاري تجهيز الهوية للمشاركة...');
    
    try {
      const canvas = await html2canvas(cardRef.current, { scale: 3, useCORS: true });
      const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/png', 0.9));
      
      if (!blob) throw new Error('Blob generation failed');

      const file = new File([blob], 'egypt-unlimited-id.png', { type: 'image/png' });
      
      const shareData = {
        files: [file],
        title: 'هويتي في حملة إنترنت غير محدود',
        text: 'أنا أدعم حملة إنترنت غير محدود في مصر 🇪🇬 انضم إلينا وصمم هويتك الآن!',
        url: window.location.origin,
      };

      if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
        await navigator.share(shareData);
        toast.dismiss(shareToast);
      } else {
        toast.dismiss(shareToast);
        toast.info('ميزة المشاركة المباشرة غير مدعومة، سيتم تحميل الهوية');
        downloadCard();
      }
    } catch (error) {
      console.error('Sharing failed:', error);
      toast.dismiss(shareToast);
      toast.error('عذراً، حدث خطأ أثناء المشاركة');
      // Fallback
      downloadCard();
    }
  };

  return (
    <Card className="glass-card overflow-hidden border-primary/20">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl font-black gradient-text flex items-center justify-center gap-2">
          🪪 هويتك الرقمية في الحملة
        </CardTitle>
        <CardDescription>
          صمم بطاقة احترافية برمز QR حقيقي يوصل لأي شخص لموقع الحملة
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-8">
        {/* Input Section */}
        <div className="space-y-3">
          <label className="text-sm font-black block text-center">أدخل اسمك الكريم</label>
          <Input 
            placeholder="مثال: أحمد محمد..." 
            value={userName} 
            onChange={(e) => setUserName(e.target.value)}
            className="text-center h-12 text-lg rounded-xl border-primary/20 bg-primary/5 focus:ring-primary/40 transition-all font-bold"
            maxLength={25}
          />
        </div>

        {/* Card Preview Container */}
        <div className="flex justify-center relative py-4">
          <div className="absolute inset-0 bg-primary/5 blur-3xl rounded-full -z-10" />
          
          {/* THE DIGITAL ID CARD (Capture Target) - تصميم محسّن مع خلفية شبكة الإنترنت */}
          <div 
            ref={cardRef}
            data-capture-target="id-card"
            dir="rtl"
            className={`w-[350px] h-[220px] md:w-[480px] md:h-[280px] rounded-3xl relative overflow-hidden shadow-2xl select-none text-white flex flex-col font-sans transition-all duration-300 ${
              userLevel?.frameStyle === 'gold' 
                ? 'border-4 border-amber-400 shadow-amber-400/50' 
                : userLevel?.frameStyle === 'silver'
                ? 'border-3 border-slate-300 shadow-slate-300/30'
                : userLevel?.frameStyle === 'diamond'
                ? 'border-4 border-pink-400 shadow-pink-400/50'
                : 'border-2 border-primary/30'
            }`}
            style={{
              background: userLevel?.frameStyle === 'gold'
                ? 'linear-gradient(135deg, #1e3a8a 0%, #1e40af 50%, #78350f 100%)'
                : userLevel?.frameStyle === 'diamond'
                ? 'linear-gradient(135deg, #1e3a8a 0%, #831843 50%, #500724 100%)'
                : 'linear-gradient(135deg, #0c1e3d 0%, #1e3a8a 50%, #0f172a 100%)',
            }}
          >
            {/* خلفية شبكة الإنترنت المتحركة */}
            <div className="absolute inset-0 opacity-20">
              <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  <pattern id="network-pattern" x="0" y="0" width="80" height="80" patternUnits="userSpaceOnUse">
                    <circle cx="10" cy="10" r="2" fill="currentColor" className="text-primary" opacity="0.6">
                      <animate attributeName="opacity" values="0.3;0.8;0.3" dur="3s" repeatCount="indefinite" />
                    </circle>
                    <circle cx="70" cy="10" r="2" fill="currentColor" className="text-primary" opacity="0.6">
                      <animate attributeName="opacity" values="0.8;0.3;0.8" dur="3s" repeatCount="indefinite" />
                    </circle>
                    <circle cx="10" cy="70" r="2" fill="currentColor" className="text-primary" opacity="0.6">
                      <animate attributeName="opacity" values="0.5;1;0.5" dur="3s" repeatCount="indefinite" />
                    </circle>
                    <circle cx="70" cy="70" r="2" fill="currentColor" className="text-primary" opacity="0.6">
                      <animate attributeName="opacity" values="1;0.5;1" dur="3s" repeatCount="indefinite" />
                    </circle>
                    <line x1="10" y1="10" x2="70" y2="10" stroke="currentColor" strokeWidth="0.5" className="text-primary" opacity="0.3" />
                    <line x1="10" y1="10" x2="10" y2="70" stroke="currentColor" strokeWidth="0.5" className="text-primary" opacity="0.3" />
                    <line x1="70" y1="10" x2="70" y2="70" stroke="currentColor" strokeWidth="0.5" className="text-primary" opacity="0.3" />
                    <line x1="10" y1="70" x2="70" y2="70" stroke="currentColor" strokeWidth="0.5" className="text-primary" opacity="0.3" />
                    <line x1="10" y1="10" x2="70" y2="70" stroke="currentColor" strokeWidth="0.5" className="text-primary" opacity="0.2" />
                    <line x1="70" y1="10" x2="10" y2="70" stroke="currentColor" strokeWidth="0.5" className="text-primary" opacity="0.2" />
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#network-pattern)" />
              </svg>
            </div>

            {/* نجوم متلألئة في الخلفية */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              {[...Array(20)].map((_, i) => (
                <div
                  key={i}
                  className="absolute w-1 h-1 bg-white rounded-full"
                  style={{
                    top: `${Math.random() * 100}%`,
                    left: `${Math.random() * 100}%`,
                    opacity: Math.random() * 0.5 + 0.3,
                    animation: `twinkle ${Math.random() * 3 + 2}s infinite ${Math.random() * 2}s`,
                  }}
                />
              ))}
            </div>

            {/* تأثير الضوء المتحرك */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-transparent to-transparent opacity-50" />
            
            {/* Egypt Flag Header Stripe - محسّن */}
            <div className="absolute top-0 left-0 w-full h-[12px] flex shadow-lg z-10">
              <div className="flex-1 bg-[#ce1126]" />
              <div className="flex-1 bg-white flex items-center justify-center">
                <span className="text-[8px]">🦅</span>
              </div>
              <div className="flex-1 bg-black" />
            </div>
            
            {/* Level Badge - Top Left Corner - محسّن */}
            {userLevel && userLevel.level > 1 && (
              <div className={`absolute top-4 left-4 px-3 py-1.5 rounded-full ${userLevel.bgColor} ${userLevel.borderColor} border-2 backdrop-blur-md flex items-center gap-1.5 shadow-xl z-20`}>
                <span className="text-sm">{userLevel.icon}</span>
                <span className={`text-[10px] font-black ${userLevel.color}`}>
                  المستوى {userLevel.level}
                </span>
              </div>
            )}
            
            {/* Card Header Content - محسّن */}
            <div className="pt-[16px] px-6 pb-3 flex justify-between items-center border-b border-white/10 bg-gradient-to-b from-white/10 to-transparent backdrop-blur-sm relative z-10">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 md:w-14 md:h-14 bg-slate-950 rounded-2xl flex items-center justify-center p-1 shadow-2xl ${
                  userLevel?.frameStyle === 'gold' ? 'border-2 border-amber-400 shadow-amber-400/50' : 'border-2 border-primary/20'
                }`}>
                   <img src={LOGO_IMAGE} alt="Logo" className="w-full h-full object-contain rounded-xl" />
                </div>
                <div className="text-right">
                  <h4 className="text-[11px] md:text-sm font-black text-white leading-tight drop-shadow-lg" style={{ direction: 'rtl', unicodeBidi: 'embed', letterSpacing: '0px' }}>هوية الحملة الشعبية</h4>
                  <p className="text-[8px] md:text-[10px] text-primary font-black uppercase tracking-tighter leading-none drop-shadow-md">Unlimited Internet Egypt</p>
                </div>
              </div>
              <div className={`p-2 rounded-xl ${
                userLevel?.frameStyle === 'gold' ? 'bg-amber-400/20' : 'bg-primary/20'
              } backdrop-blur-sm`}>
                <ShieldCheck className={`w-5 h-5 md:w-7 md:h-7 ${
                  userLevel?.frameStyle === 'gold' ? 'text-amber-400' : 'text-primary'
                } drop-shadow-lg`} />
              </div>
            </div>

            {/* Main Info Area - محسّن */}
            <div className="flex-1 p-6 flex items-center justify-between gap-6 relative z-10">
              {/* Personal Data Column */}
              <div className="flex-1 space-y-4">
                <div className="space-y-1.5 bg-black/20 backdrop-blur-sm rounded-2xl p-3 border border-white/10" style={{ textAlign: 'right' }}>
                  <p className="text-[8px] md:text-[10px] text-slate-300 font-black uppercase tracking-widest" style={{ letterSpacing: '0px' }}>الاسم الكامل / FULL NAME</p>
                  <p className="text-xl md:text-3xl font-black text-white leading-tight drop-shadow-2xl" style={{ direction: 'rtl', unicodeBidi: 'embed', letterSpacing: '0px' }}>
                    {userName || 'اسم الداعم'}
                  </p>
                </div>
                
                <div className="space-y-1.5 bg-black/20 backdrop-blur-sm rounded-2xl p-3 border border-white/10" style={{ textAlign: 'right' }}>
                  <p className="text-[8px] md:text-[10px] text-slate-300 font-black uppercase tracking-widest" style={{ letterSpacing: '0px' }}>المستوى / LEVEL</p>
                  <p className={`text-sm md:text-xl font-black flex items-center gap-2 leading-none ${userLevel?.color || 'text-primary'} drop-shadow-lg`} style={{ direction: 'rtl', unicodeBidi: 'embed', letterSpacing: '0px' }}>
                     {userLevel?.icon} {userLevel?.title || 'مشارك جديد'}
                  </p>
                </div>
              </div>

              {/* Real QR Code Side - محسّن */}
              <div className={`flex flex-col items-center gap-2 p-4 rounded-3xl bg-white shadow-2xl ${
                userLevel?.frameStyle === 'gold' ? 'border-3 border-amber-400' : 'border-2 border-primary/30'
              }`}>
                 {qrCodeUrl ? (
                   <img src={qrCodeUrl} alt="Campaign QR" className="w-14 h-14 md:w-20 md:h-20 rounded-xl" />
                 ) : (
                   <div className="w-14 h-14 md:w-20 md:h-20 bg-slate-100 animate-pulse rounded-xl" />
                 )}
                 <div className="text-center space-y-0.5">
                    <p className="text-[8px] md:text-[10px] text-slate-900 font-black tracking-tighter leading-none" style={{ direction: 'rtl', unicodeBidi: 'embed', letterSpacing: '0px' }}>امسح للانضمام</p>
                    <p className="text-[7px] md:text-[8px] text-primary font-bold leading-none tracking-tighter" style={{ direction: 'rtl', unicodeBidi: 'embed' }}>نطالب بإنترنت غير محدود 🇪🇬</p>
                 </div>
              </div>
            </div>

            {/* Footer Glow Effect */}
            <div className="absolute bottom-0 left-0 w-full h-20 bg-gradient-to-t from-primary/30 via-primary/10 to-transparent pointer-events-none" />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
          <Button 
            className="h-14 rounded-2xl font-black text-lg shadow-xl shadow-primary/30 transition-all hover:scale-[1.02] active:scale-95 gap-3"
            onClick={downloadCard}
            disabled={isGenerating || !userName.trim()}
          >
            {isGenerating ? <Loader2 className="w-6 h-6 animate-spin" /> : <Camera className="w-6 h-6" />}
            تحميل الهوية HD ✨
          </Button>
          
          <div className="flex gap-3">
            <Button 
              variant="outline"
              className="flex-1 h-14 rounded-2xl font-black border-primary/20 hover:bg-primary/5 gap-2 text-base"
              onClick={handleShare}
              disabled={!userName.trim()}
            >
              <Share2 className="w-5 h-5 text-primary" />
              مشاركة سريعة
            </Button>
            <Button 
              variant="outline"
              size="icon"
              className="w-14 h-14 rounded-2xl border-blue-500/20 text-blue-500 hover:bg-blue-500/5 transition-colors"
              onClick={() => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`, '_blank')}
            >
              <Facebook className="w-6 h-6" />
            </Button>
            <Button 
              variant="outline"
              size="icon"
              className="w-14 h-14 rounded-2xl border-green-500/20 text-green-500 hover:bg-green-500/5 transition-colors"
              onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent('أنا أدعم حملة إنترنت غير محدود في مصر! صمم بطاقتك الآن: ' + window.location.href)}`, '_blank')}
            >
              <MessageCircle className="w-6 h-6" />
            </Button>
          </div>
        </div>
        
        <p className="text-[10px] text-center text-muted-foreground font-bold italic animate-pulse">
           * نصيحة: استخدم اسمك الحقيقي لتظهر هويتك بشكل أفضل عند المشاركة
        </p>
      </CardContent>
    </Card>
  );
};
