import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ShieldCheck, RefreshCw } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';

interface HumanVerificationProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onVerified: (token: string) => void;
}

export const HumanVerification: React.FC<HumanVerificationProps> = ({ isOpen, onOpenChange, onVerified }) => {
  const [question, setQuestion] = useState({ a: 0, b: 0, op: '+', result: 0 });
  const [answer, setAnswer] = useState('');
  const [error, setError] = useState(false);

  const generateQuestion = () => {
    const a = Math.floor(Math.random() * 10) + 1;
    const b = Math.floor(Math.random() * 10) + 1;
    setQuestion({ a, b, op: '+', result: a + b });
    setAnswer('');
    setError(false);
  };

  useEffect(() => {
    if (isOpen) {
      generateQuestion();
    }
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (parseInt(answer) === question.result) {
      // In a real app, this token would be signed by a server
      // For this implementation, we use a simple string
      onVerified(`human-verified-${Date.now()}`);
      onOpenChange(false);
    } else {
      setError(true);
      setAnswer('');
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-background border-primary/20">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldCheck className="text-primary w-5 h-5" />
            تحقق من أنك لست روبوت
          </DialogTitle>
          <DialogDescription>
            من فضلك قم بحل هذه العملية الحسابية البسيطة للمتابعة
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          <div className="flex items-center justify-center gap-6 p-6 bg-primary/5 rounded-2xl border border-primary/10">
            <div className="text-3xl font-black tracking-widest text-primary">
              {question.a} {question.op} {question.b} = ?
            </div>
            <Button 
              type="button" 
              variant="ghost" 
              size="icon" 
              onClick={generateQuestion}
              className="text-muted-foreground hover:text-primary"
            >
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>

          <div className="space-y-2">
            <Input
              type="number"
              placeholder="اكتب الناتج هنا..."
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              className={`text-center text-xl font-bold h-12 ${error ? 'border-destructive ring-destructive' : ''}`}
              autoFocus
            />
            {error && (
              <p className="text-destructive text-center text-xs font-bold">الإجابة غير صحيحة، حاول مرة أخرى</p>
            )}
          </div>

          <Button type="submit" className="w-full h-12 font-black text-lg">
            تأكيد التصويت ✅
          </Button>
        </form>
        
        <DialogFooter className="text-center text-[10px] text-muted-foreground">
          نحن نستخدم هذا التحقق لحماية مصداقية الحملة من التصويت الوهمي.
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
