import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Wifi, Smartphone, TrendingUp } from 'lucide-react';

interface PostVoteSurveyProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onComplete: (data: { networkProvider: string; dataUsageType: string }) => void;
}

const NETWORK_PROVIDERS = [
  { value: 'we', label: 'WE Egypt', icon: '🌐' },
  { value: 'vodafone', label: 'Vodafone Egypt', icon: '📱' },
  { value: 'orange', label: 'Orange Egypt', icon: '🍊' },
  { value: 'etisalat', label: 'Etisalat Egypt', icon: '🟢' },
];

const DATA_USAGE_TYPES = [
  { value: 'videos', label: 'فيديوهات', icon: '🎬' },
  { value: 'social', label: 'سوشيال ميديا', icon: '💬' },
  { value: 'games', label: 'ألعاب', icon: '🎮' },
  { value: 'work', label: 'شغل / دراسة', icon: '💼' },
];

export const PostVoteSurvey: React.FC<PostVoteSurveyProps> = ({ isOpen, onOpenChange, onComplete }) => {
  const [step, setStep] = useState(1);
  const [networkProvider, setNetworkProvider] = useState('');
  const [dataUsageType, setDataUsageType] = useState('');

  const handleNext = () => {
    if (step === 1 && networkProvider) {
      setStep(2);
    } else if (step === 2 && dataUsageType) {
      onComplete({ networkProvider, dataUsageType });
      onOpenChange(false);
      // Reset for next time
      setStep(1);
      setNetworkProvider('');
      setDataUsageType('');
    }
  };

  const handleSkip = () => {
    onComplete({ networkProvider: networkProvider || 'not_specified', dataUsageType: dataUsageType || 'not_specified' });
    onOpenChange(false);
    setStep(1);
    setNetworkProvider('');
    setDataUsageType('');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-background border-primary/20">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {step === 1 ? <Wifi className="text-primary w-5 h-5" /> : <TrendingUp className="text-secondary w-5 h-5" />}
            {step === 1 ? 'ما هي شبكتك؟' : 'ما الذي يستهلك باقتك؟'}
          </DialogTitle>
          <DialogDescription>
            {step === 1 
              ? 'ساعدنا نفهم أي شبكة محتاجة تحسين أكتر' 
              : 'عايزين نعرف إيه أكتر حاجة بتخلص الباقة عندك'}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {step === 1 ? (
            <RadioGroup value={networkProvider} onValueChange={setNetworkProvider} className="space-y-3">
              {NETWORK_PROVIDERS.map((provider) => (
                <div key={provider.value} className="flex items-center space-x-2 space-x-reverse">
                  <RadioGroupItem value={provider.value} id={provider.value} />
                  <Label 
                    htmlFor={provider.value} 
                    className="flex items-center gap-3 cursor-pointer flex-1 p-3 rounded-xl border border-border hover:bg-muted/50 transition-colors"
                  >
                    <span className="text-2xl">{provider.icon}</span>
                    <span className="font-bold">{provider.label}</span>
                  </Label>
                </div>
              ))}
            </RadioGroup>
          ) : (
            <RadioGroup value={dataUsageType} onValueChange={setDataUsageType} className="space-y-3">
              {DATA_USAGE_TYPES.map((type) => (
                <div key={type.value} className="flex items-center space-x-2 space-x-reverse">
                  <RadioGroupItem value={type.value} id={type.value} />
                  <Label 
                    htmlFor={type.value} 
                    className="flex items-center gap-3 cursor-pointer flex-1 p-3 rounded-xl border border-border hover:bg-muted/50 transition-colors"
                  >
                    <span className="text-2xl">{type.icon}</span>
                    <span className="font-bold">{type.label}</span>
                  </Label>
                </div>
              ))}
            </RadioGroup>
          )}

          <div className="flex gap-3">
            <Button 
              variant="outline" 
              onClick={handleSkip} 
              className="flex-1"
            >
              تخطي
            </Button>
            <Button 
              onClick={handleNext} 
              disabled={step === 1 ? !networkProvider : !dataUsageType}
              className="flex-1 font-black"
            >
              {step === 1 ? 'التالي' : 'إرسال'}
            </Button>
          </div>

          <div className="flex justify-center gap-2">
            <div className={`w-2 h-2 rounded-full transition-colors ${step === 1 ? 'bg-primary' : 'bg-muted'}`} />
            <div className={`w-2 h-2 rounded-full transition-colors ${step === 2 ? 'bg-primary' : 'bg-muted'}`} />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
