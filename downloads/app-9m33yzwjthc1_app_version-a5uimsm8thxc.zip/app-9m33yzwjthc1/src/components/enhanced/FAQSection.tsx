import React, { useState } from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { FAQ } from '@/db/api';
import { Search, HelpCircle, CheckCircle2 } from 'lucide-react';

interface Props {
  faqs: FAQ[];
}

// أسئلة شائعة إضافية شاملة
const additionalFAQs = [
  {
    id: 'faq-tech-1',
    question: 'هل البنية التحتية في مصر تتحمل الإنترنت غير المحدود؟',
    answer: 'نعم بالتأكيد! مصر تمتلك 15 كابل بحري دولي وشبكة ألياف ضوئية ضخمة. المشكلة ليست تقنية بل سياسية تجارية. الدول المجاورة مثل السعودية والإمارات لديها نفس البنية ويوفرون إنترنت غير محدود.',
    category: 'تقني',
    display_order: 1
  },
  {
    id: 'faq-price-1',
    question: 'هل سيرتفع السعر إذا أصبح الإنترنت غير محدود؟',
    answer: 'على العكس! في معظم الدول التي تحولت للإنترنت غير المحدود، انخفضت الأسعار بسبب المنافسة. التكلفة الحقيقية للإنترنت منخفضة جداً، والباقات المحدودة هي فقط لزيادة الأرباح.',
    category: 'سعر',
    display_order: 2
  },
  {
    id: 'faq-impact-1',
    question: 'كيف سيؤثر الإنترنت غير المحدود على حياتي اليومية؟',
    answer: 'ستتمكن من مشاهدة المحاضرات والدورات دون قلق، العمل الحر بكفاءة أعلى، مشاهدة Netflix/YouTube براحة، تحميل الألعاب والتحديثات، وحضور اجتماعات Zoom طويلة دون خوف من نفاد الباقة.',
    category: 'تأثير',
    display_order: 3
  },
  {
    id: 'faq-action-1',
    question: 'كيف يمكنني المساهمة في هذه الحملة؟',
    answer: '1) صوّت على الموقع، 2) اكتب تعليقك وشارك تجربتك، 3) شارك الرابط على فيسبوك/تويتر/واتساب، 4) تحدث مع أصدقائك وعائلتك عن الموضوع، 5) اختبر سرعة إنترنتك وشارك النتيجة.',
    category: 'مشاركة',
    display_order: 4
  },
  {
    id: 'faq-compare-1',
    question: 'ما الفرق بين مصر والدول الأخرى في الإنترنت؟',
    answer: 'الإمارات: 250 Mbps غير محدود بـ40$، السعودية: 150 Mbps غير محدود بـ35$، فرنسا: 400 Mbps غير محدود بـ25$. مصر: 30 Mbps بـ140 جيجا فقط بـ10$. الفرق واضح!',
    category: 'مقارنة',
    display_order: 5
  },
  {
    id: 'faq-security-1',
    question: 'هل بياناتي آمنة على هذا الموقع؟',
    answer: 'نعم تماماً. نحن لا نجمع أي بيانات شخصية حساسة. التصويت يتم عبر بصمة الجهاز (Device Fingerprint) دون تخزين IP أو معلومات شخصية. التعليقات اختيارية ويمكنك استخدام اسم مستعار.',
    category: 'أمان',
    display_order: 6
  },
  {
    id: 'faq-goal-1',
    question: 'ما هو هدف هذه الحملة؟',
    answer: 'الهدف هو جمع أكبر عدد من الأصوات والتعليقات لإيصال صوت المواطن المصري للمسؤولين وشركات الاتصالات، وإثبات أن الطلب على الإنترنت غير المحدود حقيقي وضروري لتطور مصر الرقمي.',
    category: 'هدف',
    display_order: 7
  },
  {
    id: 'faq-freelance-1',
    question: 'أنا فريلانسر، كيف سيساعدني الإنترنت غير المحدود؟',
    answer: 'ستتمكن من رفع ملفات كبيرة (فيديوهات، تصاميم، أكواد) دون قلق، حضور اجتماعات Zoom/Teams طويلة، تحميل برامج وأدوات ضخمة، والعمل بكفاءة أعلى مما يزيد دخلك ويوفر وقتك.',
    category: 'عمل حر',
    display_order: 8
  }
];

const categoryColors: Record<string, string> = {
  'تقني': 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  'سعر': 'bg-green-500/10 text-green-400 border-green-500/20',
  'تأثير': 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  'مشاركة': 'bg-orange-500/10 text-orange-400 border-orange-500/20',
  'مقارنة': 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20',
  'أمان': 'bg-red-500/10 text-red-400 border-red-500/20',
  'هدف': 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
  'عمل حر': 'bg-pink-500/10 text-pink-400 border-pink-500/20'
};

export const FAQSection: React.FC<Props> = ({ faqs }) => {
  const [searchQuery, setSearchQuery] = useState('');
  
  // دمج الأسئلة من قاعدة البيانات مع الأسئلة الإضافية
  const allFAQs = [...additionalFAQs, ...faqs.map(f => ({ ...f, category: 'عام' }))];
  
  // فلترة الأسئلة بناءً على البحث
  const filteredFAQs = allFAQs.filter(faq => 
    faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
    faq.answer.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-full mb-4">
          <HelpCircle className="w-5 h-5 text-primary" />
          <span className="text-sm font-bold text-primary">الأسئلة الشائعة</span>
        </div>
        <h2 className="text-2xl md:text-3xl font-black mb-3 gradient-text">
          كل ما تريد معرفته عن الحملة
        </h2>
        <p className="text-muted-foreground text-sm md:text-base max-w-2xl mx-auto">
          إجابات واضحة وموجزة على جميع استفساراتك حول الإنترنت غير المحدود في مصر
        </p>
      </div>

      {/* Search Bar */}
      <Card className="glass-card">
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="ابحث في الأسئلة الشائعة..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10 bg-background/50"
            />
          </div>
        </CardContent>
      </Card>

      {/* FAQ Accordion */}
      <Accordion type="single" collapsible className="w-full space-y-4">
        {filteredFAQs.map((faq) => (
          <AccordionItem 
            key={faq.id} 
            value={`item-${faq.id}`} 
            className="glass-card px-6 rounded-2xl border-none overflow-hidden"
          >
            <AccordionTrigger className="text-right font-bold hover:no-underline py-5 gap-4">
              <div className="flex items-start gap-3 flex-1">
                <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <div className="flex-1 text-right">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="text-base leading-tight">{faq.question}</span>
                  </div>
                  {faq.category && (
                    <Badge 
                      variant="outline" 
                      className={`${categoryColors[faq.category] || 'bg-gray-500/10 text-gray-400'} text-[10px] font-bold mt-1`}
                    >
                      {faq.category}
                    </Badge>
                  )}
                </div>
              </div>
            </AccordionTrigger>
            <AccordionContent className="text-muted-foreground leading-relaxed pb-5 pr-8">
              <div className="bg-primary/5 p-4 rounded-xl border border-primary/10">
                {faq.answer}
              </div>
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>

      {/* No Results */}
      {filteredFAQs.length === 0 && (
        <Card className="glass-card">
          <CardContent className="p-8 text-center">
            <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <p className="text-muted-foreground">
              لم يتم العثور على نتائج. جرب كلمات بحث أخرى.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Help Card */}
      <Card className="bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-primary/20">
        <CardContent className="p-6 text-center">
          <HelpCircle className="w-10 h-10 text-primary mx-auto mb-3" />
          <h3 className="text-lg font-black mb-2">لم تجد إجابة لسؤالك؟</h3>
          <p className="text-sm text-muted-foreground">
            اترك تعليقاً في قسم التعليقات وسنرد عليك في أقرب وقت!
          </p>
        </CardContent>
      </Card>
    </div>
  );
};
