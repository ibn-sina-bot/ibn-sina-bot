import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, Medal, Award, Zap } from 'lucide-react';

interface LeaderboardEntry {
  fingerprint: string;
  points: number;
  vote_count: number;
  share_count: number;
}

interface PointsLeaderboardProps {
  entries: LeaderboardEntry[];
  userFingerprint?: string;
}

export const PointsLeaderboard: React.FC<PointsLeaderboardProps> = ({ entries, userFingerprint }) => {
  const topEntries = entries.slice(0, 10);
  const GOAL_POINTS = 2500;
  const topUserPoints = topEntries.length > 0 ? topEntries[0].points : 0;
  const progressPercentage = Math.min(Math.round((topUserPoints / GOAL_POINTS) * 100), 100);

  const getRankIcon = (index: number) => {
    if (index === 0) return <Trophy className="w-5 h-5 text-yellow-500" />;
    if (index === 1) return <Medal className="w-5 h-5 text-gray-400" />;
    if (index === 2) return <Award className="w-5 h-5 text-amber-700" />;
    return <Zap className="w-4 h-4 text-muted-foreground" />;
  };

  const getRankBadge = (index: number) => {
    if (index === 0) return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20';
    if (index === 1) return 'bg-gray-400/10 text-gray-400 border-gray-400/20';
    if (index === 2) return 'bg-amber-700/10 text-amber-700 border-amber-700/20';
    return 'bg-muted text-muted-foreground border-border';
  };

  return (
    <Card className="glass-card border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Trophy className="w-5 h-5 text-primary" />
          🏆 داعمي الإنترنت غير المحدود
        </CardTitle>
        <p className="text-xs text-muted-foreground">أكثر المشاركين نشاطاً هذا الأسبوع</p>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {topEntries.length > 0 ? (
            topEntries.map((entry, index) => {
              const isCurrentUser = userFingerprint && entry.fingerprint === userFingerprint;
              return (
                <div 
                  key={entry.fingerprint} 
                  className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                    isCurrentUser 
                      ? 'bg-primary/5 border-primary/30 shadow-md' 
                      : 'bg-muted/30 border-border hover:bg-muted/50'
                  }`}
                >
                  <div className="flex items-center justify-center w-10 h-10">
                    {getRankIcon(index)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-black">
                        {isCurrentUser ? 'أنت 🎉' : `داعم #${index + 1}`}
                      </span>
                      <Badge variant="outline" className={`text-xs ${getRankBadge(index)}`}>
                        {entry.points} نقطة
                      </Badge>
                    </div>
                    <p className="text-[10px] text-muted-foreground mt-1">
                      {entry.vote_count} تصويت • {entry.share_count} مشاركة
                    </p>
                  </div>
                  <div className="text-2xl font-black text-primary">
                    #{index + 1}
                  </div>
                </div>
              );
            })
          ) : (
            <p className="text-sm text-muted-foreground text-center py-8">
              كن أول من يظهر في قائمة الشرف! 🌟
            </p>
          )}
        </div>

        {/* Goal Progress */}
        <div className="mt-6 p-4 bg-gradient-to-br from-primary/10 to-primary/5 rounded-xl border border-primary/20 space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span className="font-bold text-primary flex items-center gap-2">
              <Trophy className="w-4 h-4" />
              هدف المتصدر الأول
            </span>
            <span className="text-primary font-black">{progressPercentage}%</span>
          </div>
          
          {/* Progress Bar */}
          <div className="relative h-2.5 bg-secondary/30 rounded-full overflow-hidden border border-primary/20">
            <div 
              className="absolute inset-y-0 right-0 bg-gradient-to-l from-yellow-500 via-primary to-primary/70 rounded-full transition-all duration-1000 ease-out shadow-[0_0_8px_rgba(234,179,8,0.5)]"
              style={{ width: `${progressPercentage}%` }}
            >
              <div className="absolute inset-0 bg-gradient-to-l from-white/30 to-transparent animate-pulse" />
            </div>
          </div>
          
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">الهدف: <span className="font-bold text-primary">{GOAL_POINTS.toLocaleString('ar-EG')}</span> نقطة</span>
            <span className="text-muted-foreground">متبقي: <span className="font-bold text-primary">{Math.max(GOAL_POINTS - topUserPoints, 0).toLocaleString('ar-EG')}</span></span>
          </div>
        </div>

        <div className="mt-4 p-4 bg-primary/5 rounded-xl border border-primary/20">
          <p className="text-xs font-bold text-primary mb-2">كيف تكسب النقاط؟</p>
          <div className="space-y-1 text-[10px] text-muted-foreground">
            <p>✅ +1 نقطة عند التصويت</p>
            <p>🔗 +2 نقطة عند مشاركة الحملة</p>
            <p>💬 +1 نقطة عند إضافة تعليق</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
