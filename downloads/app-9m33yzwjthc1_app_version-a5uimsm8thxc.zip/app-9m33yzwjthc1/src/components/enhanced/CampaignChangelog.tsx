import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CampaignUpdate } from '@/db/api';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, Info, AlertTriangle } from 'lucide-react';

interface Props {
  updates: CampaignUpdate[];
}

export const CampaignChangelog: React.FC<Props> = ({ updates }) => {
  const getIcon = (level: string) => {
    switch (level) {
      case 'success': return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case 'warning': return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      default: return <Info className="w-5 h-5 text-blue-500" />;
    }
  };

  if (!updates || updates.length === 0) {
    return (
      <Card className="glass-card">
        <CardContent className="py-10 text-center">
          <p className="text-muted-foreground italic">لا توجد تحديثات مسجلة حالياً.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle className="text-xl font-bold">📢 سجل تقدم الحملة</CardTitle>
        <p className="text-sm text-muted-foreground">تابع آخر التطورات وردود الأفعال الرسمية.</p>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="relative border-r-2 border-primary/20 pr-6 mr-2 space-y-8">
          {updates.map((update) => (
            <div key={update.id} className="relative">
              <div className="absolute -right-[33px] top-1 bg-background p-1 rounded-full border-2 border-primary/20">
                {getIcon(update.impact_level)}
              </div>
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-lg">{update.title}</h4>
                  <span className="text-xs text-muted-foreground">{new Date(update.update_date).toLocaleDateString('ar-EG')}</span>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">{update.content}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
