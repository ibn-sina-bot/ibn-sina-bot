import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, Medal, Award, TrendingUp, MapPin, Flame, Crown, Star } from 'lucide-react';
import { getGovernoratesLeaderboard, GovernorateRanking } from '@/db/api';
import { Progress } from '@/components/ui/progress';

export const GovernoratesLeaderboard: React.FC = () => {
  const [rankings, setRankings] = useState<GovernorateRanking[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchRankings = async () => {
      setIsLoading(true);
      const data = await getGovernoratesLeaderboard();
      setRankings(data);
      setIsLoading(false);
    };

    fetchRankings();
    
    // تحديث كل دقيقة
    const interval = setInterval(fetchRankings, 60000);
    return () => clearInterval(interval);
  }, []);

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="w-6 h-6 text-amber-400" />;
      case 2:
        return <Medal className="w-6 h-6 text-slate-300" />;
      case 3:
        return <Award className="w-6 h-6 text-orange-400" />;
      default:
        return <Star className="w-5 h-5 text-slate-500" />;
    }
  };

  const getRankBadgeColor = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-r from-amber-500 to-yellow-500 text-white';
      case 2:
        return 'bg-gradient-to-r from-slate-400 to-slate-300 text-slate-900';
      case 3:
        return 'bg-gradient-to-r from-orange-500 to-amber-600 text-white';
      default:
        return 'bg-slate-700 text-slate-300';
    }
  };

  if (isLoading) {
    return (
      <Card className="glass-card border-primary/20">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-black gradient-text flex items-center justify-center gap-2">
            <Trophy className="w-7 h-7" />
            لوحة شرف المحافظات
          </CardTitle>
          <CardDescription>جاري التحميل...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map(i => (
              <div key={i} className="h-16 bg-slate-800/50 rounded-xl animate-pulse" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const topThree = rankings.slice(0, 3);
  const others = rankings.slice(3, 10);

  return (
    <Card className="glass-card border-primary/20 overflow-hidden">
      <CardHeader className="text-center pb-4">
        <CardTitle className="text-2xl md:text-3xl font-black gradient-text flex items-center justify-center gap-2">
          <Trophy className="w-7 h-7 md:w-8 md:h-8" />
          لوحة شرف المحافظات
        </CardTitle>
        <CardDescription className="text-sm md:text-base">
          المحافظات الأكثر مشاركة في الحملة - تحديث لحظي 🔥
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* المراكز الثلاثة الأولى - عرض مميز */}
        {topThree.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {topThree.map((item) => (
              <div
                key={item.governorate}
                className={`relative p-5 rounded-2xl border-2 transition-all duration-300 hover:scale-105 ${
                  item.rank === 1
                    ? 'bg-gradient-to-br from-amber-500/20 to-yellow-500/10 border-amber-500/50 shadow-xl shadow-amber-500/20'
                    : item.rank === 2
                    ? 'bg-gradient-to-br from-slate-500/20 to-slate-400/10 border-slate-400/50 shadow-lg shadow-slate-400/20'
                    : 'bg-gradient-to-br from-orange-500/20 to-amber-600/10 border-orange-500/50 shadow-lg shadow-orange-500/20'
                }`}
              >
                {/* أيقونة الترتيب */}
                <div className="absolute -top-3 -right-3 w-12 h-12 rounded-full bg-slate-900 border-2 border-current flex items-center justify-center shadow-lg">
                  {getRankIcon(item.rank)}
                </div>

                {/* اسم المحافظة */}
                <div className="text-center mt-2">
                  <h3 className="text-xl md:text-2xl font-black text-white mb-1 flex items-center justify-center gap-2">
                    <MapPin className="w-5 h-5 text-primary" />
                    {item.governorate}
                  </h3>
                  <Badge className={`${getRankBadgeColor(item.rank)} font-black text-xs px-3 py-1`}>
                    المركز {item.rank}
                  </Badge>
                </div>

                {/* الإحصائيات */}
                <div className="mt-4 space-y-2">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-400 font-bold">المشاركات:</span>
                    <span className="text-white font-black text-lg">{item.commentCount}</span>
                  </div>
                  <Progress value={item.percentage} className="h-2" />
                  <p className="text-center text-xs text-slate-400 font-bold">
                    {item.percentage}% من إجمالي المشاركات
                  </p>
                </div>

                {/* تأثير الشعلة للمركز الأول */}
                {item.rank === 1 && (
                  <div className="absolute -bottom-1 left-1/2 -translate-x-1/2">
                    <Flame className="w-6 h-6 text-amber-500 animate-pulse" />
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* باقي المحافظات */}
        {others.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-lg font-black text-slate-300 mb-3 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              باقي المحافظات المتنافسة
            </h4>
            {others.map((item) => (
              <div
                key={item.governorate}
                className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/50 border border-slate-700/50 hover:bg-slate-800/70 hover:border-primary/30 transition-all group"
              >
                {/* الترتيب */}
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-slate-700 border border-slate-600 font-black text-slate-300 group-hover:bg-primary/20 group-hover:border-primary/50 group-hover:text-primary transition-all">
                  {item.rank}
                </div>

                {/* اسم المحافظة */}
                <div className="flex-1">
                  <p className="font-black text-white text-sm md:text-base flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-primary" />
                    {item.governorate}
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <Progress value={item.percentage} className="h-1.5 flex-1" />
                    <span className="text-xs text-slate-400 font-bold min-w-[45px]">
                      {item.percentage}%
                    </span>
                  </div>
                </div>

                {/* عدد المشاركات */}
                <div className="text-right">
                  <p className="text-lg md:text-xl font-black text-primary">{item.commentCount}</p>
                  <p className="text-[10px] text-slate-400 font-bold">مشاركة</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* رسالة تحفيزية */}
        <div className="mt-6 p-4 rounded-xl bg-primary/10 border border-primary/20">
          <p className="text-center text-sm font-bold text-slate-300">
            💪 محافظتك مش في القائمة؟ صوّت وعلّق دلوقتي عشان ترفع ترتيبها!
          </p>
        </div>
      </CardContent>
    </Card>
  );
};
