import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, MapPin, Activity, Zap } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface Props {
  votes: number;
  comments: number;
  activeUsers: number;
  latestGov: string;
}

export const LiveDashboard: React.FC<Props> = ({ votes, comments, activeUsers, latestGov }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      <Card className="glass-card">
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-primary/10 rounded-xl">
              <Users className="text-primary w-6 h-6 animate-pulse" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">زوار الآن (حقيقي)</p>
              <h4 className="text-2xl font-black">{activeUsers}</h4>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-primary/10 rounded-xl">
              <MapPin className="text-primary w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">آخر مشاركة من</p>
              <h4 className="text-xl font-bold">{latestGov}</h4>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-primary/10 rounded-xl">
              <Activity className="text-primary w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">إجمالي التعليقات</p>
              <h4 className="text-2xl font-black">{comments.toLocaleString('ar-EG')}</h4>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-primary/10 rounded-xl">
              <Zap className="text-primary w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">إجمالي الأصوات</p>
              <h4 className="text-2xl font-black">{votes.toLocaleString('ar-EG')}</h4>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
