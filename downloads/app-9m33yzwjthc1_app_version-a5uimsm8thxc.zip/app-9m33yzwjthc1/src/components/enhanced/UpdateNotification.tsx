import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { RefreshCw, X } from 'lucide-react';

// Version identifier - update this when making changes
const APP_VERSION = '2.1.0'; // Updated with better error handling and survey

export const UpdateNotification: React.FC = () => {
  const [showUpdate, setShowUpdate] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    console.log('🔍 فحص الإصدار:', { current: APP_VERSION, stored: localStorage.getItem('app_version') });
    
    // Store current version on first load
    const storedVersion = localStorage.getItem('app_version');
    
    if (!storedVersion) {
      // First time user - store current version
      console.log('✅ مستخدم جديد - حفظ الإصدار:', APP_VERSION);
      localStorage.setItem('app_version', APP_VERSION);
      return;
    }

    // Check if version changed (meaning app was updated)
    if (storedVersion !== APP_VERSION && !dismissed) {
      console.log('🔄 تحديث جديد متاح:', { stored: storedVersion, current: APP_VERSION });
      setShowUpdate(true);
    }

    // Also check for updates every 3 minutes
    const interval = setInterval(() => {
      const currentStored = localStorage.getItem('app_version');
      if (currentStored && currentStored !== APP_VERSION && !dismissed) {
        console.log('🔄 تم اكتشاف تحديث جديد');
        setShowUpdate(true);
      }
    }, 3 * 60 * 1000); // Check every 3 minutes

    return () => clearInterval(interval);
  }, [dismissed]);

  const handleRefresh = () => {
    localStorage.setItem('app_version', APP_VERSION);
    localStorage.setItem('update_refreshed', 'true');
    window.location.reload();
  };

  const handleDismiss = () => {
    setDismissed(true);
    setShowUpdate(false);
    // Store dismissal but still update version
    localStorage.setItem('app_version', APP_VERSION);
  };

  if (!showUpdate) return null;

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[300] animate-in slide-in-from-top-4 w-[90%] max-w-md">
      <Alert className="bg-primary/10 border-primary/30 shadow-2xl backdrop-blur-xl">
        <RefreshCw className="h-4 w-4 text-primary animate-spin" />
        <AlertDescription className="flex items-center justify-between gap-4">
          <div className="flex-1">
            <p className="font-bold text-sm text-primary mb-1">تحديث جديد متاح! 🎉</p>
            <p className="text-xs text-muted-foreground">حدّث الصفحة الآن للحصول على أحدث الميزات والتحسينات</p>
          </div>
          <div className="flex gap-2">
            <Button 
              size="sm" 
              onClick={handleRefresh}
              className="bg-primary hover:bg-primary/90 text-white font-bold h-8 px-4"
            >
              <RefreshCw className="w-3 h-3 ml-1" />
              حدّث الآن
            </Button>
            <Button 
              size="sm" 
              variant="ghost" 
              onClick={handleDismiss}
              className="h-8 w-8 p-0"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </AlertDescription>
      </Alert>
    </div>
  );
};
