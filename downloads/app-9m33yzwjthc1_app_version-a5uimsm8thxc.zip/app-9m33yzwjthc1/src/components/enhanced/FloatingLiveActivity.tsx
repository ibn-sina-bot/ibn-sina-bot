import React, { useEffect, useState } from 'react';
import { User, CheckCircle2, X } from 'lucide-react';

interface Activity {
  id: string;
  name: string;
  governorate: string;
  content: string;
  timestamp: Date;
}

export const FloatingLiveActivity: React.FC<{ initialActivities: any[] }> = ({ initialActivities }) => {
  const [currentActivity, setCurrentActivity] = useState<Activity | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);

  useEffect(() => {
    // Check if user has dismissed notifications permanently
    const dismissed = localStorage.getItem('liveActivityDismissed');
    if (dismissed === 'true') {
      setIsDismissed(true);
      return;
    }

    if (initialActivities.length === 0) return;

    const showNext = () => {
      const pool = initialActivities.slice(0, 20); 
      const randomIndex = Math.floor(Math.random() * pool.length);
      const a = pool[randomIndex];
      if (!a) return;

      setIsVisible(false);
      
      setTimeout(() => {
        setCurrentActivity({
          id: Math.random().toString(),
          name: a.name || 'مواطن مصري',
          governorate: a.governorate || 'القاهرة',
          content: a.content || '',
          timestamp: new Date(a.created_at || Date.now()),
        });
        setIsVisible(true);
      }, 500);
    };

    const initialDelay = setTimeout(showNext, 5000);
    const interval = setInterval(showNext, 30000);
    
    return () => {
      clearTimeout(initialDelay);
      clearInterval(interval);
    };
  }, [initialActivities]);

  const handleDismiss = () => {
    localStorage.setItem('liveActivityDismissed', 'true');
    setIsVisible(false);
    setTimeout(() => {
      setIsDismissed(true);
    }, 700);
  };

  if (!currentActivity || isDismissed) return null;

  return (
    <div className="fixed bottom-24 left-4 z-[100] pointer-events-none max-w-[200px] w-full">
      <div className={`
        pointer-events-auto bg-slate-900/25 backdrop-blur-md border border-primary/10 p-2 rounded-lg shadow-[0_8px_20px_rgba(0,0,0,0.15)] flex flex-col gap-1 w-full relative
        transition-all duration-700 ease-in-out
        ${isVisible ? 'opacity-100 translate-x-0 scale-100' : 'opacity-0 -translate-x-20 scale-90'}
      `}>
        {/* Close Button */}
        <button
          onClick={handleDismiss}
          className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500/80 hover:bg-red-600 flex items-center justify-center transition-colors duration-200 shadow-md z-10"
          aria-label="إزالة الإشعارات"
        >
          <X className="w-3 h-3 text-white" />
        </button>

        <div className="flex items-center gap-1.5">
          <div className="w-6 h-6 rounded-full bg-primary/8 flex items-center justify-center shrink-0 border border-primary/10">
            <User className="w-3 h-3 text-primary" />
          </div>
          <div className="flex-1 overflow-hidden">
            <p className="text-[8px] font-bold text-primary flex items-center gap-0.5 uppercase tracking-tight">
              <CheckCircle2 className="w-2 h-2" /> انضم للحملة
            </p>
            <p className="text-[9px] font-bold text-white/80 truncate">
              {currentActivity.name} <span className="text-primary/35 px-0.5">•</span> {currentActivity.governorate}
            </p>
          </div>
        </div>
        
        {currentActivity.content && (
          <div className="bg-white/5 rounded-md p-1.5 border border-white/5">
            <p className="text-[9px] leading-snug text-slate-200/70 font-medium line-clamp-2 italic">
              "{currentActivity.content}"
            </p>
          </div>
        )}
        
        <p className="text-[7px] text-muted-foreground/35 font-bold text-left">
          صوّت قبل قليل ✨
        </p>
      </div>
    </div>
  );
};
