import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { InternationalComparison } from '@/db/api';

interface Props {
  data: InternationalComparison[];
}

export const ComparisonTable: React.FC<Props> = ({ data }) => {
  return (
    <Card className="glass-card overflow-hidden">
      <CardHeader className="bg-primary/5">
        <CardTitle className="text-xl font-bold flex items-center gap-2">
          📊 مقارنة عالمية لأسعار وسرعات الإنترنت
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        {/* Mobile-Optimized: Scrollable Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-right min-w-[500px]">
            <thead className="bg-muted/50 border-b">
              <tr>
                <th className="px-3 md:px-4 py-3 text-xs md:text-sm font-bold whitespace-nowrap">الدولة</th>
                <th className="px-3 md:px-4 py-3 text-xs md:text-sm font-bold whitespace-nowrap">متوسط السرعة</th>
                <th className="px-3 md:px-4 py-3 text-xs md:text-sm font-bold whitespace-nowrap">التكلفة</th>
                <th className="px-3 md:px-4 py-3 text-xs md:text-sm font-bold whitespace-nowrap">غير محدود؟</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {data.map((item) => (
                <tr key={item.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-3 md:px-4 py-3 font-medium text-sm md:text-base">{item.country_name}</td>
                  <td className="px-3 md:px-4 py-3 text-xs md:text-sm">{item.avg_speed}</td>
                  <td className="px-3 md:px-4 py-3 text-xs md:text-sm">{item.avg_price}</td>
                  <td className="px-3 md:px-4 py-3 text-xs md:text-sm">
                    {item.is_unlimited ? (
                      <span className="text-accent font-bold">نعم ✅</span>
                    ) : (
                      <span className="text-primary font-bold">لا ❌</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {/* Mobile Hint */}
        <div className="md:hidden p-3 bg-muted/20 border-t text-center">
          <p className="text-xs text-muted-foreground">
            💡 اسحب الجدول يميناً ويساراً لعرض جميع البيانات
          </p>
        </div>
      </CardContent>
    </Card>
  );
};
