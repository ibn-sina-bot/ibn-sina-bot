import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { MessageCircle, ThumbsUp, ExternalLink, Sparkles } from 'lucide-react';

interface SupportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const SupportDialog: React.FC<SupportDialogProps> = ({ open, onOpenChange }) => {
  const handleMessenger = () => {
    window.open('https://m.me/ebrahemhany690', '_blank', 'noopener,noreferrer');
    onOpenChange(false);
  };

  const handleFacebook = () => {
    window.open('https://www.facebook.com/share/1FttQFB8Dy/', '_blank', 'noopener,noreferrer');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-slate-950 border-primary/20">
        <DialogHeader>
          <DialogTitle className="text-2xl font-black text-center gradient-text flex items-center justify-center gap-2">
            <Sparkles className="w-6 h-6 text-primary" />
            تواصل معنا
          </DialogTitle>
          <DialogDescription className="text-center text-muted-foreground text-sm">
            اختر طريقة التواصل المفضلة لديك
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Messenger Card */}
          <Card 
            className="glass-card border-blue-500/20 hover:border-blue-500/40 transition-all cursor-pointer group"
            onClick={handleMessenger}
          >
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#0084FF] to-[#00C6FF] flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform shadow-lg shadow-blue-500/30">
                  <MessageCircle className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-black text-lg mb-1 flex items-center gap-2">
                    تواصل معنا عبر ماسنجر
                    <ExternalLink className="w-4 h-4 text-muted-foreground" />
                  </h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    راسلنا مباشرة للاستفسارات والاقتراحات، نرد خلال دقائق ⚡
                  </p>
                </div>
              </div>
              <Button 
                className="w-full mt-4 bg-gradient-to-r from-[#0084FF] to-[#00C6FF] hover:from-[#0073E6] hover:to-[#00B3E6] text-white font-bold rounded-xl h-11"
                onClick={(e) => {
                  e.stopPropagation();
                  handleMessenger();
                }}
              >
                <MessageCircle className="w-4 h-4 ml-2" />
                فتح ماسنجر الآن
              </Button>
            </CardContent>
          </Card>

          {/* Facebook Page Card */}
          <Card 
            className="glass-card border-blue-600/20 hover:border-blue-600/40 transition-all cursor-pointer group"
            onClick={handleFacebook}
          >
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#1877F2] to-[#0D5DBF] flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform shadow-lg shadow-blue-600/30">
                  <ThumbsUp className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-black text-lg mb-1 flex items-center gap-2">
                    تابع صفحتنا على فيسبوك
                    <ExternalLink className="w-4 h-4 text-muted-foreground" />
                  </h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    تابعنا لآخر التحديثات والأخبار حول الحملة 📢
                  </p>
                </div>
              </div>
              <Button 
                className="w-full mt-4 bg-gradient-to-r from-[#1877F2] to-[#0D5DBF] hover:from-[#1565D8] hover:to-[#0A4FA6] text-white font-bold rounded-xl h-11"
                onClick={(e) => {
                  e.stopPropagation();
                  handleFacebook();
                }}
              >
                <ThumbsUp className="w-4 h-4 ml-2" />
                زيارة الصفحة
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Footer Note */}
        <div className="text-center pt-2 pb-2">
          <p className="text-[10px] text-muted-foreground italic">
            💙 نحن هنا لخدمتك في أي وقت
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};
