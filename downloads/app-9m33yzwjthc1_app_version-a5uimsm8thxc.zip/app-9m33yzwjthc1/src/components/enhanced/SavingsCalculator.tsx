import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Calculator, TrendingDown, Share2, Download, Sparkles, DollarSign, Loader2, Brain } from 'lucide-react';
import { toast } from 'sonner';
import html2canvas from 'html2canvas';
import { supabase } from '@/db/supabase';

interface AIAnalysis {
  yearlyAnalysis: {
    meals: { count: number; description: string; pricePerMeal?: number };
    subscriptions: { count: number; description: string; pricePerMonth?: number };
    other: string[];
  };
  fiveYearAnalysis: {
    bigPurchases: string[];
    investments: string[];
  };
  advice: {
    savingTips: string[];
    alternatives: string[];
  };
  summary: string;
}

export const SavingsCalculator: React.FC = () => {
  const [monthlySpending, setMonthlySpending] = useState<string>('');
  const [showResult, setShowResult] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const resultRef = useRef<HTMLDivElement>(null);

  const handleCalculate = async () => {
    const amount = parseFloat(monthlySpending);
    if (isNaN(amount) || amount <= 0) {
      toast.error('يرجى إدخال مبلغ صحيح');
      return;
    }
    
    setShowResult(true);
    setIsAnalyzing(true);
    
    // تأثير صوتي/بصري
    setTimeout(() => {
      const element = document.getElementById('savings-result');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 100);

    // Call AI analysis
    try {
      const yearlySpending = amount * 12;
      const fiveYearSpending = yearlySpending * 5;

      const { data, error } = await supabase.functions.invoke('ai-financial-analysis', {
        body: {
          monthlySpending: amount,
          yearlySpending,
          fiveYearSpending
        }
      });

      if (error) {
        console.error('AI Analysis error:', error);
        toast.error('حدث خطأ في التحليل الذكي');
      } else if (data?.success && data?.analysis) {
        setAiAnalysis(data.analysis);
        toast.success('تم التحليل بنجاح! 🤖✨', {
          description: 'تحليل مالي واقعي بالذكاء الاصطناعي'
        });
      }
    } catch (error) {
      console.error('Failed to get AI analysis:', error);
      toast.error('فشل الاتصال بخدمة التحليل الذكي');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const yearlySpending = parseFloat(monthlySpending) * 12;
  const fiveYearSpending = yearlySpending * 5;

  const downloadResult = async () => {
    if (!resultRef.current) return;

    try {
      const canvas = await html2canvas(resultRef.current, {
        scale: 3,
        backgroundColor: '#0f172a',
        logging: false,
      });

      const link = document.createElement('a');
      link.download = 'savings-calculator-egypt-unlimited.png';
      link.href = canvas.toDataURL('image/png', 1.0);
      link.click();
      toast.success('تم تحميل النتيجة بنجاح! 📊');
    } catch (error) {
      console.error('Error generating image:', error);
      toast.error('حدث خطأ أثناء تحميل الصورة');
    }
  };

  const shareResult = async () => {
    if (!resultRef.current) return;

    try {
      const canvas = await html2canvas(resultRef.current, {
        scale: 3,
        backgroundColor: '#0f172a',
      });

      const blob = await new Promise<Blob | null>((resolve) =>
        canvas.toBlob(resolve, 'image/png', 0.9)
      );

      if (!blob) throw new Error('Failed to generate image');

      const file = new File([blob], 'savings-result.png', { type: 'image/png' });
      const shareData = {
        files: [file],
        title: 'كام بصرف على الباقات الإضافية؟',
        text: `أنا بصرف ${yearlySpending.toLocaleString('ar-EG')} جنيه سنوياً على باقات إضافية! لو كان الإنترنت غير محدود في مصر كنت وفرت كل ده 💰 #إنترنت_غير_محدود_في_مصر`,
        url: window.location.origin,
      };

      if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
        await navigator.share(shareData);
      } else {
        toast.info('ميزة المشاركة غير مدعومة، سيتم التحميل');
        downloadResult();
      }
    } catch (error: any) {
      if (error.name !== 'AbortError') {
        console.error('Sharing failed:', error);
        toast.error('حدث خطأ أثناء المشاركة');
      }
    }
  };

  return (
    <Card className="glass-card border-primary/20 overflow-hidden">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl md:text-3xl font-black gradient-text flex items-center justify-center gap-2">
          <Calculator className="w-7 h-7 md:w-8 md:h-8" />
          احسب كام بتصرف على الباقات
        </CardTitle>
        <CardDescription className="text-sm md:text-base">
          اعرف بنفسك كام بتدفع سنوياً على الباقات الإضافية - أرقام حقيقية 💸
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* قسم الإدخال */}
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-black text-slate-300 block">
              كام بتصرف شهرياً على الباقات الإضافية؟ (بالجنيه المصري)
            </label>
            <div className="relative">
              <Input
                type="number"
                placeholder="مثال: 150 جنيه"
                value={monthlySpending}
                onChange={(e) => setMonthlySpending(e.target.value)}
                className="text-center h-14 text-xl font-black rounded-xl border-primary/30 bg-slate-800/50 focus:ring-primary/50 pr-12"
                min="0"
                step="10"
              />
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-primary font-black text-lg">
                ج.م
              </div>
            </div>
            <p className="text-xs text-slate-400 font-bold">
              💡 اجمع كل الباقات: سوشيال ميديا، فيديوهات، ألعاب، إلخ
            </p>
          </div>

          <Button
            onClick={handleCalculate}
            disabled={!monthlySpending || parseFloat(monthlySpending) <= 0 || isAnalyzing}
            className="w-full h-14 rounded-xl font-black text-lg gap-2 shadow-xl shadow-primary/30 transition-all hover:scale-[1.02]"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                جاري التحليل الذكي...
              </>
            ) : (
              <>
                <Brain className="w-5 h-5" />
                احسب بالذكاء الاصطناعي
              </>
            )}
          </Button>
        </div>

        {/* قسم النتيجة */}
        {showResult && !isNaN(yearlySpending) && yearlySpending > 0 && (
          <div
            id="savings-result"
            ref={resultRef}
            className="space-y-4 p-6 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border-2 border-primary/30 shadow-2xl animate-in fade-in slide-in-from-bottom-4"
          >
            {/* العنوان */}
            <div className="text-center space-y-2 pb-4 border-b border-slate-700">
              <h3 className="text-2xl font-black text-white">حسابك الشخصي 📊</h3>
              <p className="text-sm text-slate-400 font-bold">
                بناءً على إنفاقك الشهري الحقيقي: {parseFloat(monthlySpending).toLocaleString('ar-EG')} جنيه
              </p>
            </div>

            {/* الإحصائيات */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* الإنفاق السنوي */}
              <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/30">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingDown className="w-5 h-5 text-red-400" />
                  <p className="text-sm font-bold text-red-400">إنفاقك السنوي</p>
                </div>
                <p className="text-3xl md:text-4xl font-black text-red-400">
                  {yearlySpending.toLocaleString('ar-EG')}
                </p>
                <p className="text-xs text-slate-400 font-bold mt-1">جنيه مصري</p>
              </div>

              {/* الإنفاق على 5 سنوات */}
              <div className="p-4 rounded-xl bg-orange-500/10 border border-orange-500/30">
                <div className="flex items-center gap-2 mb-2">
                  <DollarSign className="w-5 h-5 text-orange-400" />
                  <p className="text-sm font-bold text-orange-400">في 5 سنين</p>
                </div>
                <p className="text-3xl md:text-4xl font-black text-orange-400">
                  {fiveYearSpending.toLocaleString('ar-EG')}
                </p>
                <p className="text-xs text-slate-400 font-bold mt-1">جنيه مصري</p>
              </div>
            </div>

            {/* الرسالة التحفيزية */}
            <div className="p-5 rounded-xl bg-primary/10 border border-primary/30 space-y-3">
              <p className="text-center text-lg font-black text-white leading-relaxed">
                💡 لو كان الإنترنت غير محدود في مصر...
              </p>
              <p className="text-center text-2xl md:text-3xl font-black text-primary leading-tight">
                كنت وفرت {yearlySpending.toLocaleString('ar-EG')} جنيه كل سنة!
              </p>
              <p className="text-center text-sm text-slate-400 font-bold">
                ده مبلغ حقيقي من جيبك - تخيل تعمل إيه بيه؟ 🤔
              </p>
            </div>

            {/* أمثلة على الاستخدام - AI Analysis */}
            {isAnalyzing ? (
              <div className="p-6 rounded-xl bg-slate-800/50 border border-primary/30 space-y-3">
                <div className="flex items-center justify-center gap-3">
                  <Brain className="w-6 h-6 text-primary animate-pulse" />
                  <p className="text-lg font-black text-primary">جاري التحليل الذكي...</p>
                </div>
                <p className="text-sm text-slate-400 text-center font-bold">
                  الذكاء الاصطناعي يحلل إنفاقك بشكل واقعي 🤖
                </p>
                <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto" />
              </div>
            ) : aiAnalysis ? (
              <div className="space-y-4">
                {/* AI Summary */}
                <div className="p-5 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 border border-primary/30 space-y-2">
                  <div className="flex items-center gap-2 mb-2">
                    <Brain className="w-5 h-5 text-primary" />
                    <p className="text-sm font-black text-primary">تحليل ذكي واقعي</p>
                  </div>
                  <p className="text-sm text-slate-200 font-bold leading-relaxed">
                    {aiAnalysis.summary}
                  </p>
                </div>

                {/* Yearly Analysis */}
                <div className="space-y-3">
                  <p className="text-sm font-black text-slate-300 text-center">
                    💰 بالمبلغ السنوي ({yearlySpending.toLocaleString('ar-EG')} جنيه):
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {/* Meals */}
                    <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
                      <p className="text-2xl mb-2">🍔</p>
                      <p className="text-lg font-black text-primary mb-1">
                        {aiAnalysis.yearlyAnalysis.meals.count} وجبة
                      </p>
                      <p className="text-xs text-slate-400 font-bold leading-relaxed">
                        {aiAnalysis.yearlyAnalysis.meals.description}
                      </p>
                      {aiAnalysis.yearlyAnalysis.meals.pricePerMeal && (
                        <p className="text-xs text-slate-500 font-bold mt-1">
                          سعر الوجبة: {aiAnalysis.yearlyAnalysis.meals.pricePerMeal} ج.م
                        </p>
                      )}
                    </div>

                    {/* Subscriptions */}
                    <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
                      <p className="text-2xl mb-2">📺</p>
                      <p className="text-lg font-black text-primary mb-1">
                        {aiAnalysis.yearlyAnalysis.subscriptions.count} شهر
                      </p>
                      <p className="text-xs text-slate-400 font-bold leading-relaxed">
                        {aiAnalysis.yearlyAnalysis.subscriptions.description}
                      </p>
                      {aiAnalysis.yearlyAnalysis.subscriptions.pricePerMonth && (
                        <p className="text-xs text-slate-500 font-bold mt-1">
                          السعر الشهري: {aiAnalysis.yearlyAnalysis.subscriptions.pricePerMonth} ج.م
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Other Uses */}
                  {aiAnalysis.yearlyAnalysis.other.length > 0 && (
                    <div className="p-4 rounded-xl bg-slate-800/30 border border-slate-700/50">
                      <p className="text-sm font-black text-slate-300 mb-2">أو يمكنك:</p>
                      <ul className="space-y-1">
                        {aiAnalysis.yearlyAnalysis.other.map((item, idx) => (
                          <li key={idx} className="text-xs text-slate-400 font-bold flex items-center gap-2">
                            <span className="text-primary">•</span>
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>

                {/* 5-Year Analysis */}
                {fiveYearSpending >= 5000 && (
                  <div className="space-y-3">
                    <p className="text-sm font-black text-slate-300 text-center">
                      🚀 على 5 سنين ({fiveYearSpending.toLocaleString('ar-EG')} جنيه):
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {/* Big Purchases */}
                      <div className="p-4 rounded-xl bg-green-500/10 border border-green-500/30">
                        <p className="text-sm font-black text-green-400 mb-2">مشتريات كبيرة:</p>
                        <ul className="space-y-1">
                          {aiAnalysis.fiveYearAnalysis.bigPurchases.map((item, idx) => (
                            <li key={idx} className="text-xs text-slate-300 font-bold flex items-center gap-2">
                              <span className="text-green-400">✓</span>
                              {item}
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Investments */}
                      <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-500/30">
                        <p className="text-sm font-black text-blue-400 mb-2">استثمارات:</p>
                        <ul className="space-y-1">
                          {aiAnalysis.fiveYearAnalysis.investments.map((item, idx) => (
                            <li key={idx} className="text-xs text-slate-300 font-bold flex items-center gap-2">
                              <span className="text-blue-400">💎</span>
                              {item}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                )}

                {/* Advice */}
                <div className="p-5 rounded-xl bg-amber-500/10 border border-amber-500/30 space-y-3">
                  <p className="text-sm font-black text-amber-400 flex items-center gap-2">
                    💡 نصائح للتوفير:
                  </p>
                  <ul className="space-y-2">
                    {aiAnalysis.advice.savingTips.map((tip, idx) => (
                      <li key={idx} className="text-xs text-slate-300 font-bold flex items-start gap-2">
                        <span className="text-amber-400 mt-0.5">•</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                  
                  {aiAnalysis.advice.alternatives.length > 0 && (
                    <>
                      <p className="text-sm font-black text-amber-400 mt-3">بدائل أفضل:</p>
                      <ul className="space-y-1">
                        {aiAnalysis.advice.alternatives.map((alt, idx) => (
                          <li key={idx} className="text-xs text-slate-300 font-bold flex items-center gap-2">
                            <span className="text-amber-400">→</span>
                            {alt}
                          </li>
                        ))}
                      </ul>
                    </>
                  )}
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <p className="text-xs text-slate-400 font-bold text-center">
                  أمثلة حقيقية - ممكن تشتري بالمبلغ ده:
                </p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    { icon: '📚', text: 'كورسات أونلاين', amount: Math.floor(yearlySpending / 500) },
                    { icon: '🎮', text: 'ألعاب جديدة', amount: Math.floor(yearlySpending / 300) },
                    { icon: '🍕', text: 'وجبات', amount: Math.floor(yearlySpending / 100) },
                    { icon: '🎬', text: 'اشتراكات', amount: Math.floor(yearlySpending / 150) },
                  ].map((item, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-lg bg-slate-800/50 border border-slate-700/50 text-center"
                    >
                      <p className="text-2xl mb-1">{item.icon}</p>
                      <p className="text-xs text-slate-400 font-bold mb-1">{item.text}</p>
                      <p className="text-lg font-black text-primary">{item.amount}+</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* أزرار المشاركة */}
            <div className="flex gap-3 pt-4">
              <Button
                onClick={shareResult}
                className="flex-1 h-12 rounded-xl font-black gap-2 bg-primary hover:bg-primary/90"
              >
                <Share2 className="w-5 h-5" />
                شارك النتيجة
              </Button>
              <Button
                onClick={downloadResult}
                variant="outline"
                className="flex-1 h-12 rounded-xl font-black gap-2 border-primary/30"
              >
                <Download className="w-5 h-5" />
                تحميل
              </Button>
            </div>

            {/* شعار الحملة */}
            <div className="text-center pt-3 border-t border-slate-700">
              <p className="text-xs text-slate-500 font-bold">
                نطالب بإنترنت غير محدود في مصر 🇪🇬
              </p>
            </div>
          </div>
        )}

        {/* معلومات إضافية */}
        {!showResult && (
          <div className="p-4 rounded-xl bg-slate-800/30 border border-slate-700/50 space-y-2">
            <p className="text-xs text-center text-slate-400 font-bold leading-relaxed">
              💡 <span className="text-slate-300">نصيحة:</span> احسب كل الباقات الإضافية اللي بتشتريها شهرياً
            </p>
            <p className="text-xs text-center text-slate-500 font-bold">
              (فيديوهات، سوشيال ميديا، ألعاب، تطبيقات، إلخ)
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
