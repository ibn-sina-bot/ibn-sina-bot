import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Wifi, TrendingUp } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface NetworkStat {
  network_provider: string;
  vote_count: number;
  percentage: number;
}

interface DataUsageStat {
  data_usage_type: string;
  response_count: number;
  percentage: number;
}

interface NetworkAnalyticsProps {
  networkStats: NetworkStat[];
  dataUsageStats: DataUsageStat[];
}

const NETWORK_LABELS: Record<string, { label: string; icon: string; color: string }> = {
  'we': { label: 'WE Egypt', icon: '🌐', color: 'bg-blue-500' },
  'vodafone': { label: 'Vodafone Egypt', icon: '📱', color: 'bg-red-500' },
  'orange': { label: 'Orange Egypt', icon: '🍊', color: 'bg-orange-500' },
  'etisalat': { label: 'Etisalat Egypt', icon: '🟢', color: 'bg-green-500' },
};

const DATA_USAGE_LABELS: Record<string, { label: string; icon: string }> = {
  'videos': { label: 'فيديوهات', icon: '🎬' },
  'social': { label: 'سوشيال ميديا', icon: '💬' },
  'games': { label: 'ألعاب', icon: '🎮' },
  'work': { label: 'شغل / دراسة', icon: '💼' },
};

export const NetworkAnalytics: React.FC<NetworkAnalyticsProps> = ({ networkStats, dataUsageStats }) => {
  return (
    <TooltipProvider>
      <div className="grid md:grid-cols-2 gap-6">
        {/* Network Provider Analytics */}
        <Card className="glass-card border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Wifi className="w-5 h-5 text-primary" />
              التحليل حسب الشبكة
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {networkStats.length > 0 ? (
              networkStats.map((stat) => {
                const info = NETWORK_LABELS[stat.network_provider] || { label: stat.network_provider, icon: '📡', color: 'bg-muted' };
                return (
                  <div key={stat.network_provider} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{info.icon}</span>
                        <span className="text-sm font-bold">{info.label}</span>
                      </div>
                      <Badge variant="outline" className="bg-primary/5 text-primary border-primary/20">
                        {stat.percentage}%
                      </Badge>
                    </div>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div className="cursor-help">
                          <Progress value={stat.percentage} className="h-2" />
                        </div>
                      </TooltipTrigger>
                      <TooltipContent side="top" className="bg-slate-900 border-primary/20">
                        <p className="font-bold text-primary">{stat.vote_count.toLocaleString('ar-EG')} صوت</p>
                        <p className="text-xs text-muted-foreground">من إجمالي الأصوات: {stat.percentage.toFixed(1)}%</p>
                      </TooltipContent>
                    </Tooltip>
                    <p className="text-xs text-muted-foreground">
                      {stat.vote_count.toLocaleString('ar-EG')} مصوت من مشتركي {info.label}
                    </p>
                  </div>
                );
              })
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">لا توجد بيانات كافية بعد</p>
            )}
          </CardContent>
        </Card>

        {/* Data Usage Analytics */}
        <Card className="glass-card border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <TrendingUp className="w-5 h-5 text-primary" />
              أكثر ما يستهلك الباقة
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {dataUsageStats.length > 0 ? (
              dataUsageStats.map((stat) => {
                const info = DATA_USAGE_LABELS[stat.data_usage_type] || { label: stat.data_usage_type, icon: '📊' };
                return (
                  <div key={stat.data_usage_type} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{info.icon}</span>
                        <span className="text-sm font-bold">{info.label}</span>
                      </div>
                      <Badge variant="outline" className="bg-primary/5 text-primary border-primary/20">
                        {stat.percentage}%
                      </Badge>
                    </div>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div className="cursor-help">
                          <Progress value={stat.percentage} className="h-2" />
                        </div>
                      </TooltipTrigger>
                      <TooltipContent side="top" className="bg-slate-900 border-primary/20">
                        <p className="font-bold text-primary">{stat.response_count.toLocaleString('ar-EG')} شخص</p>
                        <p className="text-xs text-muted-foreground">من إجمالي المشاركين: {stat.percentage.toFixed(1)}%</p>
                      </TooltipContent>
                    </Tooltip>
                    <p className="text-xs text-muted-foreground">
                      {stat.response_count.toLocaleString('ar-EG')} شخص اختاروا هذا الخيار
                    </p>
                  </div>
                );
              })
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">لا توجد بيانات كافية بعد</p>
            )}
          </CardContent>
        </Card>
      </div>
    </TooltipProvider>
  );
};
