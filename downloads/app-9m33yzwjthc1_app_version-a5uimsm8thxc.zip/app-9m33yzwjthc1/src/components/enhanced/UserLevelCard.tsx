import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Shield, ShieldCheck, ShieldAlert } from 'lucide-react';

interface UserLevelCardProps {
  points: number;
}

export const UserLevelCard: React.FC<UserLevelCardProps> = ({ points }) => {
  const getLevel = () => {
    if (points >= 15) return { name: 'قائد حملة 🚀', color: 'text-red-500', bgColor: 'bg-red-500/10', borderColor: 'border-red-500/20', icon: <ShieldAlert className="w-8 h-8" />, next: 30, desc: 'أنت من نخبة الداعمين والمؤثرين في هذه الحركة!' };
    if (points >= 5) return { name: 'سفير الحملة 🎓', color: 'text-primary', bgColor: 'bg-primary/10', borderColor: 'border-primary/20', icon: <ShieldCheck className="w-8 h-8" />, next: 15, desc: 'مجهودك رائع! شارك الرابط أكثر للوصول لرتبة القائد' };
    return { name: 'داعم مشارك ✅', color: 'text-slate-400', bgColor: 'bg-slate-500/10', borderColor: 'border-slate-500/20', icon: <Shield className="w-8 h-8" />, next: 5, desc: 'صوّت، علق، وشارك لترفع رتبتك وتأثيرك في الحملة' };
  };

  const level = getLevel();
  const progress = Math.min((points / level.next) * 100, 100);

  return (
    <Card className={`glass-card overflow-hidden border-2 ${level.borderColor} shadow-2xl transition-all duration-500`}>
      <div className={`${level.bgColor} p-5 flex items-center justify-between border-b ${level.borderColor}`}>
        <div>
          <h3 className={`text-lg font-black ${level.color}`}>رتبتك في الحملة</h3>
          <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">التلعيب الهادف للهوية الرقمية</p>
        </div>
        <div className={`p-3 rounded-2xl bg-slate-900 shadow-xl ${level.color} border ${level.borderColor}`}>
          {level.icon}
        </div>
      </div>
      <CardContent className="p-6">
        <div className="text-center mb-6">
          <p className={`text-3xl font-black mb-2 ${level.color} drop-shadow-sm`}>{level.name}</p>
          <p className="text-xs text-muted-foreground leading-relaxed max-w-[240px] mx-auto font-medium">{level.desc}</p>
        </div>
        
        <div className="space-y-4">
          <div className="flex justify-between text-xs font-black">
            <span className="flex items-center gap-1">
                نقاطك الحالية: <span className={level.color}>{points}</span>
            </span>
            <span className="text-muted-foreground">الهدف القادم: {level.next}</span>
          </div>
          <div className="relative h-3 w-full bg-slate-800 rounded-full overflow-hidden p-0.5 border border-white/5">
            <div 
              className={`h-full rounded-full transition-all duration-1000 ease-out ${level.name.includes('قائد') ? 'bg-red-500' : 'bg-primary'} shadow-[0_0_10px_currentColor]`}
              style={{ width: `${progress}%` }} 
            />
          </div>
        </div>

        <div className="mt-8 grid grid-cols-3 gap-3">
            {[
                { label: 'تصويت', icon: '✅', done: points >= 1 },
                { label: 'سفير', icon: '🎓', done: points >= 5 },
                { label: 'قائد', icon: '🚀', done: points >= 15 },
            ].map(step => (
                <div key={step.label} className={`flex flex-col items-center p-3 rounded-2xl border transition-all ${step.done ? `bg-primary/10 ${level.borderColor} scale-105 shadow-lg` : 'bg-white/5 border-transparent opacity-30'}`}>
                    <span className="text-2xl mb-1">{step.icon}</span>
                    <span className={`text-[10px] font-black ${step.done ? level.color : 'text-muted-foreground'}`}>{step.label}</span>
                </div>
            ))}
        </div>
      </CardContent>
    </Card>
  );
};
