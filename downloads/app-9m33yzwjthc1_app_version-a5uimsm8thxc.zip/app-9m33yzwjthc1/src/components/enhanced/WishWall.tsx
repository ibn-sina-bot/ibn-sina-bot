import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Heart, Sparkles, Send, Loader2, Star, Zap, Shield, AlertTriangle } from 'lucide-react';
import { getWishes, addWish, subscribeToWishes, Wish } from '@/db/api';
import { sanitizeComment, sanitizeName } from '@/lib/security';
import { toast } from 'sonner';
import confetti from 'canvas-confetti';
import { supabase } from '@/db/supabase';
import { Alert, AlertDescription } from '@/components/ui/alert';

export const WishWall: React.FC = () => {
  const [wishes, setWishes] = useState<Wish[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isModerating, setIsModerating] = useState(false);
  const [newWish, setNewWish] = useState('');
  const [authorName, setAuthorName] = useState('');
  const [moderationError, setModerationError] = useState<string | null>(null);
  const [moderationSuggestion, setModerationSuggestion] = useState<string | null>(null);

  useEffect(() => {
    const fetchWishes = async () => {
      setIsLoading(true);
      const data = await getWishes(30);
      setWishes(data);
      setIsLoading(false);
    };

    fetchWishes();

    // الاشتراك في الأمنيات الجديدة
    const unsubscribe = subscribeToWishes((newWish) => {
      setWishes((prev) => [newWish, ...prev].slice(0, 30));
      
      // تأثير بصري للأمنية الجديدة
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.8 },
        colors: ['#0ea5e9', '#8b5cf6', '#ec4899'],
      });
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Clear previous errors
    setModerationError(null);
    setModerationSuggestion(null);

    // Sanitize inputs
    const sanitizedWish = sanitizeComment(newWish);
    const sanitizedAuthor = authorName ? sanitizeName(authorName) : 'مواطن مصري';

    if (!sanitizedWish.trim()) {
      toast.error('يرجى كتابة أمنيتك أولاً');
      return;
    }

    if (sanitizedWish.trim().length < 5) {
      toast.error('الأمنية قصيرة جداً، اكتب على الأقل 5 حروف');
      return;
    }

    // Step 1: AI Moderation
    setIsModerating(true);
    
    try {
      const { data: moderationData, error: moderationError } = await supabase.functions.invoke('moderate-wish', {
        body: {
          wishText: sanitizedWish.trim(),
          userName: sanitizedAuthor
        }
      });

      if (moderationError) {
        console.error('Moderation error:', moderationError);
        toast.error('حدث خطأ في مراجعة الأمنية، حاول مرة أخرى');
        setIsModerating(false);
        return;
      }

      if (!moderationData?.success || !moderationData?.moderation) {
        toast.error('فشلت مراجعة الأمنية، حاول مرة أخرى');
        setIsModerating(false);
        return;
      }

      const moderation = moderationData.moderation;

      // Check if approved
      if (!moderation.approved) {
        setModerationError(moderation.reason || 'الأمنية غير مناسبة');
        setModerationSuggestion(moderation.suggestions || null);
        toast.error('عذراً، لم يتم قبول الأمنية', {
          description: moderation.reason,
          duration: 5000
        });
        setIsModerating(false);
        return;
      }

      // Approved! Proceed to submit
      setIsModerating(false);
      setIsSubmitting(true);

      console.log('✅ AI Moderation approved, submitting wish...');
      const success = await addWish(sanitizedWish.trim(), sanitizedAuthor);
      console.log('Wish submission result:', success);

      if (success) {
        toast.success('تم إضافة أمنيتك بنجاح! ✨', {
          description: 'تمت مراجعة أمنيتك وقبولها ونشرها بنجاح 🤖✅'
        });
        setNewWish('');
        setAuthorName('');
        setModerationError(null);
        setModerationSuggestion(null);
        
        // تأثير احتفالي
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        });

        // Refresh wishes list immediately
        console.log('Refreshing wishes list...');
        const updatedWishes = await getWishes(30);
        setWishes(updatedWishes);
      } else {
        toast.error('حدث خطأ في نشر الأمنية، حاول مرة أخرى');
      }

      setIsSubmitting(false);
    } catch (error) {
      console.error('Error in wish submission:', error);
      toast.error('حدث خطأ، حاول مرة أخرى');
      setIsModerating(false);
      setIsSubmitting(false);
    }
  };

  const getRandomColor = (index: number) => {
    const colors = [
      'from-blue-500/20 to-cyan-500/10 border-blue-500/30',
      'from-purple-500/20 to-pink-500/10 border-purple-500/30',
      'from-green-500/20 to-emerald-500/10 border-green-500/30',
      'from-orange-500/20 to-amber-500/10 border-orange-500/30',
      'from-red-500/20 to-rose-500/10 border-red-500/30',
      'from-indigo-500/20 to-violet-500/10 border-indigo-500/30',
    ];
    return colors[index % colors.length];
  };

  const getRandomIcon = (index: number) => {
    const icons = ['✨', '💫', '🌟', '⭐', '🎯', '🚀', '💡', '🔥', '💪', '🎓', '📚', '🎮', '🎬', '🎵'];
    return icons[index % icons.length];
  };

  return (
    <Card className="glass-card border-primary/20 overflow-hidden">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl md:text-3xl font-black gradient-text flex items-center justify-center gap-2">
          <Heart className="w-7 h-7 md:w-8 md:h-8 text-pink-500" />
          حائط الأمنيات الحقيقية
        </CardTitle>
        <CardDescription className="text-sm md:text-base">
          شارك أمنيتك الحقيقية - إيه أول حاجة هتعملها لما الإنترنت يبقى غير محدود؟ 🤔
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* نموذج إضافة أمنية جديدة */}
        <form onSubmit={handleSubmit} className="space-y-4 p-5 rounded-2xl bg-gradient-to-br from-primary/10 to-purple-500/5 border border-primary/20">
          {/* AI Moderation Info */}
          <div className="p-3 rounded-xl bg-green-500/10 border border-green-500/30">
            <p className="text-xs text-green-400 font-bold flex items-center gap-2">
              <Shield className="w-4 h-4" />
              محمي بالذكاء الاصطناعي: جميع الأمنيات تُراجع تلقائياً للتأكد من أنها مناسبة وتدعم الحملة 🤖✅
            </p>
          </div>

          {/* Moderation Error Alert */}
          {moderationError && (
            <Alert className="bg-red-500/10 border-red-500/30">
              <AlertTriangle className="w-4 h-4 text-red-400" />
              <AlertDescription className="text-red-400 font-bold text-sm">
                <p className="mb-2">{moderationError}</p>
                {moderationSuggestion && (
                  <p className="text-xs text-red-300">
                    💡 اقتراح: {moderationSuggestion}
                  </p>
                )}
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <label className="text-sm font-black text-slate-300 block">
              اسمك (اختياري)
            </label>
            <Input
              placeholder="مثال: أحمد محمد"
              value={authorName}
              onChange={(e) => setAuthorName(e.target.value)}
              className="h-11 rounded-xl border-primary/30 bg-slate-800/50 font-bold"
              maxLength={30}
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-black text-slate-300 block flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary" />
              أمنيتك الحقيقية (5-150 حرف)
            </label>
            <Textarea
              placeholder="مثال: هتعلم تصميم جرافيك وأشوف دروس مجانية... أو هشتغل فريلانسر من البيت..."
              value={newWish}
              onChange={(e) => {
                setNewWish(e.target.value);
                // Clear errors when user types
                if (moderationError) {
                  setModerationError(null);
                  setModerationSuggestion(null);
                }
              }}
              className="min-h-[100px] rounded-xl border-primary/30 bg-slate-800/50 font-bold resize-none"
              maxLength={150}
            />
            <p className="text-xs text-slate-400 font-bold text-left">
              {newWish.length} / 150
            </p>
          </div>

          <Button
            type="submit"
            disabled={isSubmitting || isModerating || !newWish.trim()}
            className="w-full h-12 rounded-xl font-black text-base gap-2 shadow-lg shadow-primary/30 transition-all hover:scale-[1.02]"
          >
            {isModerating ? (
              <>
                <Shield className="w-5 h-5 animate-pulse" />
                جاري المراجعة بالذكاء الاصطناعي...
              </>
            ) : isSubmitting ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                جاري الإضافة...
              </>
            ) : (
              <>
                <Send className="w-5 h-5" />
                أضف أمنيتك ✨
              </>
            )}
          </Button>

          <p className="text-xs text-slate-500 font-bold text-center">
            💡 اكتب أمنية إيجابية تدعم الحملة وتعبر عن تطلعاتك الحقيقية
          </p>
        </form>

        {/* عرض الأمنيات */}
        <div className="space-y-3">
          <div className="space-y-2">
            <h3 className="text-lg font-black text-slate-300 flex items-center gap-2">
              <Star className="w-5 h-5 text-amber-400" />
              أمنيات حقيقية من مصريين ({wishes.length})
            </h3>
            {!isLoading && wishes.length > 0 && (
              <span className="text-xs text-slate-500 font-bold animate-pulse">تحديث لحظي 🔴</span>
            )}
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="h-32 bg-slate-800/50 rounded-xl animate-pulse" />
              ))}
            </div>
          ) : wishes.length === 0 ? (
            <div className="text-center py-16 space-y-5 px-4">
              <div className="text-7xl animate-bounce">💭</div>
              <div className="space-y-3">
                <h4 className="text-2xl font-black text-white">
                  حائط الأمنيات فاضي!
                </h4>
                <p className="text-slate-400 font-bold text-lg leading-relaxed max-w-md mx-auto">
                  كن أول من يشارك أمنيته الحقيقية<br />
                  إيه أول حاجة هتعملها لما الإنترنت يبقى غير محدود؟
                </p>
              </div>
              <div className="pt-4">
                <div className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-primary/20 border border-primary/30">
                  <Sparkles className="w-5 h-5 text-primary animate-pulse" />
                  <span className="text-sm font-black text-primary">اكتب أمنيتك فوق واضغط إضافة ✨</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {wishes.map((wish, index) => (
                <div
                  key={wish.id}
                  className={`p-4 rounded-xl bg-gradient-to-br ${getRandomColor(
                    index
                  )} border transition-all duration-300 hover:scale-105 hover:shadow-xl group animate-in fade-in slide-in-from-bottom-2`}
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  {/* الأيقونة */}
                  <div className="flex items-start gap-3">
                    <div className="text-3xl group-hover:scale-110 transition-transform">
                      {getRandomIcon(index)}
                    </div>
                    <div className="flex-1 space-y-2">
                      {/* المحتوى */}
                      <p className="text-sm md:text-base font-bold text-white leading-relaxed">
                        "{wish.content}"
                      </p>

                      {/* معلومات الكاتب */}
                      <div className="flex items-center justify-between pt-2 border-t border-white/10">
                        <p className="text-xs text-slate-400 font-bold flex items-center gap-1">
                          <Zap className="w-3 h-3" />
                          {wish.author_name}
                        </p>
                        <p className="text-[10px] text-slate-500 font-bold">
                          {new Date(wish.created_at).toLocaleDateString('ar-EG', {
                            day: 'numeric',
                            month: 'short',
                          })}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* رسالة تحفيزية */}
        <div className="p-4 rounded-xl bg-gradient-to-r from-pink-500/10 to-purple-500/10 border border-pink-500/20">
          <p className="text-center text-sm font-bold text-slate-300 leading-relaxed">
            💡 كل أمنية حقيقية هنا هي سبب قوي إننا نطالب بإنترنت غير محدود!
          </p>
        </div>
      </CardContent>
    </Card>
  );
};
