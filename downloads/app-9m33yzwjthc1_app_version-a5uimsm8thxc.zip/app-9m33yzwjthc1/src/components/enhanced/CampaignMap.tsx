import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Map, Flame, TrendingUp } from 'lucide-react';

interface Props {
  data: { name: string; support: number }[];
}

export const CampaignMap: React.FC<Props> = ({ data }) => {
  // Sort data to find hot spots
  const sortedData = [...data].sort((a, b) => b.support - a.support);
  const topGov = sortedData[0];

  const getColorClass = (val: number) => {
    if (val > 15) return 'bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]';
    if (val > 10) return 'bg-orange-500';
    if (val > 5) return 'bg-primary';
    return 'bg-slate-500';
  };

  const getTextColor = (val: number) => {
    if (val > 15) return 'text-red-500';
    if (val > 10) return 'text-orange-500';
    if (val > 5) return 'text-primary';
    return 'text-slate-400';
  };

  return (
    <Card className="glass-card h-full overflow-hidden border-primary/20 shadow-2xl">
      <CardHeader className="bg-primary/5 pb-6 border-b border-primary/10">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-black flex items-center gap-2 text-primary">
            <Map className="w-6 h-6" /> خريطة الحرارة للمطالب 🇪🇬
          </CardTitle>
          {topGov && (
            <Badge variant="outline" className="bg-red-500/10 text-red-500 border-red-500/20 animate-pulse flex gap-1">
              <Flame className="w-3 h-3" /> الأكثر نشاطاً: {topGov.name}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {/* Lazy Loading Wrapper - Performance Optimization */}
        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4 max-h-[500px] overflow-y-auto custom-scrollbar">
          {data.length > 0 ? (
            data.map((gov) => (
              <div key={gov.name} className="space-y-2 group p-2 rounded-xl hover:bg-white/5 transition-all">
                <div className="flex justify-between text-xs items-center">
                  <span className="font-black flex items-center gap-1.5">
                    <span className={`w-2 h-2 rounded-full ${getColorClass(gov.support)}`} />
                    {gov.name}
                  </span>
                  <span className={`font-mono font-bold ${getTextColor(gov.support)}`}>
                    {gov.support}% <TrendingUp className="inline w-3 h-3 ml-0.5" />
                  </span>
                </div>
                <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-1000 ease-out ${getColorClass(gov.support)}`}
                    style={{ width: `${gov.support}%` }} 
                  />
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-full py-20 text-center">
              <Map className="w-12 h-12 text-muted-foreground/20 mx-auto mb-4" />
              <p className="text-sm text-muted-foreground">جاري تحليل البيانات الجغرافية...</p>
            </div>
          )}
        </div>
        
        <div className="bg-slate-900/50 p-4 border-t border-primary/10 flex flex-wrap justify-around gap-2 text-[10px] text-muted-foreground font-bold uppercase tracking-wider">
           <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500" /> مرتفع جداً</div>
           <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-orange-500" /> مرتفع</div>
           <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-primary" /> متوسط</div>
           <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-slate-500" /> عادي</div>
        </div>
      </CardContent>
    </Card>
  );
};
