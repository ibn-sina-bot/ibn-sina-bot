import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Rocket, Smartphone, MessageCircle, BarChart, CheckCircle2 } from 'lucide-react';

export const FutureRoadmap: React.FC = () => {
  const steps = [
    {
      title: 'إطلاق التطبيق المحمول',
      desc: 'نسخة مخصصة للهواتف لتسهيل التصويت ومتابعة الحملة وتلقي الإشعارات اللحظية.',
      icon: <Smartphone className="w-5 h-5" />,
      status: 'upcoming'
    },
    {
      title: 'التواصل مع المسؤولين',
      desc: 'تقديم ملف شامل بمطالب الحملة وإحصائيات المشاركة للجهات المعنية وشركات الاتصالات.',
      icon: <MessageCircle className="w-5 h-5" />,
      status: 'planned'
    },
    {
      title: 'تحليل جودة الشبكة',
      desc: 'إطلاق أداة لقياس سرعة الإنترنت وجودته في جميع المحافظات وعرضها على خريطة تفاعلية.',
      icon: <BarChart className="w-5 h-5" />,
      status: 'planned'
    }
  ];

  return (
    <Card className="glass-card border-primary/20 bg-gradient-to-br from-slate-900/50 via-slate-900/30 to-slate-900/50">
      <CardContent className="p-8 space-y-8">
        <div className="flex items-center gap-4 border-b border-white/10 pb-6">
          <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center animate-pulse-subtle">
            <Rocket className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="text-2xl font-black text-white">خارطة الطريق المستقبلية 🚀</h3>
            <p className="text-sm text-muted-foreground">خطواتنا القادمة لتحقيق حلم الإنترنت غير المحدود.</p>
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {steps.map((step, idx) => (
            <div key={idx} className="relative group p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 hover:border-primary/30 transition-all duration-300">
              <div className="absolute top-4 left-4">
                <div className={`w-2 h-2 rounded-full ${step.status === 'upcoming' ? 'bg-yellow-500 animate-pulse' : 'bg-slate-600'}`} />
              </div>
              
              <div className="mb-4 w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                {step.icon}
              </div>
              
              <h4 className="font-bold text-lg mb-2 group-hover:text-primary transition-colors">{step.title}</h4>
              <p className="text-xs text-muted-foreground leading-relaxed h-16">{step.desc}</p>
              
              <div className="mt-4 pt-4 border-t border-white/5 flex items-center justify-between text-[10px] text-muted-foreground font-mono uppercase tracking-widest">
                <span>المرحلة {idx + 1}</span>
                {step.status === 'upcoming' && <span className="text-yellow-500 font-bold">قريباً</span>}
              </div>
            </div>
          ))}
        </div>

        <div className="bg-primary/5 rounded-xl p-4 border border-primary/10 flex gap-3 items-center text-xs text-muted-foreground">
          <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0" />
          <p>
            هذه الخارطة مرنة وتعتمد بشكل أساسي على دعمكم ومشاركتكم. كل صوت يضاف يقربنا خطوة نحو الهدف!
          </p>
        </div>
      </CardContent>
    </Card>
  );
};
