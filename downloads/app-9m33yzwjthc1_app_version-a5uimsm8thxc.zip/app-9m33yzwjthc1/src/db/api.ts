import { supabase } from './supabase';

export interface Comment {
  id: string;
  name: string;
  governorate: string;
  content: string;
  created_at: string;
  status?: 'pending' | 'approved' | 'rejected';
  moderation_reason?: string;
  likes_count: number;
  hearts_count: number;
  broken_heart_count: number;
  sad_count: number;
}

export interface CampaignStats {
  id: number;
  vote_count: number;
  shared_count: number;
  comment_offset: number;
  virtual_start_time: string;
}

export interface InternationalComparison {
  id: number;
  country_name: string;
  country_code: string;
  avg_speed: string;
  avg_price: string;
  is_unlimited: boolean;
}

export interface FAQ {
  id: number;
  question: string;
  answer: string;
  category: string;
}

export interface Testimonial {
  id: number;
  name: string;
  role: string;
  story: string;
  avatar_url?: string;
}

export interface Fact {
  id: number;
  title: string;
  content: string;
  icon: string;
}

export interface CampaignUpdate {
  id: number;
  title: string;
  content: string;
  update_date: string;
  impact_level: 'success' | 'warning' | 'info';
}



export interface SitePresence {
  id: string;
  last_seen: string;
  governorate?: string;
}

export const updatePresence = async (id?: string, governorate?: string): Promise<string> => {
  const now = new Date().toISOString();
  if (id) {
    const { error } = await supabase
      .from('site_presence')
      .update({ last_seen: now, governorate })
      .eq('id', id);
    if (!error) return id;
  }

  const { data, error } = await supabase
    .from('site_presence')
    .insert([{ last_seen: now, governorate }])
    .select('id')
    .maybeSingle();

  if (error || !data) {
    console.error('Error updating presence:', error);
    return id || '';
  }
  return data.id;
};

export const getActiveUsersCount = async (): Promise<number> => {
  const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
  const { count, error } = await supabase
    .from('site_presence')
    .select('*', { count: 'exact', head: true })
    .gt('last_seen', fiveMinutesAgo);
  
  if (error) {
    console.error('Error getting active users:', error);
    return 0;
  }
  return count || 0;
};

export const getLatestGovernorate = async (): Promise<string> => {
  const { data, error } = await supabase
    .from('comments')
    .select('governorate')
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();
  
  if (error || !data) return 'القاهرة';
  return data.governorate;
};

export const getParticipatingGovernoratesCount = async (): Promise<number> => {
  const { data, error } = await supabase
    .from('comments')
    .select('governorate');
  
  if (error || !data) return 1;
  const uniqueGovs = new Set(data.map(d => d.governorate));
  return uniqueGovs.size;
};
export const getGovernorateDistribution = async (): Promise<{ name: string; support: number }[]> => {
  const { data, error } = await supabase
    .from('comments')
    .select('governorate');
  
  if (error || !data || data.length === 0) return [];
  
  const counts: Record<string, number> = {};
  data.forEach(d => {
    counts[d.governorate] = (counts[d.governorate] || 0) + 1;
  });

  const total = data.length;
  // Convert to percentage and sort
  return Object.entries(counts)
    .map(([name, count]) => ({
      name,
      support: Math.round((count / total) * 100)
    }))
    .sort((a, b) => b.support - a.support)
    .slice(0, 10); // Show top 10
};




export const getCampaignStats = async (): Promise<CampaignStats | null> => {
  const { data, error } = await supabase
    .from('campaign_stats')
    .select('*')
    .eq('id', 1)
    .maybeSingle();
  
  if (error) {
    console.error('خطأ في جلب الإحصائيات:', error);
    return null;
  }
  
  console.log('الإحصائيات الحالية:', data);
  return data;
};

export const getStats = async () => {
  const stats = await getCampaignStats();
  return {
    votes: stats?.vote_count || 0,
    shares: stats?.shared_count || 0
  };
};

export const castVote = async (
  fingerprint: string, 
  surveyData?: { networkProvider: string; dataUsageType: string }
): Promise<{ success: boolean; error?: string }> => {
  // Check rate limit first
  const { data: rateLimit, error: rlError } = await supabase
    .from('vote_rate_limit')
    .select('*')
    .eq('fingerprint', fingerprint)
    .maybeSingle();

  const now = new Date();

  if (rateLimit) {
    const lastAttempt = new Date(rateLimit.last_attempt);
    const diffMs = now.getTime() - lastAttempt.getTime();
    
    // If less than 1 hour since last vote, block it (standard campaign rule)
    if (diffMs < 60 * 60 * 1000) {
      const remainingMinutes = Math.ceil((60 * 60 * 1000 - diffMs) / 60000);
      console.warn('Rate limit exceeded for fingerprint:', fingerprint);
      return { 
        success: false, 
        error: `لقد صوّت مؤخراً. يمكنك التصويت مرة أخرى بعد ${remainingMinutes} دقيقة.` 
      };
    }

    // Update rate limit
    await supabase
      .from('vote_rate_limit')
      .update({ 
        last_attempt: now.toISOString(),
        count: (rateLimit.count || 0) + 1 
      })
      .eq('fingerprint', fingerprint);
  } else {
    // Insert new rate limit record
    await supabase
      .from('vote_rate_limit')
      .insert([{ fingerprint, last_attempt: now.toISOString(), count: 1 }]);
  }

  const voteData: any = { fingerprint };
  if (surveyData) {
    voteData.network_provider = surveyData.networkProvider;
    voteData.data_usage_type = surveyData.dataUsageType;
  }

  const { data, error } = await supabase
    .from('votes')
    .insert([voteData])
    .select();
  
  if (error) {
    console.error('خطأ في التصويت:', error);
    return { success: false, error: 'حدث خطأ أثناء حفظ التصويت. يرجى المحاولة لاحقاً.' };
  }
  
  // Award points for voting
  await supabase.rpc('award_points', {
    user_fingerprint: fingerprint,
    points_to_add: 1,
    action_type: 'vote'
  });
  
  console.log('تم التصويت بنجاح:', data);
  return { success: true };
};

export const awardSharePoints = async (fingerprint: string) => {
  await supabase.rpc('award_points', {
    user_fingerprint: fingerprint,
    points_to_add: 2,
    action_type: 'share'
  });
};

export const getLeaderboard = async (limit = 10) => {
  const { data, error } = await supabase
    .from('user_points')
    .select('*')
    .order('points', { ascending: false })
    .limit(limit);
  
  if (error) {
    console.error('Error fetching leaderboard:', error);
    return [];
  }
  return data || [];
};

export const getUserPoints = async (fingerprint: string) => {
  const { data, error } = await supabase
    .from('user_points')
    .select('*')
    .eq('fingerprint', fingerprint)
    .maybeSingle();
  
  if (error) {
    console.error('Error fetching user points:', error);
    return null;
  }
  return data;
};

export const getRankLabel = (points: number) => {
  if (points >= 31) return 'رائد التغيير 🏆';
  if (points >= 16) return 'سفير الحملة 🌟';
  if (points >= 6) return 'ناشط رقمي ⚡';
  return 'عضو جديد 🛡️';
};


export const getNetworkAnalytics = async () => {
  const { data, error } = await supabase
    .from('network_analytics')
    .select('*');
  
  if (error) {
    console.error('Error fetching network analytics:', error);
    return [];
  }
  return data || [];
};

export const getDataUsageAnalytics = async () => {
  const { data, error } = await supabase
    .from('data_usage_analytics')
    .select('*');
  
  if (error) {
    console.error('Error fetching data usage analytics:', error);
    return [];
  }
  return data || [];
};

export const getComments = async (page = 0, limit = 10): Promise<Comment[]> => {
  const { data, error } = await supabase
    .from('comments')
    .select('*')
    .eq('status', 'approved') // عرض التعليقات المعتمدة فقط
    .order('created_at', { ascending: false })
    .range(page * limit, (page + 1) * limit - 1);
  
  if (error) {
    console.error('Error fetching comments:', error);
    return [];
  }
  return data || [];
};

export const getCommentsCount = async (): Promise<number> => {
  const { count, error } = await supabase
    .from('comments')
    .select('*', { count: 'exact', head: true })
    .eq('status', 'approved'); // عد التعليقات المعتمدة فقط
  
  if (error) {
    console.error('Error fetching comments count:', error);
    return 0;
  }
  return count || 0;
};

export const reactToComment = async (commentId: string, fingerprint: string, reactionType: 'like' | 'heart' | 'broken_heart' | 'sad'): Promise<{ action: 'added' | 'removed', count: number }> => {
  console.log('🔵 API: Calling react_to_comment RPC', { commentId, fingerprint, reactionType });
  
  // تحويل نوع التفاعل إلى إيموجي للعرض في السجلات
  const emojiMap = { like: '⚡', heart: '🚀', broken_heart: '💥', sad: '😤' };
  console.log(`🔵 التفاعل: ${emojiMap[reactionType]}`);
  
  const { data, error } = await supabase.rpc('react_to_comment', {
    target_comment_id: commentId,
    user_fingerprint: fingerprint,
    reaction_kind: reactionType
  });

  if (error) {
    console.error('🔴 API Error reacting to comment:', error);
    console.error('🔴 Error details:', JSON.stringify(error, null, 2));
    throw error;
  }

  console.log('🟢 API: Reaction successful', data);
  return data;
};

// جلب تفاعلات المستخدم الحالي على التعليقات
export const getUserReactions = async (fingerprint: string, commentIds: string[]): Promise<Record<string, string[]>> => {
  if (!fingerprint || commentIds.length === 0) return {};
  
  const { data, error } = await supabase
    .from('comment_reactions')
    .select('comment_id, reaction_type')
    .eq('fingerprint', fingerprint)
    .in('comment_id', commentIds);
  
  if (error) {
    console.error('Error fetching user reactions:', error);
    return {};
  }
  
  // تنظيم البيانات: { commentId: [reactionType1, reactionType2] }
  const reactions: Record<string, string[]> = {};
  data?.forEach(r => {
    if (!reactions[r.comment_id]) reactions[r.comment_id] = [];
    reactions[r.comment_id].push(r.reaction_type);
  });
  
  return reactions;
};

export interface ForumPost {
  id: number;
  user_name: string;
  content: string;
  likes: number;
  created_at: string;
}

export const getForumPosts = async (page = 0, limit = 10): Promise<ForumPost[]> => {
  const { data, error } = await supabase
    .from('forum_posts')
    .select('*')
    .order('created_at', { ascending: false })
    .range(page * limit, (page + 1) * limit - 1);
  
  if (error) {
    console.error('Error fetching forum posts:', error);
    return [];
  }
  return data || [];
};

export const addForumPost = async (post: { user_name: string; content: string }) => {
  const forbiddenWords = [
    'zopre', 'naaaar', 'وسخ', 'شتيمة', 'قذر', 'خول', 'شرموط', 'لبوة', 'متناك',
    'احا', 'كس', 'طيز', 'زب', 'سكس', 'نيك', 'منيوك', 'عرص', 'لبوه',
    'ديوث', 'قحبة', 'شرموطه', 'منيوكه', 'كسمك'
  ];

  const hasForbiddenWord = forbiddenWords.some(word => 
    post.content.toLowerCase().includes(word.toLowerCase()) || 
    post.user_name.toLowerCase().includes(word.toLowerCase())
  );

  const isSpam = /(.)\1{6,}/.test(post.content); 

  if (hasForbiddenWord || isSpam) {
    throw new Error('عذراً، يحتوي المنشور على كلمات غير لائقة أو محتوى سبام.');
  }

  const { error } = await supabase
    .from('forum_posts')
    .insert([post]);
  
  if (error) {
    console.error('Error adding forum post:', error);
    throw error;
  }
};

export const likeForumPost = async (id: number) => {
  const { error } = await supabase.rpc('increment_post_likes', { post_id: id });
  if (error) {
    // Fallback if RPC doesn't exist
    const { data: post } = await supabase.from('forum_posts').select('likes').eq('id', id).maybeSingle();
    if (post) {
      await supabase.from('forum_posts').update({ likes: post.likes + 1 }).eq('id', id);
    }
  }
};

export const subscribeToForumPosts = (callback: (post: ForumPost) => void) => {
  const channel = supabase
    .channel('forum_posts_changes')
    .on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'forum_posts' },
      (payload) => {
        console.log('🔴 منشور جديد:', payload);
        if (payload.new) {
          callback(payload.new as ForumPost);
        }
      }
    )
    .subscribe((status) => {
      console.log('📡 حالة الاشتراك في المنشورات:', status);
    });
  
  return channel;
};

export const addComment = async (comment: Omit<Comment, 'id' | 'created_at' | 'status' | 'moderation_reason' | 'likes_count' | 'hearts_count' | 'broken_heart_count' | 'sad_count'>) => {
  // قائمة الكلمات المرفوضة (فلتر تلقائي شامل)
  const forbiddenWords = [
    'zopre', 'naaaar', 'وسخ', 'شتيمة', 'قذر', 'خول', 'شرموط', 'لبوة', 'متناك',
    'احا', 'كس', 'طيز', 'زب', 'سكس', 'نيك', 'منيوك', 'عرص', 'لبوه',
    'ديوث', 'قحبة', 'شرموطه', 'منيوكه', 'كسمك'
  ];

  // التحقق من وجود كلمات بذيئة
  const hasForbiddenWord = forbiddenWords.some(word => 
    comment.content.toLowerCase().includes(word.toLowerCase()) || 
    comment.name.toLowerCase().includes(word.toLowerCase())
  );

  // التحقق من التكرار العشوائي للحروف (سبام)
  const isSpam = /(.)\1{6,}/.test(comment.content); 

  if (hasForbiddenWord || isSpam) {
    console.error('تم حجب التعليق لاحتوائه على محتوى غير لائق');
    throw new Error('عذراً، لا يمكن إضافة هذا التعليق لاحتوائه على كلمات غير لائقة أو محتوى سبام.');
  }

  // إضافة التعليق بحالة "pending" للمراجعة
  const { data: insertedComment, error: insertError } = await supabase
    .from('comments')
    .insert([{ ...comment, status: 'pending' }])
    .select()
    .single();
  
  if (insertError) {
    console.error('Error adding comment:', insertError);
    throw insertError;
  }

  // إرسال التعليق للمراجعة بالذكاء الاصطناعي
  try {
    const moderationResponse = await supabase.functions.invoke('moderate-comment', {
      body: {
        commentId: insertedComment.id,
        name: comment.name,
        content: comment.content
      }
    });

    if (moderationResponse.error) {
      const errorMsg = await moderationResponse.error?.context?.text?.();
      console.error('Moderation error:', errorMsg || moderationResponse.error);
      throw new Error('فشلت عملية المراجعة. يرجى المحاولة مرة أخرى.');
    }

    const moderationData = moderationResponse.data;
    
    return {
      success: true,
      commentId: insertedComment.id,
      approved: moderationData?.approved || false,
      reason: moderationData?.reason || '',
      message: moderationData?.approved 
        ? 'تم نشر تعليقك بنجاح! ✅' 
        : 'لم يتم نشر تعليقك. السبب: ' + (moderationData?.reason || 'التعليق لا يدعم الحملة')
    };
  } catch (moderationError) {
    console.error('Failed to moderate comment:', moderationError);
    throw new Error('فشلت عملية المراجعة. يرجى المحاولة مرة أخرى.');
  }
};

export const subscribeToStats = (callback: (stats: CampaignStats) => void) => {
  const channel = supabase
    .channel('campaign_stats_changes')
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'campaign_stats' },
      (payload) => {
        console.log('🔴 تحديث لحظي للإحصائيات:', payload);
        if (payload.new && (payload.new as CampaignStats).id === 1) {
          callback(payload.new as CampaignStats);
        }
      }
    )
    .subscribe((status) => {
      console.log('📡 حالة الاشتراك في الإحصائيات:', status);
    });
  
  return channel;
};

export const subscribeToComments = (callback: (comment: Comment) => void) => {
  const channel = supabase
    .channel('comments_changes')
    .on(
      'postgres_changes',
      { 
        event: 'UPDATE', 
        schema: 'public', 
        table: 'comments',
        filter: 'status=eq.approved'
      },
      (payload) => {
        console.log('🔴 تعليق تمت الموافقة عليه:', payload);
        if (payload.new && (payload.new as Comment).status === 'approved') {
          callback(payload.new as Comment);
        }
      }
    )
    .subscribe((status) => {
      console.log('📡 حالة الاشتراك في التعليقات:', status);
    });
  
  return channel;
};

export const subscribeToVotes = (callback: () => void) => {
  const channel = supabase
    .channel('votes_changes')
    .on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'votes' },
      (payload) => {
        console.log('🔴 صوت جديد تم تسجيله:', payload);
        callback();
      }
    )
    .subscribe((status) => {
      console.log('📡 حالة الاشتراك في الأصوات:', status);
    });
  
  return channel;
};

export const getInternationalComparisons = async (): Promise<InternationalComparison[]> => {
  const { data, error } = await supabase.from('international_comparisons').select('*').order('id', { ascending: true });
  if (error) return [];
  return data || [];
};

export const getFAQs = async (): Promise<FAQ[]> => {
  const { data, error } = await supabase.from('faqs').select('*').order('display_order', { ascending: true });
  if (error) return [];
  return data || [];
};

export const getTestimonials = async (): Promise<Testimonial[]> => {
  const { data, error } = await supabase.from('testimonials').select('*').order('created_at', { ascending: false });
  if (error) return [];
  return data || [];
};

export const getFacts = async (): Promise<Fact[]> => {
  const { data, error } = await supabase.from('campaign_facts').select('*').order('id', { ascending: true });
  if (error) return [];
  return data || [];
};


export const getCampaignUpdates = async (): Promise<CampaignUpdate[]> => {
  const { data, error } = await supabase.from('campaign_updates').select('*').order('update_date', { ascending: false });
  if (error) return [];
  return data || [];
};

// ============================================
// نظام المستويات المحسّن (Enhanced Level System)
// ============================================

export interface LevelInfo {
  level: number;
  title: string;
  minPoints: number;
  maxPoints: number;
  color: string;
  bgColor: string;
  borderColor: string;
  frameStyle: 'basic' | 'silver' | 'gold' | 'diamond';
  icon: string;
  benefits: string[];
}

export const LEVELS: LevelInfo[] = [
  {
    level: 1,
    title: 'مشارك جديد',
    minPoints: 0,
    maxPoints: 5,
    color: 'text-slate-400',
    bgColor: 'bg-slate-500/10',
    borderColor: 'border-slate-500/30',
    frameStyle: 'basic',
    icon: '🛡️',
    benefits: ['بطاقة دعم أساسية', 'المشاركة في التعليقات']
  },
  {
    level: 2,
    title: 'ناشط رقمي',
    minPoints: 6,
    maxPoints: 10,
    color: 'text-blue-400',
    bgColor: 'bg-blue-500/10',
    borderColor: 'border-blue-500/30',
    frameStyle: 'basic',
    icon: '⚡',
    benefits: ['بطاقة دعم محسّنة', 'ظهور في لوحة الشرف']
  },
  {
    level: 3,
    title: 'مؤثر نشط',
    minPoints: 11,
    maxPoints: 15,
    color: 'text-cyan-400',
    bgColor: 'bg-cyan-500/10',
    borderColor: 'border-cyan-500/30',
    frameStyle: 'silver',
    icon: '💎',
    benefits: ['إطار فضي للبطاقة', 'أولوية في العرض']
  },
  {
    level: 4,
    title: 'سفير الحملة',
    minPoints: 16,
    maxPoints: 25,
    color: 'text-purple-400',
    bgColor: 'bg-purple-500/10',
    borderColor: 'border-purple-500/30',
    frameStyle: 'silver',
    icon: '🌟',
    benefits: ['إطار مميز', 'شارة سفير رسمي']
  },
  {
    level: 5,
    title: 'قائد التغيير',
    minPoints: 26,
    maxPoints: 40,
    color: 'text-amber-400',
    bgColor: 'bg-amber-500/10',
    borderColor: 'border-amber-500/30',
    frameStyle: 'gold',
    icon: '👑',
    benefits: ['إطار ذهبي', 'شارة قائد', 'ظهور بارز']
  },
  {
    level: 6,
    title: 'رائد التغيير',
    minPoints: 41,
    maxPoints: 60,
    color: 'text-orange-400',
    bgColor: 'bg-orange-500/10',
    borderColor: 'border-orange-500/30',
    frameStyle: 'gold',
    icon: '🏆',
    benefits: ['إطار ذهبي متقدم', 'شارة رائد', 'أولوية قصوى']
  },
  {
    level: 7,
    title: 'أسطورة الحملة',
    minPoints: 61,
    maxPoints: 100,
    color: 'text-red-400',
    bgColor: 'bg-red-500/10',
    borderColor: 'border-red-500/30',
    frameStyle: 'diamond',
    icon: '🔥',
    benefits: ['إطار ماسي', 'شارة أسطورية', 'تكريم خاص']
  },
  {
    level: 8,
    title: 'بطل الإنترنت الحر',
    minPoints: 101,
    maxPoints: 999999,
    color: 'text-pink-400',
    bgColor: 'bg-pink-500/10',
    borderColor: 'border-pink-500/30',
    frameStyle: 'diamond',
    icon: '⭐',
    benefits: ['إطار حصري', 'شارة البطل', 'تخليد في تاريخ الحملة']
  }
];

export const getLevelInfo = (points: number): LevelInfo => {
  for (let i = LEVELS.length - 1; i >= 0; i--) {
    if (points >= LEVELS[i].minPoints) {
      return LEVELS[i];
    }
  }
  return LEVELS[0];
};

export const getNextLevelInfo = (points: number): LevelInfo | null => {
  const currentLevel = getLevelInfo(points);
  const currentIndex = LEVELS.findIndex(l => l.level === currentLevel.level);
  if (currentIndex < LEVELS.length - 1) {
    return LEVELS[currentIndex + 1];
  }
  return null;
};

export const getLevelProgress = (points: number): number => {
  const currentLevel = getLevelInfo(points);
  const nextLevel = getNextLevelInfo(points);
  
  if (!nextLevel) return 100;
  
  const pointsInLevel = points - currentLevel.minPoints;
  const pointsNeeded = nextLevel.minPoints - currentLevel.minPoints;
  
  return Math.min(Math.round((pointsInLevel / pointsNeeded) * 100), 100);
};

// ============================================
// حائط الأمنيات الرقمي (Digital Wish Wall)
// ============================================

export interface Wish {
  id: string;
  content: string;
  author_name: string;
  governorate?: string;
  created_at: string;
  status: 'pending' | 'approved' | 'rejected';
  likes_count: number;
}

export const getWishes = async (limit: number = 50): Promise<Wish[]> => {
  const { data, error } = await supabase
    .from('wishes')
    .select('*')
    .eq('status', 'approved')
    .order('created_at', { ascending: false })
    .limit(limit);
  
  if (error) {
    console.error('Error fetching wishes:', error);
    return [];
  }
  return data || [];
};

export const addWish = async (content: string, authorName: string = 'مواطن مصري', governorate?: string): Promise<boolean> => {
  console.log('Adding wish:', { content, authorName, governorate });
  
  const { data, error } = await supabase
    .from('wishes')
    .insert([{ 
      content: content.trim(), 
      author_name: authorName.trim() || 'مواطن مصري',
      governorate,
      status: 'approved' // معتمدة بعد مراجعة AI
    }])
    .select();
  
  if (error) {
    console.error('Error adding wish:', error);
    return false;
  }
  
  console.log('Wish added successfully:', data);
  return true;
};

export const subscribeToWishes = (callback: (wish: Wish) => void) => {
  const channel = supabase
    .channel('wishes-changes')
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'wishes',
        filter: 'status=eq.approved'
      },
      (payload) => {
        callback(payload.new as Wish);
      }
    )
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
};

// ============================================
// لوحة شرف المحافظات المحسّنة
// ============================================

export interface GovernorateRanking {
  governorate: string;
  voteCount: number;
  commentCount: number;
  totalScore: number;
  rank: number;
  percentage: number;
}

export const getGovernoratesLeaderboard = async (): Promise<GovernorateRanking[]> => {
  // جلب عدد التعليقات لكل محافظة
  const { data: comments, error: commentsError } = await supabase
    .from('comments')
    .select('governorate');
  
  if (commentsError || !comments) {
    console.error('Error fetching comments:', commentsError);
    return [];
  }

  // حساب عدد التعليقات لكل محافظة
  const govCounts: Record<string, { comments: number }> = {};
  
  comments.forEach(c => {
    if (!govCounts[c.governorate]) {
      govCounts[c.governorate] = { comments: 0 };
    }
    govCounts[c.governorate].comments++;
  });

  // تحويل إلى مصفوفة وحساب النسب
  const total = comments.length;
  const rankings: GovernorateRanking[] = Object.entries(govCounts)
    .map(([governorate, counts]) => ({
      governorate,
      voteCount: 0, // يمكن إضافة منطق للتصويت لاحقاً
      commentCount: counts.comments,
      totalScore: counts.comments, // النقاط الإجمالية
      rank: 0, // سيتم تحديده بعد الترتيب
      percentage: Math.round((counts.comments / total) * 100)
    }))
    .sort((a, b) => b.totalScore - a.totalScore);

  // تعيين الترتيب
  rankings.forEach((item, index) => {
    item.rank = index + 1;
  });

  return rankings;
};
